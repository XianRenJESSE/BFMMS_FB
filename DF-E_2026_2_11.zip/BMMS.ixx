//BMMS.ixx
//basic_memory_management_system

export module BMMS;

#include "BMMS_dp.h"

export namespace bmms_f {
    size_t index_max = 0x00FFFFFFFFFFFFFF;

    class agent_ptr {
    public:
        friend class agent_ptr;

        //============================ ���� ============================

        // Ĭ�Ϲ��캯�� �õ���ָ��
        agent_ptr() = default;

        // ��ַ&&��С���캯��
        agent_ptr(
            void* ptr,
            size_t size
        );

        // ���������ݶ�ȡ������ָ��
        void load(
            size_t load_begin_in,
            size_t load_size_in,
            agent_ptr& save_agent_ptr_in,
            size_t     store_begin_in,
            bool       safe
        );

        // �Ӵ���ָ���ȡ����д�뵽����
        void store(
            agent_ptr& load_agent_ptr_in,
            size_t     load_begin_in,
            size_t     load_size_in,
            size_t     store_begin_in,
            bool       safe
        );

        //============================ ��д ============================

        // ���������ݶ�ȡ��voidָ��
        void load_to_void_ptr(
            size_t load_begin_in,
            size_t load_size_in,
            void* store_ptr_in,
            bool   safe
        );

        // ��voidָ�������д������
        void store_from_void_ptr(
            void* load_ptr_in,
            size_t load_size_in,
            size_t store_begin_in,
            bool   safe
        );

        // �������
        void clear();

        // ��Χ�������
        void clear_range(
            size_t begin_in,
            size_t size_in
        );

        //============================ ���ݻ�ȡ ============================

        // ��ȡָ��
        void get_void_ptr(void*& ptr_out);

        // ��ȡ�Ƿ�Ϊ��
        void get_is_null(bool& is_null_in);

        // ��ȡ��С
        void get_size(size_t& size_out);

        // ��ȡ���
        void get_begin(void*& begin_out);

        // ��ȡ�յ�
        void get_end(void*& end_out);

        // ��ȡ��Χ��鲼��
        void get_check_range_bool(
            size_t begin_in,
            size_t size_in,
            bool& is_valid_out
        );

        // ��ȡ���������
        void check_building_no_overflow(
            void*& ptr_in,
            size_t size_in,
            bool& building_is_no_overflow
        );

        // ��ȡ�����������������
        void  check_end_no_overflow(
            size_t begin_in,
            size_t size_in,
            bool& is_no_overflow
        );

#if defined(AGENT_PTR_INCLUDE_TEST)
        void test();
#endif

        //============================ �ж� ============================

        //========== ��Ϣ��ȡ ==========

        inline uintptr_t __self_begin__();

        inline uintptr_t __self_end__();

        inline uintptr_t __op_begin__(
            size_t begin_in
        );

        inline uintptr_t __op_end__(
            size_t op_begin_in,
            size_t op_size_in
        );

        inline uintptr_t __void_ptr_begin__(
            void*& op_ptr_in
        );

        inline uintptr_t __void_ptr_end__(
            void*& op_ptr_in,
            size_t op_size_in
        );

        //========== ��������ר��У�� ==========
        void check_building(
            void*& ptr_in,
            size_t& size_in
        );

        //========== ����У�� ==========

        inline bool no_overflow(uintptr_t a, size_t b);

        // �մ���ָ����
        inline void check_null_agent_ptr(
            agent_ptr& other_agent_ptr_in
        );

        // ��С���
        inline void check_size(
            size_t& self_op_size_in,
            size_t& other_op_size_in
        );

        // ˫������ָ�벿���ص������ռ���
        inline void check_self_and_other_managemented_range(
            uintptr_t& self_self_begin_in,
            uintptr_t& self_self_end_in,
            uintptr_t& other_self_begin_in,
            uintptr_t& other_self_end_in
        );

        // ����������Ч���
        inline void check_op_range_overlap(
            uintptr_t& self_self_begin_in,
            uintptr_t& self_self_end_in,
            uintptr_t& self_op_begin_in,
            uintptr_t& self_op_end_in_in,
            size_t& self_op_size,
            uintptr_t& other_self_begin_in,
            uintptr_t& other_self_end_in,
            uintptr_t& other_op_begin_in,
            uintptr_t& other_op_end_in,
            size_t& other_op_size
        );

        // ԭ�ز������ݼ��
        inline void check_op_on_the_spot(
            uintptr_t& self_op_begin_in,
            uintptr_t& self_op_end_in,
            uintptr_t& other_op_begin_in,
            uintptr_t& other_op_end_in
        );

        // ������Χ���ص����
        inline void check_op_range_not_overlapping(
            uintptr_t& self_begin_in,
            uintptr_t& self_end_in,
            uintptr_t& other_begin_in,
            uintptr_t& other_end_in
        );

        // ��voidָ����
        inline void check_null_void_ptr(void* ptr_in);

        //����ָ������Ŀռ� �� void*ָ������Ŀռ� �� �����ص� ���
        inline void check_self_managemented_range_and_void_ptr_op_range_not_overlapping(
            uintptr_t& self_self_begin_in,
            uintptr_t& self_self_end_in,
            uintptr_t& self_op_begin_in,
            uintptr_t& self_op_end_in_in,
            uintptr_t& void_ptr_op_begin_in,
            uintptr_t& void_ptr_op_end_in
        );

        // self��void_ptr�����Ĵ�С��Ч�Լ���
        inline void check_self_and_void_ptr_op_size(
            size_t& self_op_size_in,
            size_t& void_ptr_op_size_in
        );

        // ������������Ч�Լ���
        inline void check_self_op_range(
            uintptr_t& self_self_begin_in,
            uintptr_t& self_self_end_in,
            uintptr_t& self_op_begin_in,
            uintptr_t& self_op_end_in_in
        );

        void* raw_ptr = 0;
        size_t size = 0;
    };

    class static_volume {
    public:

        enum init_type {
            no_init_all_size  = 0, // ��ʼ�������ֽ�
            init_all_size     = 1, // ʵ�ʷ���ʱ�ų�ʼ��д��Ŀ�
        };

        enum alignment_type {
            without_alignment   = 0,
            byte_4_each_block   = 1,
            byte_8_each_block   = 2,
            byte_16_each_block  = 3,
            byte_32_each_block  = 4,
            byte_64_each_block  = 5
        };

        //======================================== ���ʿ��� ========================================

        //��ֹ����
        static_volume(const static_volume&) = delete;
        static_volume& operator=(const static_volume&) = delete;

        //�����ƶ�
        static_volume(static_volume&& other) noexcept;
        static_volume& operator=(static_volume&& other) noexcept;

        //======================================== ���������� ========================================

        // Ĭ�Ϲ��캯��
        static_volume() = delete;

        // �������캯��
        static_volume(
            size_t         block_size_in,
            size_t         block_count_max_in,
            init_type      init_type_in,
            alignment_type alignment_type_in,
            mes::a_mes&    mes_out
        );

        // ��������
        ~static_volume();

        //======================================== �ڴ���� ========================================

        void new_block(
            bmms_f::agent_ptr& agent_ptr_out,
            mes::a_mes&      mes_out
        );

        void delete_block(
            bmms_f::agent_ptr& agent_ptr_in
        );

        //============================ �������ݻ�ȡ ============================
        
        bool   get_is_init();

        size_t get_block_count_max();

        size_t get_free_block_count();

        size_t get_block_size();

        size_t __total_ram_size__();

        size_t __recycle_stack_size__();

        size_t __actually_block_size__();

        size_t __block_space_size__();

        uintptr_t __block_space_begin__();

        uintptr_t __block_space_end__();

        uintptr_t __stack_begin__();

        uintptr_t __stack_end__();

        //============================ ����У�麯�� ============================
        
        inline void check_total_size_no_overflow();

        inline void check_enum_init_type_valid(
            init_type init_type_in
        );

        inline void check_enum_alignment_type_valid(
            alignment_type alignment_type_in
        );

        inline void check_block_belong_to_self(
            bmms_f::agent_ptr& agent_ptr_in
        );

        inline void check_can_push(
            bmms_f::agent_ptr& agent_ptr_in
        );

        inline bool check_can_pop();

        //============================ ���� ============================
        #if defined(VOLUME_INCLUDE_TEST)
        void test();
        #endif

    private:
        //============================ ˽�����ݻ�ȡ ============================

        void* get_block_ptr(size_t block_index);

        size_t get_block_index(bmms_f::agent_ptr& block_agent_ptr_in);

        //============================ ���� ============================

        // ����������������㣬��Ϊ�������Ϊ�������Ȼ���׳��쳣���߽�������
        inline size_t nf_add(size_t a, size_t b); // ������ӷ�
        inline size_t nf_sub(size_t a, size_t b); // ���������
        inline size_t nf_mul(size_t a, size_t b); // ������˷�
        inline size_t nf_div(size_t a, size_t b); // ���������
        inline size_t nf_mod(size_t a, size_t b); // �����ȡģ


        //============================ ��ʼ�� ============================

        inline void init_recycle_stack();

        inline void init_a_block(
            void* block_begin_void_ptr_in
        );

        inline void init_block_ram_space();


        //============================ ջ���� ============================
        
        inline void push_to_recycle_stack(
            bmms_f::agent_ptr& block_agent_ptr_in
        );

        inline void pop_from_recycle_stack(
            bmms_f::agent_ptr& block_agent_ptr_out,
            mes::a_mes&      mes_out
        );

        // ����״̬
        bool           is_init         = false;                             // 1 byte
        init_type      init_type_      = init_type::no_init_all_size;       // 1 byte
        alignment_type alignment_type_ = alignment_type::without_alignment; // 1 byte
        byte_1         fill_0[5];                                           // 5 byte
        size_t         block_size            = 0;                           // 8 byte
        size_t         block_count_max       = 0;                           // 8 byte
        size_t*        recycle_stack_top_ptr = nullptr;                     // 8 byte

        unique_ptr<byte_1[]> ram_space       = nullptr;              // 8 byte
        byte_1               fill_1[24];                                    // 24 byte
        bmms_f::agent_ptr      block_ram_space;                               // 16 byte
        bmms_f::agent_ptr      stack_index_ram_space;                         // 16 byte
    };
    
    class static_volume_ptr {
    public:
        friend class static_volume_ptr;

        //======================================== ���������� ========================================
        static_volume_ptr() = delete;

        static_volume_ptr(
            shared_ptr<static_volume>& static_volume_shared_ptr_in,
            mes::a_mes& mes_out
        );

        ~static_volume_ptr();
        //======================================== ���ʿ��� ========================================

        //��ֹ����
        static_volume_ptr(const static_volume_ptr&) = delete;
        static_volume_ptr& operator=(const static_volume_ptr&) = delete;

        //�����ƶ�
        static_volume_ptr(static_volume_ptr&& other) noexcept;
        static_volume_ptr& operator=(static_volume_ptr&& other) noexcept;

        //======================================== ���ݿ��� ========================================

        // �������
        void clear();

        // ��Χ�������
        void clear_range(
            size_t begin_in,
            size_t size_in
        );

        //======================================== ���ݽ��� ========================================

        // ���������ݶ�ȡ������ָ��
        void load(
            size_t load_begin_in,
            size_t load_size_in,
            bmms_f::agent_ptr& save_agent_ptr_in,
            size_t     store_begin_in,
            bool       safe
        );

        // �Ӵ���ָ���ȡ����д�뵽����
        void store(
            bmms_f::agent_ptr& load_agent_ptr_in,
            size_t     load_begin_in,
            size_t     load_size_in,
            size_t     store_begin_in,
            bool       safe
        );

        // ���������ݶ�ȡ��voidָ��
        void load_to_void_ptr(
            size_t load_begin_in,
            size_t load_size_in,
            void* store_ptr_in,
            bool   safe
        );

        // ��voidָ�������д������
        void store_from_void_ptr(
            void* load_ptr_in,
            size_t load_size_in,
            size_t store_begin_in,
            bool   safe
        );

        //======================================== У�� ========================================
        
        void check_static_volume_value_valid();

        void check_is_init();

    private:
        bool is_init = false;
        byte_1 fill_0[7];
        bmms_f::agent_ptr agent_ptr = bmms_f::agent_ptr();
        shared_ptr<static_volume> static_volume_shared_ptr = nullptr;
    };
    
    class static_volume_part {
    public:
        //======================================== ���������� ========================================
        
        enum init_type {
            no_init_all_size = 0, // ��ʼ��ʱ�������п�
            init_all_size    = 1, // ʵ��ʹ��ʱ�������
        };

        enum control_type {
            allow_over_use     = 0,// ��������߼���ַ�������鼫��ʹ�ã��������������ó�����������
            not_allow_over_use = 1 // ����������
        };
        
        static_volume_part() = delete;

        static_volume_part(
            shared_ptr<static_volume>& static_volume_shared_ptr_in,
            size_t                     block_count_max_in,
            init_type                  init_type_in,
            control_type               control_type_in,
            mes::a_mes&                mes_out
        );

        ~static_volume_part();

        //======================================== ���ʿ��� ========================================

        //��ֹ����
        static_volume_part(const static_volume_part&) = delete;
        static_volume_part& operator=(const static_volume_part&) = delete;

        //�����ƶ�
        static_volume_part(static_volume_part&& other) noexcept;
        static_volume_part& operator=(static_volume_part&& other) noexcept;

        //======================================== ���ݿ��� ========================================
        
        void clear();

        void clear_range(
            size_t begin_in,
            size_t size_in
        );

        void resize(
            size_t block_count_limit_in,
            mes::a_mes& mes_out
        );

        // �ͷſ飬ʹ�ÿ��Բ����ն��Լ��ٶԾ�̬����ʹ��
        // ʹ���Ѿ��ͷŵĿ�ʱ���Զ����´Ӿ�̬��ȡ�ռ�
        void free_block(
            size_t block_index_in
        );

        void free_range(
            size_t begin_in,
            size_t size_in
        );

        //======================================== ���ݽ��� ========================================

        // ���������ݶ�ȡ������ָ��
        void load(
            size_t           load_begin_in,
            size_t           load_size_in,
            bmms_f::agent_ptr& save_agent_ptr_in,
            size_t           store_begin_in,
            bool             safe
        );

        // �Ӵ���ָ���ȡ����д�뵽����
        void store(
            bmms_f::agent_ptr& load_agent_ptr_in,
            size_t           load_begin_in,
            size_t           load_size_in,
            size_t           store_begin_in,
            bool             safe
        );

        // ���������ݶ�ȡ��voidָ��
        void load_to_void_ptr(
            size_t load_begin_in,
            size_t load_size_in,
            void*  store_ptr_in,
            bool   safe
        );

        // ��voidָ�������д������
        void store_from_void_ptr(
            void*  load_ptr_in,
            size_t load_size_in,
            size_t store_begin_in,
            bool   safe
        );

        //======================================== ���ݻ�ȡ ========================================

        inline size_t get_total_size();

        inline size_t get_block_count_max();

        inline size_t get_block_size();

        inline size_t get_block_count_used();

        inline void   get_block_ptr(
            size_t& block_index_in,
            bmms_f::agent_ptr& block_agent_ptr_out,
            bool& is_nullptr_out
        );

        inline void   get_range_info(
            size_t& op_begin_in,
            size_t& op_size_in,
            size_t& index_begin_out,
            size_t& index_count_out,
            size_t& index_end_out,
            size_t& op_begin_of_first_block_out,
            size_t& op_size_of_end_block_out,
            bool  & is_over_more_than_a_block_out
        );

        inline uintptr_t __block_ptr_ram_space_begin__();

        inline uintptr_t __block_ptr_ram_space_end__();

        //======================================== У�� ========================================
        
        inline void check_build_value_valid(
            mes::a_mes mes_out
        );

        inline void check_contro_valid(
            mes::a_mes mes_out
        );

        inline void check_range(
            size_t begin_in,
            size_t size_in
        );

        //======================================== ���� ========================================

        // ����������������㣬��Ϊ�������Ϊ�������Ȼ���׳��쳣���߽�������
        inline size_t nf_add(size_t a, size_t b); // ������ӷ�
        inline size_t nf_sub(size_t a, size_t b); // ���������
        inline size_t nf_mul(size_t a, size_t b); // ������˷�
        inline size_t nf_div(size_t a, size_t b); // ���������
        inline size_t nf_mod(size_t a, size_t b); // �����ȡģ

        void init_blocks();

    private:

        //======================================== ���� ========================================

        bool is_init         = false;
        byte_1 init_type_    = init_type::no_init_all_size;
        byte_1 control_type_ = control_type::not_allow_over_use;

        byte_1 fill_0[5];

        size_t block_count_max   = 0;
        size_t using_block_count = 0;

        shared_ptr<static_volume> static_volume_shared_ptr    = nullptr;

        unique_ptr<void*[]>       block_ptr_ram_space         = nullptr;
        bmms_f::agent_ptr           block_ptr_ram_space_agent_ptr;
    };

    class free_part {
    public:
        friend class free_volume;
        //======================================== ���������� ========================================

        enum init_type {
            no_init_all_size = 0, // ��ʼ��ʱ�������п�
            init_all_size = 1,    // ʵ��ʹ��ʱ�������
        };

        free_part() = delete;

        free_part(
            size_t      block_size_in,
            size_t      block_count_max_in,
            init_type   init_type_in,
            mes::a_mes& mes_out
        );

        ~free_part();

        //======================================== ���ʿ��� ========================================

        //��ֹ����
        free_part(const free_part&) = delete;
        free_part& operator=(const free_part&) = delete;

        //�����ƶ�
        free_part(free_part&& other) noexcept;
        free_part& operator=(free_part&& other) noexcept;

        //======================================== ���ݿ��� ========================================

        void clear();

        void clear_range(
            size_t begin_in,
            size_t size_in
        );

        void resize(
            size_t block_count_limit_in,
            mes::a_mes& mes_out
        );

        // �ͷſ飬ʹ�ÿ��Բ����ն��Լ��ٶԾ�̬����ʹ��
        // ʹ���Ѿ��ͷŵĿ�ʱ���Զ����´Ӿ�̬��ȡ�ռ�
        void free_block(
            size_t block_index_in
        );

        void free_range(
            size_t begin_in,
            size_t size_in
        );

        //======================================== ���ݽ��� ========================================

        // ���������ݶ�ȡ������ָ��
        void load(
            size_t           load_begin_in,
            size_t           load_size_in,
            bmms_f::agent_ptr& save_agent_ptr_in,
            size_t           store_begin_in,
            bool             safe
        );

        // �Ӵ���ָ���ȡ����д�뵽����
        void store(
            bmms_f::agent_ptr& load_agent_ptr_in,
            size_t           load_begin_in,
            size_t           load_size_in,
            size_t           store_begin_in,
            bool             safe
        );

        // ���������ݶ�ȡ��voidָ��
        void load_to_void_ptr(
            size_t load_begin_in,
            size_t load_size_in,
            void* store_ptr_in,
            bool   safe
        );

        // ��voidָ�������д������
        void store_from_void_ptr(
            void* load_ptr_in,
            size_t load_size_in,
            size_t store_begin_in,
            bool   safe
        );

        //======================================== ���ݻ�ȡ ========================================

        inline size_t get_total_size();

        inline size_t get_block_count_max();

        inline size_t get_block_size();

        inline size_t get_block_count_used();

        inline void   get_block_ptr(
            size_t& block_index_in,
            bmms_f::agent_ptr& block_agent_ptr_out,
            bool& is_nullptr_out
        );

        inline void   get_range_info(
            size_t& op_begin_in,
            size_t& op_size_in,
            size_t& index_begin_out,
            size_t& index_count_out,
            size_t& index_end_out,
            size_t& op_begin_of_first_block_out,
            size_t& op_size_of_end_block_out,
            bool& is_over_more_than_a_block_out
        );

        inline uintptr_t __block_ptr_ram_space_begin__();

        inline uintptr_t __block_ptr_ram_space_end__();

        //======================================== У�� ========================================

        inline void check_build_value_valid(
            mes::a_mes mes_out
        );

        inline void check_contro_valid(
            mes::a_mes mes_out
        );

        inline void check_range(
            size_t begin_in,
            size_t size_in
        );

        //======================================== ���� ========================================

        // ����������������㣬��Ϊ�������Ϊ�������Ȼ���׳��쳣���߽�������
        inline size_t nf_add(size_t a, size_t b); // ������ӷ�
        inline size_t nf_sub(size_t a, size_t b); // ���������
        inline size_t nf_mul(size_t a, size_t b); // ������˷�
        inline size_t nf_div(size_t a, size_t b); // ���������
        inline size_t nf_mod(size_t a, size_t b); // �����ȡģ

        void init_blocks(mes::a_mes& mes_out);

    private:

        //======================================== ���� ========================================

        bool is_init = false;
        bool init_type_    = init_type::no_init_all_size;

        byte_1 fill_0[6];

        size_t block_size = 0;  // ���������Ա
        size_t block_count_max = 0;
        size_t using_block_count = 0;

        unique_ptr<unique_ptr<byte_1[]>[]> block_ptr_ram_space = nullptr;
        bmms_f::agent_ptr                    block_ptr_ram_space_agent_ptr;

        byte_8 fill_1;
    };

    class free_volume{

        enum init_type {
            no_init_all_size = 0, // ��ʼ�������ֽ�
            init_all_size    = 1, // ʵ�ʷ���ʱ�ų�ʼ��д��Ŀ�
        };

        enum alignment_type {
            without_alignment = 0,
            byte_4_each_block = 1,
            byte_8_each_block = 2,
            byte_16_each_block = 3,
            byte_32_each_block = 4,
            byte_64_each_block = 5
        };

        //======================================== ���ʿ��� ========================================

        //��ֹ����
        free_volume(const free_volume&) = delete;
        free_volume& operator=(const free_volume&) = delete;

        //�����ƶ�
        free_volume(free_volume&& other) noexcept;
        free_volume& operator=(free_volume&& other) noexcept;

        //======================================== ���������� ========================================

        // Ĭ�Ϲ��캯��
        free_volume() = delete;

        // �������캯��
        free_volume(
            size_t         block_size_in,
            size_t         block_count_max_in,
            init_type      init_type_in,
            alignment_type alignment_type_in,
            mes::a_mes& mes_out
        );

        // ��������
        ~free_volume();

        //======================================== �ڴ���� ========================================

        void new_block(
            bmms_f::agent_ptr& agent_ptr_out,
            mes::a_mes& mes_out
        );

        void delete_block(
            bmms_f::agent_ptr& agent_ptr_in
        );

        //============================ �������ݻ�ȡ ============================

        bool   get_is_init();

        size_t get_block_count_max();

        size_t get_free_block_count();

        size_t get_block_size();

        size_t __total_ram_size__();

        size_t __recycle_stack_size__();

        size_t __actually_block_size__();

        size_t __block_space_size__();

        uintptr_t __block_space_begin__();

        uintptr_t __block_space_end__();

        uintptr_t __stack_begin__();

        uintptr_t __stack_end__();

        //============================ ����У�麯�� ============================

        inline void check_total_size_no_overflow();

        inline void check_enum_init_type_valid(
            init_type init_type_in
        );

        inline void check_enum_alignment_type_valid(
            alignment_type alignment_type_in
        );

        inline void check_block_belong_to_self(
            bmms_f::agent_ptr& agent_ptr_in
        );

        inline void check_can_push(
            bmms_f::agent_ptr& agent_ptr_in
        );

        inline bool check_can_pop();

        //============================ ���� ============================
#if defined(VOLUME_INCLUDE_TEST)
        void test();
#endif

    private:
        //============================ ˽�����ݻ�ȡ ============================

        void* get_block_ptr(size_t block_index);

        size_t get_block_index(bmms_f::agent_ptr& block_agent_ptr_in);

        //============================ ���� ============================

        // ����������������㣬��Ϊ�������Ϊ�������Ȼ���׳��쳣���߽�������
        inline size_t nf_add(size_t a, size_t b); // ������ӷ�
        inline size_t nf_sub(size_t a, size_t b); // ���������
        inline size_t nf_mul(size_t a, size_t b); // ������˷�
        inline size_t nf_div(size_t a, size_t b); // ���������
        inline size_t nf_mod(size_t a, size_t b); // �����ȡģ


        //============================ ��ʼ�� ============================

        inline void init_recycle_stack();

        inline void init_a_block(
            void* block_begin_void_ptr_in
        );

        inline void init_block_ram_space();


        //============================ ջ���� ============================

        inline void push_to_recycle_stack(
            bmms_f::agent_ptr& block_agent_ptr_in
        );

        inline void pop_from_recycle_stack(
            bmms_f::agent_ptr& block_agent_ptr_out,
            mes::a_mes& mes_out
        );

        // ����״̬
        bool           is_init = false;                             // 1 byte
        init_type      init_type_ = init_type::no_init_all_size;       // 1 byte
        alignment_type alignment_type_ = alignment_type::without_alignment; // 1 byte
        byte_1         fill_0[5];                                           // 5 byte
        size_t         block_size = 0;                           // 8 byte
        size_t         block_count_max = 0;                           // 8 byte
        size_t* recycle_stack_top_ptr = nullptr;                     // 8 byte

        unique_ptr<byte_1[]> ram_space = nullptr;              // 8 byte
        byte_1               fill_1[24];                                    // 24 byte
        bmms_f::agent_ptr      block_ram_space;                               // 16 byte
        bmms_f::agent_ptr      stack_index_ram_space;                         // 16 byte
    };

    /*
    class free_volume_ptr {
    
    }

    
    class logical_static_volume {

    };

    class logical_dynamic_volume {

    };
    */
};