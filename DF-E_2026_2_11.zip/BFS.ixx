export module BFS;

#include "BFS_dp.h"

export namespace bfs_f {

	class bin_file {
	public:

		friend class bin_file;
		//============================= ��ʼ�� =============================

		enum class init_type {
			open_existed,
			cover_and_create,
			create
		};

		bin_file() = default;

		// �Ӷ������ļ������ļ�����
		bin_file(
			str       path_in, 
			size_t    size_in,
			init_type init_type_in,
			mes::a_mes& mes_out
		);

		~bin_file();

		// ��ֹ����
		bin_file(const bin_file&) = delete;
		bin_file& operator=(const bin_file&) = delete;

		// ֧���ƶ�
		bin_file(bin_file&& other)noexcept;
		bin_file& operator=(bin_file&& other) noexcept;

		//============================= �ļ��������� =============================

		// ���Ѷ��������ļ����󴴽��ļ�����
		void open(
			str       path_in,
			size_t    size_in,
			init_type init_type_in,
			mes::a_mes& mes_out
		);

		// ����ˢ�»���������������
		void flush();

		void flush_with_check(
			mes::a_mes& mes_out
		);

		// �ر�
		void close(
			mes::a_mes& mes_out
		);

		// �������ô�С
		void resize(
			size_t size_in,
			mes::a_mes& mes_out
		);

		// ����ļ�
		void clear(
			mes::a_mes& mes_out
		);

		// ��Χ����ļ�
		void clear_range(
			size_t begin_in,
			size_t size_in,
			mes::a_mes& mes_out
		);

		// ����Ϊ
		void save_as(
			str path,
			mes::a_mes& mes_out
		);

		//============================= ���ݽ��� =============================

		// ���ļ���ȡ���ݵ�����
		void load(
			size_t      load_begin_in,
			size_t      load_size_in,
			bin_file&   save_bin_file_in,
			size_t      store_begin_in,
			bool        safe,
			bool        flush_instantly,
			mes::a_mes& mes_out
		);

		// ����������д���ļ�
		void store(
			bin_file&   load_bin_file_in,
			size_t      load_begin_in,
			size_t      load_size_in,
			size_t      store_begin_in,
			bool        safe,
			bool        flush_instantly,
			mes::a_mes& mes_out
		);

		// ���������ݶ�ȡ������ָ��
		void load_to_agent_ptr(
			size_t           load_begin_in,
			size_t           load_size_in,
			bmms_f::agent_ptr& save_agent_ptr_in,
			size_t           store_begin_in,
			bool             safe,
			mes::a_mes&      mes_out
		);

		// �Ӵ���ָ���ȡ����д�뵽����
		void store_from_agent_ptr(
			bmms_f::agent_ptr& load_agent_ptr_in,
			size_t           load_begin_in,
			size_t           load_size_in,
			size_t           store_begin_in,
			bool             safe,
			bool             flush_instantly,
			mes::a_mes&      mes_out
		);

		// ���������ݶ���voidָ��
		void load_to_void_ptr(
			size_t      load_begin_in,
			size_t      load_size_in,
			void*       store_ptr_in,
			bool        safe,
			mes::a_mes& mes_out
		);

		// ��voidָ�������д������
		void store_from_void_ptr(
			void*       load_ptr_in,
			size_t      load_size_in,
			size_t      store_begin_in,
			bool        safe,
			mes::a_mes& mes_out
		);

		// ============================ ��Ϣ��ȡ���� ============================

		// ����ļ�����������Ч��
		bool __check_file_range__(size_t begin, size_t size);

		// ��������С��Ч��
		inline bool __check_op_size__(size_t size);

		// �����������Ƿ��ص�
		inline bool __check_range_overlap__(
			size_t self_begin, size_t self_size,
			size_t other_begin, size_t other_size
		);

		// ��������ļ��Ƿ�Ϊͬһ�ļ�����������������
		inline void __check_not_same_file_and_exit__(bin_file& other);

		inline bool   __check_inited__();
		inline bool   __same_file__(bin_file& other);
		inline size_t __file_size__();
		inline size_t __self_begin__();
		inline size_t __self_end__();
		inline size_t __op_begin__(size_t begin_in);
		inline size_t __op_end__(size_t op_begin_in, size_t op_size_in);

		// ====================== �������� ======================

		// ����δ��ʼ��״̬��������Դ��
		void __enter_uninitialized_state__();

		// �������´�ԭ�ļ������ʧ�������δ��ʼ��״̬
		void __try_reopen_and_enter_uninitialized_state__(mes::a_mes& mes_out);

		// ����ʧ��ʱ����Դ
		void __cleanup_on_failure__();

		// ============================ ������麯�� ============================
		// ǰ����
		inline bool no_overflow(size_t a, size_t b);

		// �ļ����ļ��������
		void check_basic_validity(
			size_t& self_op_begin,
			size_t& self_op_size,
			size_t& self_self_begin,
			size_t& self_self_end,
			size_t& other_op_begin,
			size_t& other_op_size,
			size_t& other_self_begin,
			size_t& other_self_end
		);

		void check_not_same_file(bin_file& other);

		void check_op_range_not_overlapping(
			size_t& self_op_begin,
			size_t& self_op_size,
			size_t& other_op_begin,
			size_t& other_op_size
		);

		// �ļ������ָ�뽻�����
		void check_file_to_agent_ptr_validity(
			size_t& file_op_begin,
			size_t& file_op_size,
			size_t& file_self_begin,
			size_t& file_self_end,
			bmms_f::agent_ptr& agent_ptr_in,
			size_t& agent_ptr_op_begin
		);

		void check_agent_ptr_to_file_validity(
			bmms_f::agent_ptr& agent_ptr_in,
			size_t& agent_ptr_op_begin,
			size_t& agent_ptr_op_size,
			size_t& file_op_begin,
			size_t& file_self_begin,
			size_t& file_self_end
		);

		// �ļ���voidָ�뽻�����
		void check_file_to_void_ptr_validity(
			size_t& file_op_begin,
			size_t& file_op_size,
			size_t& file_self_begin,
			size_t& file_self_end,
			void*& void_ptr_in
		);

		void check_void_ptr_to_file_validity(
			void*& void_ptr_in,
			size_t& void_ptr_op_size,
			size_t& file_op_begin,
			size_t& file_self_begin,
			size_t& file_self_end
		);

		#if defined(BFS_INCLUDE_TEST)
		void test();
		#endif

	private:
		bool inited = false;
		byte_1 fill[15];
		unique_ptr<std::fstream> filestream_ptr = nullptr;
		str  path = "";
	};

	class alignas(64) file_agent_ptr {
	public:
		friend class file_agent_ptr;

		//============================ ���� ============================

		// Ĭ�Ϲ��캯�� �õ���ָ��
		file_agent_ptr() = default;

		// ��bin_file ���캯��
		file_agent_ptr(
			const shared_ptr<bfs_f::bin_file>& bin_file_in,
			size_t           begin_in,
			size_t           size_in,
			bmms_f::agent_ptr& cache_agent_ptr_in,
			mes::a_mes& mes_out
		);

		~file_agent_ptr();

		// ���ÿ���
		file_agent_ptr(const file_agent_ptr&) = delete;
		file_agent_ptr& operator=(const file_agent_ptr&) = delete;

		// ֧���ƶ�
		file_agent_ptr(file_agent_ptr&& other) noexcept;
		file_agent_ptr& operator=(file_agent_ptr&& other) noexcept;

		//============================ ���ݿ��� ============================

		// �������
		void clear(
			mes::a_mes& mes_out
		);

		// ��Χ�������
		void clear_range(
			size_t begin_in,
			size_t size_in,
			mes::a_mes& mes_out
		);

		void push_cache_to_bin_file(
			mes::a_mes& mes_out
		);

		void pull_cache_from_bin_file(
			mes::a_mes& mes_out
		);

		//============================ ���ݽ��� ============================

		// ���������ݶ�ȡ��file_agent_ptr
		void load(
			size_t          load_begin_in,
			size_t          load_size_in,
			file_agent_ptr& save_file_agent_ptr_in,
			size_t          store_begin_in,
			bool            safe,
			mes::a_mes& mes_out
		);

		// ��file_agent_ptr��ȡ����д�뵽����
		void store(
			file_agent_ptr& load__file_agent_ptr_in,
			size_t          load_begin_in,
			size_t          load_size_in,
			size_t          store_begin_in,
			bool            safe,
			mes::a_mes& mes_out
		);

		// ���������ݶ�ȡ��agent_ptr
		void load_to_agent_ptr(
			size_t           load_begin_in,
			size_t           load_size_in,
			bmms_f::agent_ptr& save_agent_ptr_in,
			size_t           store_begin_in,
			bool             safe,
			mes::a_mes& mes_out
		);

		// ��agent_ptr��ȡ����д�뵽����
		void store_from_agent_ptr(
			bmms_f::agent_ptr& load_agent_ptr_in,
			size_t           load_begin_in,
			size_t           load_size_in,
			size_t           store_begin_in,
			bool             safe,
			mes::a_mes& mes_out
		);

		// ���������ݶ�ȡ��voidָ��
		void load_to_void_ptr(
			size_t      load_begin_in,
			size_t      load_size_in,
			void* store_ptr_in,
			bool        safe,
			mes::a_mes& mes_out
		);

		// ��voidָ�������д������
		void store_from_void_ptr(
			void* load_ptr_in,
			size_t      load_size_in,
			size_t      store_begin_in,
			bool        safe,
			mes::a_mes& mes_out
		);

		//============================ ���� ============================

#if defined(BFS_INCLUDE_TEST)
		void test();
#endif

		//============================ ��Ϣ��ȡ ============================

		// ����״̬��Ϣ
		void get_is_inited(bool& is_inited_out);
		void get_cache_begin_about_bin_file(size_t& begin_out);
		void get_cache_agent_ptr(bmms_f::agent_ptr& cache_agent_ptr_out);
		void get_cache_raw_ptr(void*& raw_ptr_out);
		void get_cache_size(size_t& cache_size_out);
		void get_dirty_flag(bool& is_dirty_out);
		void get_associated_bin_file_shared_ptr(
			shared_ptr<bfs_f::bin_file>& bin_file_out
		);
		void check_associated_with_bin_file_shared_ptr(
			shared_ptr<bfs_f::bin_file> bin_file_in,
			bool& is_associated_out,
			mes::a_mes& mes_out
		);

		// ���ָ���ļ���Χ�Ƿ��ڵ�ǰ������Χ��
		void check_file_range_in_managed(
			const shared_ptr<bfs_f::bin_file>& bin_file_in,
			size_t file_begin,
			size_t size_in,
			bool& is_in_managed_out,
			mes::a_mes& mes_out
		);

		void check_cache_range_in_managed(
			size_t cache_begin,
			size_t size_in,
			bool& is_in_managed_out,
			mes::a_mes& mes_out
		);

		// ��С��Ϣ
		void get_managed_file_size(
			size_t& managed_size_out,
			mes::a_mes& mes_out
		);

		void get_cache_used_size(
			size_t& used_size_out,
			mes::a_mes& mes_out
		);

		// ��Ч�Լ��
		void check_file_still_valid(
			bool& is_valid_out,
			mes::a_mes& mes_out
		);

		// λ��ӳ��
		void calculate_cache_position(
			size_t file_absolute_pos,
			size_t& cache_pos_out,
			bool& is_mappable_out,
			mes::a_mes& mes_out
		);

		// λ��ӳ��
		void calculate_file_position(
			size_t cache_pos,
			size_t& file_absolute_pos_out,
			bool& is_mappable_out,
			mes::a_mes& mes_out
		);

		//============================ ����У�� ============================
		bool __check_self_valid__(
			mes::a_mes& mes_out
		);
		bool __check_file_range_valid__(
			bfs_f::bin_file& file_in,
			size_t& file_begin,
			size_t& size_in,
			mes::a_mes& mes_out
		);
		bool __check_cache_range_valid__(
			size_t& cache_begin,
			size_t& size_in,
			mes::a_mes& mes_out
		);
		bool __check_two_fap_compatible__(
			file_agent_ptr& other_fap,
			size_t& self_cache_begin,
			size_t& other_cache_begin,
			size_t& size_in,
			mes::a_mes& mes_out
		);

	private:

		bmms_f::agent_ptr cache_ptr = bmms_f::agent_ptr();
		shared_ptr<bfs_f::bin_file> bin_file_shared_ptr = nullptr;
		size_t cache_begin_about_bin_file = 0;
		bool   inited = false;
		bool   dirty = false;
		byte_1 fill[\
			64       \
			- sizeof(bmms_f::agent_ptr) \
			- sizeof(shared_ptr<bfs_f::bin_file>) \
			- sizeof(size_t) \
			- sizeof(bool) * 2 \
		];

		// ˽�и�������
		void __mark_dirty__();
		void __clear_dirty__();
		void __cleanup_on_construct_failure__();
	};

	namespace dir_control {

		void add_dir(
			str path,
			mes::a_mes& mes_out
		);

		void del(
			str path,
			mes::a_mes& mes_out
		);

		void get_dir_list(
			str path,
			vector<str>& dir_list_path_out,
			mes::a_mes& mes_out
		);

		void get_list_file(
			str path,
			vector<str>& file_list_path_out,
			mes::a_mes&  mes_out
		);
		
		void get_path_is_excited(
			str path,
			bool& is_excited_out,
			mes::a_mes& mes_out
		);

		void get_is_dir(
			str path,
			bool& is_dir_out,
			mes::a_mes& mes_out
		);

		void get_is_file(
			str path,
			bool& is_file_out,
			mes::a_mes& mes_out
		);

		void get_accessible(
			str path,
			bool& accessible_out,
			mes::a_mes& mes_out
		);

		void rename_file(
			str old_path,
			str new_path,
			mes::a_mes& mes_out,
			bool overwrite = false
		);

		#if defined(BFS_INCLUDE_TEST)
		void test();
		#endif
	};
};