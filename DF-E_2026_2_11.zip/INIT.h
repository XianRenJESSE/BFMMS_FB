﻿
// MODE_CODE_INIT
#define EXAMPLE_MODE_CODE       0
#define MOD_CODE_TEST           1
#define MOD_CODE_MES            2
#define MOD_CODE_AGENT_PTR      3
#define MOD_CODE_BFS           4
#define MOD_CODE_BFS_AGENT_PTR 5
#define MOD_CODE_BMMS         6


// MES
#define DEBUG_MODE
#define SHOW_STATIC_STR_MESSAGE  //存储静态字符串消息
#define SHOW_DYNAMIC_STR_MESSAGE //存储动态字符串消息
#define SHOW_CALL_CHAIN_MESSAGE  //显示调用链信息


// AGENT_PTR
#define AGENT_PTR_INCLUDE_TEST  //启用 agent_ptr::test()

//BFS
#define BFS_INCLUDE_TEST       //启用bin_file::test()

//BFS_AGENT_PTR
#define BFS_INCLUDE_TEST //启用file_agent_ptr::test()

//VOLUME
#define VOLUME_INCLUDE_TEST
#define STATIC_VOLUME_MAX_BLOCK_SIZE  1024*1024
#define STATIC_VOLUME_MAX_BLOCK_COUNT 1024*1024*1024