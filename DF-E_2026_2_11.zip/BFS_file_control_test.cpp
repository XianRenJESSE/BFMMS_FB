﻿//file_file_control_test.cpp

module BFS;

#include "BFS_dp.h"

namespace bfs_f::dir_control {
#if defined(BFS_INCLUDE_TEST)

    // 辅助函数：打印测试信息
    void print_test(const std::string& msg) {
        std::cout << msg << endl;
    }

    // 辅助函数：创建测试目录
    bool create_test_dir(const std::string& path) {
        try {
            std::filesystem::create_directories(path);
            return true;
        }
        catch (...) {
            return false;
        }
    }

    // 辅助函数：创建测试文件
    bool create_test_file(const std::string& path, const std::string& content = "") {
        try {
            std::ofstream f(path);
            if (f.is_open()) {
                if (!content.empty()) {
                    f << content;
                }
                return true;
            }
            return false;
        }
        catch (...) {
            return false;
        }
    }

    // 辅助函数：清理测试路径
    void cleanup_test_path(const std::string& path) {
        try {
            if (std::filesystem::exists(path)) {
                std::filesystem::remove_all(path);
            }
        }
        catch (...) {
            // 忽略清理错误
        }
    }

    // 辅助函数：验证目录内容
    bool verify_dir_contents(const std::string& path, size_t expected_files = 0, size_t expected_dirs = 0) {
        try {
            if (!std::filesystem::exists(path) || !std::filesystem::is_directory(path)) {
                return false;
            }

            size_t file_count = 0;
            size_t dir_count = 0;

            for (const auto& entry : std::filesystem::directory_iterator(path)) {
                if (std::filesystem::is_regular_file(entry.status())) {
                    file_count++;
                }
                else if (std::filesystem::is_directory(entry.status())) {
                    dir_count++;
                }
            }

            return (file_count == expected_files) && (dir_count == expected_dirs);
        }
        catch (...) {
            return false;
        }
    }

    // 辅助函数：打印错误信息
    void print_error(const mes::a_mes& mes_out, const std::string& operation) {
        if (mes_out.code != 0) {
            print_test("  " + operation + " 失败: MODC=" + to_string(mes_out.mode_code) +
                " MESC=" + to_string(mes_out.code) + " " + mes_out.message);
        }
    }

    // 辅助函数：比较两个向量中的字符串（忽略顺序）
    bool compare_string_vectors(const vector<str>& v1, const vector<str>& v2) {
        if (v1.size() != v2.size()) {
            return false;
        }

        auto sorted1 = v1;
        auto sorted2 = v2;
        std::sort(sorted1.begin(), sorted1.end());
        std::sort(sorted2.begin(), sorted2.end());

        return sorted1 == sorted2;
    }

    // 主测试函数
    void test() {
        print_test("========== DIR_CONTROL 测试开始 ==========\n");

        // 创建主测试目录
        std::string main_test_dir = "C:/lib/cache/dir_control_test/";
        create_test_dir(main_test_dir);

        // ============================ add_dir 测试 ============================
        print_test("\n1. add_dir 测试：");

        print_test("1.1 创建新目录");
        {
            std::string test_dir = main_test_dir + "test_add_dir/";
            cleanup_test_path(test_dir);

            mes::a_mes mes_out;
            add_dir(test_dir, mes_out);

            if (mes_out.code == 0 && std::filesystem::exists(test_dir)) {
                print_test("  创建新目录成功");
            }
            else {
                print_error(mes_out, "创建新目录");
            }
        }

        print_test("1.2 递归创建多级目录");
        {
            std::string deep_dir = main_test_dir + "level1/level2/level3/";
            cleanup_test_path(main_test_dir + "level1");

            mes::a_mes mes_out;
            add_dir(deep_dir, mes_out);

            if (mes_out.code == 0 && std::filesystem::exists(deep_dir)) {
                print_test("  递归创建目录成功");
            }
            else {
                print_error(mes_out, "递归创建目录");
            }
        }

        print_test("1.3 创建已存在的目录（幂等性）");
        {
            std::string existing_dir = main_test_dir + "existing_dir/";
            create_test_dir(existing_dir);

            mes::a_mes mes_out;
            add_dir(existing_dir, mes_out);

            if (mes_out.code == 0 && std::filesystem::exists(existing_dir)) {
                print_test("  创建已存在目录成功（幂等）");
            }
            else {
                print_error(mes_out, "创建已存在目录");
            }
        }

        print_test("1.4 创建已存在文件的位置（应失败）");
        {
            std::string file_path = main_test_dir + "existing_file.txt";
            create_test_file(file_path);

            mes::a_mes mes_out;
            add_dir(file_path, mes_out);

            if (mes_out.code != 0) {
                print_test("  正确检测到路径已存在且不是目录");
            }
            else {
                print_test("  未检测到路径冲突 - 错误");
            }
        }

        print_test("1.5 创建到空路径（编码错误）");
        {
            try {
                mes::a_mes mes_out;
                add_dir("", mes_out);
                print_test("  未捕获异常 - 错误");
            }
            catch (mes::a_mes e) {
                print_test("  捕获异常 - 正常: " + e.message);
            }
        }

        print_test("1.6 创建到无效路径");
        {
            std::string invalid_path = "C:/invalid/path/with/*/illegal/chars/";
            mes::a_mes mes_out;
            add_dir(invalid_path, mes_out);

            if (mes_out.code != 0) {
                print_test("  正确检测到无效路径");
            }
            else {
                print_test("  未检测到无效路径 - 错误");
            }
        }

        // ============================ del 测试 ============================
        print_test("\n2. del 测试：");

        print_test("2.1 删除文件");
        {
            std::string test_file = main_test_dir + "file_to_delete.txt";
            create_test_file(test_file);

            mes::a_mes mes_out;
            del(test_file, mes_out);

            if (mes_out.code == 0 && !std::filesystem::exists(test_file)) {
                print_test("  删除文件成功");
            }
            else {
                print_error(mes_out, "删除文件");
            }
        }

        print_test("2.2 删除空目录");
        {
            std::string empty_dir = main_test_dir + "empty_dir_to_delete/";
            create_test_dir(empty_dir);

            mes::a_mes mes_out;
            del(empty_dir, mes_out);

            if (mes_out.code == 0 && !std::filesystem::exists(empty_dir)) {
                print_test("  删除空目录成功");
            }
            else {
                print_error(mes_out, "删除空目录");
            }
        }

        print_test("2.3 删除非空目录（递归删除）");
        {
            std::string non_empty_dir = main_test_dir + "non_empty_dir/";
            std::string sub_dir = non_empty_dir + "subdir/";
            std::string file1 = non_empty_dir + "file1.txt";
            std::string file2 = sub_dir + "file2.txt";

            create_test_dir(sub_dir);
            create_test_file(file1);
            create_test_file(file2);

            mes::a_mes mes_out;
            del(non_empty_dir, mes_out);

            if (mes_out.code == 0 && !std::filesystem::exists(non_empty_dir)) {
                print_test("  递归删除非空目录成功");
            }
            else {
                print_error(mes_out, "递归删除非空目录");
            }
        }

        print_test("2.4 删除不存在的路径（幂等性）");
        {
            std::string non_existent = main_test_dir + "non_existent_path/";
            cleanup_test_path(non_existent);

            mes::a_mes mes_out;
            del(non_existent, mes_out);

            if (mes_out.code == 0) {
                print_test("  删除不存在路径成功（幂等）");
            }
            else {
                print_error(mes_out, "删除不存在路径");
            }
        }

        print_test("2.5 删除到空路径（编码错误）");
        {
            try {
                mes::a_mes mes_out;
                del("", mes_out);
                print_test("  未捕获异常 - 错误");
            }
            catch (mes::a_mes e) {
                print_test("  捕获异常 - 正常: " + e.message);
            }
        }

        // ============================ get_dir_list 测试 ============================
        print_test("\n3. get_dir_list 测试：");

        print_test("3.1 获取空目录列表");
        {
            std::string empty_dir = main_test_dir + "list_empty_dir/";
            create_test_dir(empty_dir);

            vector<str> dir_list;
            mes::a_mes mes_out;
            get_dir_list(empty_dir, dir_list, mes_out);

            if (mes_out.code == 0 && dir_list.empty()) {
                print_test("  获取空目录列表成功");
            }
            else {
                print_error(mes_out, "获取空目录列表");
            }
        }

        print_test("3.2 获取包含子目录的列表");
        {
            std::string parent_dir = main_test_dir + "parent_dir/";
            std::string subdir1 = parent_dir + "subdir1/";
            std::string subdir2 = parent_dir + "subdir2/";
            std::string file1 = parent_dir + "file1.txt";

            create_test_dir(subdir1);
            create_test_dir(subdir2);
            create_test_file(file1);

            vector<str> dir_list;
            mes::a_mes mes_out;
            get_dir_list(parent_dir, dir_list, mes_out);

            if (mes_out.code == 0 && dir_list.size() == 2) {
                print_test("  获取包含子目录的列表成功，找到 " + to_string(dir_list.size()) + " 个子目录");

                // 验证返回的是正确的子目录
                vector<str> expected_paths = { subdir1, subdir2 };
                if (compare_string_vectors(dir_list, expected_paths)) {
                    print_test("  验证通过：返回正确的子目录列表");
                }
            }
            else {
                print_error(mes_out, "获取包含子目录的列表");
            }
        }

        print_test("3.3 获取不存在目录的列表");
        {
            std::string non_existent = main_test_dir + "non_existent_for_list/";
            cleanup_test_path(non_existent);

            vector<str> dir_list;
            mes::a_mes mes_out;
            get_dir_list(non_existent, dir_list, mes_out);

            if (mes_out.code != 0) {
                print_test("  正确检测到目录不存在");
            }
            else {
                print_test("  未检测到目录不存在 - 错误");
            }
        }

        print_test("3.4 获取文件而不是目录的列表");
        {
            std::string file_path = main_test_dir + "file_not_dir.txt";
            create_test_file(file_path);

            vector<str> dir_list;
            mes::a_mes mes_out;
            get_dir_list(file_path, dir_list, mes_out);

            if (mes_out.code != 0) {
                print_test("  正确检测到路径不是目录");
            }
            else {
                print_test("  未检测到路径不是目录 - 错误");
            }
        }

        // ============================ get_list_file 测试 ============================
        print_test("\n4. get_list_file 测试：");

        print_test("4.1 获取空目录的文件列表");
        {
            std::string empty_dir = main_test_dir + "file_list_empty/";
            create_test_dir(empty_dir);

            vector<str> file_list;
            mes::a_mes mes_out;
            get_list_file(empty_dir, file_list, mes_out);

            if (mes_out.code == 0 && file_list.empty()) {
                print_test("  获取空目录文件列表成功");
            }
            else {
                print_error(mes_out, "获取空目录文件列表");
            }
        }

        print_test("4.2 获取包含文件的列表");
        {
            std::string dir_with_files = main_test_dir + "dir_with_files/";
            std::string file1 = dir_with_files + "file1.txt";
            std::string file2 = dir_with_files + "file2.txt";
            std::string subdir = dir_with_files + "subdir/";

            create_test_dir(dir_with_files);
            create_test_file(file1);
            create_test_file(file2);
            create_test_dir(subdir);

            vector<str> file_list;
            mes::a_mes mes_out;
            get_list_file(dir_with_files, file_list, mes_out);

            if (mes_out.code == 0 && file_list.size() == 2) {
                print_test("  获取包含文件的列表成功，找到 " + to_string(file_list.size()) + " 个文件");

                // 验证列表排序
                if (std::is_sorted(file_list.begin(), file_list.end())) {
                    print_test("  验证通过：文件列表已排序");
                }
            }
            else {
                print_error(mes_out, "获取包含文件的列表");
            }
        }

        // ============================ get_path_is_excited 测试 ============================
        print_test("\n5. get_path_is_excited 测试：");

        print_test("5.1 检查存在的目录");
        {
            std::string existing_dir = main_test_dir + "check_existing_dir/";
            create_test_dir(existing_dir);

            bool exists = false;
            mes::a_mes mes_out;
            get_path_is_excited(existing_dir, exists, mes_out);

            if (mes_out.code == 0 && exists) {
                print_test("  检查存在的目录成功");
            }
            else {
                print_error(mes_out, "检查存在的目录");
            }
        }

        print_test("5.2 检查存在的文件");
        {
            std::string existing_file = main_test_dir + "check_existing_file.txt";
            create_test_file(existing_file);

            bool exists = false;
            mes::a_mes mes_out;
            get_path_is_excited(existing_file, exists, mes_out);

            if (mes_out.code == 0 && exists) {
                print_test("  检查存在的文件成功");
            }
            else {
                print_error(mes_out, "检查存在的文件");
            }
        }

        print_test("5.3 检查不存在的路径");
        {
            std::string non_existent = main_test_dir + "non_existent_check/";
            cleanup_test_path(non_existent);

            bool exists = false;
            mes::a_mes mes_out;
            get_path_is_excited(non_existent, exists, mes_out);

            if (mes_out.code == 0 && !exists) {
                print_test("  检查不存在的路径成功");
            }
            else {
                print_error(mes_out, "检查不存在的路径");
            }
        }

        // ============================ get_is_dir 测试 ============================
        print_test("\n6. get_is_dir 测试：");

        print_test("6.1 检查目录");
        {
            std::string test_dir = main_test_dir + "is_dir_test/";
            create_test_dir(test_dir);

            bool is_dir = false;
            mes::a_mes mes_out;
            get_is_dir(test_dir, is_dir, mes_out);

            if (mes_out.code == 0 && is_dir) {
                print_test("  检查目录成功");
            }
            else {
                print_error(mes_out, "检查目录");
            }
        }

        print_test("6.2 检查文件（应返回false）");
        {
            std::string test_file = main_test_dir + "is_dir_file.txt";
            create_test_file(test_file);

            bool is_dir = true; // 初始设为true，测试是否被正确设为false
            mes::a_mes mes_out;
            get_is_dir(test_file, is_dir, mes_out);

            if (mes_out.code == 0 && !is_dir) {
                print_test("  检查文件返回false（正确）");
            }
            else {
                print_error(mes_out, "检查文件");
            }
        }

        print_test("6.3 检查不存在的路径");
        {
            std::string non_existent = main_test_dir + "non_existent_is_dir/";
            cleanup_test_path(non_existent);

            bool is_dir = false;
            mes::a_mes mes_out;
            get_is_dir(non_existent, is_dir, mes_out);

            if (mes_out.code == 0 && !is_dir) {
                print_test("  检查不存在的路径返回false（正确）");
            }
            else {
                print_error(mes_out, "检查不存在的路径");
            }
        }

        // ============================ get_is_file 测试 ============================
        print_test("\n7. get_is_file 测试：");

        print_test("7.1 检查普通文件");
        {
            std::string test_file = main_test_dir + "is_file_test.txt";
            create_test_file(test_file);

            bool is_file = false;
            mes::a_mes mes_out;
            get_is_file(test_file, is_file, mes_out);

            if (mes_out.code == 0 && is_file) {
                print_test("  检查普通文件成功");
            }
            else {
                print_error(mes_out, "检查普通文件");
            }
        }

        print_test("7.2 检查目录（应返回false）");
        {
            std::string test_dir = main_test_dir + "is_file_dir/";
            create_test_dir(test_dir);

            bool is_file = true; // 初始设为true，测试是否被正确设为false
            mes::a_mes mes_out;
            get_is_file(test_dir, is_file, mes_out);

            if (mes_out.code == 0 && !is_file) {
                print_test("  检查目录返回false（正确）");
            }
            else {
                print_error(mes_out, "检查目录");
            }
        }

        // ============================ get_accessible 测试 ============================
        print_test("\n8. get_accessible 测试：");

        print_test("8.1 检查可访问的目录");
        {
            std::string accessible_dir = main_test_dir + "accessible_dir/";
            create_test_dir(accessible_dir);

            bool accessible = false;
            mes::a_mes mes_out;
            get_accessible(accessible_dir, accessible, mes_out);

            if (mes_out.code == 0 && accessible) {
                print_test("  检查可访问目录成功");
            }
            else {
                print_error(mes_out, "检查可访问目录");
            }
        }

        print_test("8.2 检查可访问的文件");
        {
            std::string accessible_file = main_test_dir + "accessible_file.txt";
            create_test_file(accessible_file);

            bool accessible = false;
            mes::a_mes mes_out;
            get_accessible(accessible_file, accessible, mes_out);

            if (mes_out.code == 0 && accessible) {
                print_test("  检查可访问文件成功");
            }
            else {
                print_error(mes_out, "检查可访问文件");
            }
        }

        print_test("8.3 检查不存在的路径");
        {
            std::string non_existent = main_test_dir + "non_existent_accessible/";
            cleanup_test_path(non_existent);

            bool accessible = false;
            mes::a_mes mes_out;
            get_accessible(non_existent, accessible, mes_out);

            if (mes_out.code == 0 && !accessible) {
                print_test("  检查不存在的路径返回false（正确）");
            }
            else {
                print_error(mes_out, "检查不存在的路径");
            }
        }

        // ============================ 综合测试 ============================
        print_test("\n9. 综合测试：");

        print_test("9.1 完整目录生命周期测试");
        {
            std::string test_root = main_test_dir + "full_lifecycle/";
            cleanup_test_path(test_root);

            mes::a_mes mes_out;
            bool all_passed = true;

            // 阶段1：创建目录结构
            print_test("  阶段1: 创建目录结构");
            add_dir(test_root + "subdir1/subsubdir/", mes_out);
            if (mes_out.code != 0) {
                print_error(mes_out, "创建子目录");
                all_passed = false;
            }

            add_dir(test_root + "subdir2/", mes_out);
            if (mes_out.code != 0) {
                print_error(mes_out, "创建子目录2");
                all_passed = false;
            }

            // 创建文件
            create_test_file(test_root + "file1.txt", "content1");
            create_test_file(test_root + "subdir1/file2.txt", "content2");
            create_test_file(test_root + "subdir1/subsubdir/file3.txt", "content3");

            // 阶段2：验证目录结构
            if (all_passed) {
                print_test("  阶段2: 验证目录结构");

                // 检查根目录存在
                bool root_exists = false;
                get_path_is_excited(test_root, root_exists, mes_out);
                if (!root_exists) {
                    print_test("    根目录不存在 - 失败");
                    all_passed = false;
                }

                // 获取子目录列表
                vector<str> dir_list;
                get_dir_list(test_root, dir_list, mes_out);
                if (mes_out.code == 0 && dir_list.size() >= 2) {
                    print_test("    找到 " + to_string(dir_list.size()) + " 个子目录");
                }
                else {
                    print_test("    获取子目录列表失败");
                    all_passed = false;
                }

                // 获取文件列表
                vector<str> file_list;
                get_list_file(test_root, file_list, mes_out);
                if (mes_out.code == 0 && file_list.size() >= 1) {
                    print_test("    找到 " + to_string(file_list.size()) + " 个文件");
                }
                else {
                    print_test("    获取文件列表失败");
                    all_passed = false;
                }
            }

            // 阶段3：检查路径类型
            if (all_passed) {
                print_test("  阶段3: 检查路径类型");

                bool is_dir = false;
                bool is_file = false;

                get_is_dir(test_root, is_dir, mes_out);
                get_is_file(test_root + "file1.txt", is_file, mes_out);

                if (is_dir && is_file) {
                    print_test("    路径类型检查通过");
                }
                else {
                    print_test("    路径类型检查失败");
                    all_passed = false;
                }
            }

            // 阶段4：检查可访问性
            if (all_passed) {
                print_test("  阶段4: 检查可访问性");

                bool accessible = false;
                get_accessible(test_root, accessible, mes_out);

                if (accessible) {
                    print_test("    可访问性检查通过");
                }
                else {
                    print_test("    可访问性检查失败");
                    all_passed = false;
                }
            }

            // 阶段5：清理
            if (all_passed) {
                print_test("  阶段5: 清理目录");
                del(test_root, mes_out);

                if (mes_out.code == 0) {
                    // 验证清理
                    bool root_exists = false;
                    get_path_is_excited(test_root, root_exists, mes_out);
                    if (!root_exists) {
                        print_test("    清理验证通过");
                    }
                    else {
                        print_test("    清理验证失败 - 目录仍然存在");
                    }
                }
                else {
                    print_error(mes_out, "清理目录");
                }
            }

            if (all_passed) {
                print_test("  目录生命周期测试完成 - 全部通过");
            }
            else {
                print_test("  目录生命周期测试完成 - 部分失败");
            }
        }

        print_test("9.2 错误恢复测试");
        {
            std::string test_dir = main_test_dir + "error_recovery/";
            create_test_dir(test_dir);

            mes::a_mes mes_out;

            // 触发一个错误（检查不存在的路径）
            bool exists = false;
            get_path_is_excited(test_dir + "non_existent", exists, mes_out);

            if (mes_out.code == 0 && !exists) {
                print_test("  第一个操作成功");

                // 立即执行另一个操作（测试错误恢复）
                mes_out = mes::a_mes(0, 0, ""); // 重置消息

                vector<str> dir_list;
                get_dir_list(test_dir, dir_list, mes_out);

                if (mes_out.code == 0) {
                    print_test("  错误后成功恢复并执行新操作");
                }
                else {
                    print_error(mes_out, "错误恢复");
                }
            }

            del(test_dir, mes_out);
        }

        print_test("9.3 批量操作测试");
        {
            std::string batch_dir = main_test_dir + "batch_test/";
            cleanup_test_path(batch_dir);

            create_test_dir(batch_dir);

            // 批量创建目录
            print_test("  批量创建10个目录");
            for (int i = 0; i < 10; i++) {
                std::string subdir = batch_dir + "dir" + to_string(i) + "/";
                mes::a_mes mes_out;
                add_dir(subdir, mes_out);

                if (mes_out.code != 0) {
                    print_error(mes_out, "批量创建目录 " + to_string(i));
                    break;
                }
            }

            // 批量创建文件
            print_test("  批量创建10个文件");
            for (int i = 0; i < 10; i++) {
                std::string file = batch_dir + "file" + to_string(i) + ".txt";
                create_test_file(file, "test data " + to_string(i));
            }

            // 验证批量创建
            vector<str> dir_list;
            vector<str> file_list;
            mes::a_mes mes_out;

            get_dir_list(batch_dir, dir_list, mes_out);
            get_list_file(batch_dir, file_list, mes_out);

            if (mes_out.code == 0 && dir_list.size() == 10 && file_list.size() == 10) {
                print_test("  批量操作验证成功");
            }

            // 清理
            del(batch_dir, mes_out);
        }

        // ============================ 边界值测试 ============================
        print_test("\n10. 边界值测试：");

        print_test("10.1 长路径测试");
        {
            std::string long_path = main_test_dir;
            for (int i = 0; i < 5; ++i) { // 减少层级避免路径过长
                long_path += "long_dir_name_" + to_string(i) + "/";
            }

            mes::a_mes mes_out;
            add_dir(long_path, mes_out);

            if (mes_out.code == 0) {
                print_test("  长路径创建成功");

                // 验证
                bool exists = false;
                get_path_is_excited(long_path, exists, mes_out);
                if (exists) {
                    print_test("  长路径验证成功");
                }

                // 清理
                del(long_path, mes_out);
            }
            else {
                print_error(mes_out, "长路径测试");
            }
        }

        print_test("10.2 特殊字符路径测试");
        {
            // 使用安全的特殊字符
            std::string special_path = main_test_dir + "test_dir_with-spaces_and-dashes/";

            mes::a_mes mes_out;
            add_dir(special_path, mes_out);

            if (mes_out.code == 0) {
                print_test("  特殊字符路径创建成功");

                // 验证其他操作
                vector<str> dir_list;
                get_dir_list(main_test_dir, dir_list, mes_out);

                if (mes_out.code == 0) {
                    print_test("  特殊字符路径操作验证成功");
                }

                del(special_path, mes_out);
            }
            else {
                print_test("  特殊字符路径测试: " + mes_out.message);
            }
        }
        // ============================ 重命名测试 ============================

        print_test("11. 重命名测试：");

        print_test("11.1 正常文件重命名");
        {
            std::string test_dir = "C:/lib/cache";
            std::string old_file = test_dir + "old_name.txt";
            std::string new_file = test_dir + "new_name.txt";
            create_test_file(old_file, "test data");
            cleanup_test_path(new_file);

            mes::a_mes mes_out;
            dir_control::rename_file(old_file, new_file, mes_out, false);

            if (mes_out.code == 0 &&
                !f_s::exists(old_file) &&
                f_s::exists(new_file)) {
                print_test("  重命名成功");
            }
        }

        print_test("11.2 重命名到已存在文件（不覆盖）");
        {
            std::string test_dir = "C:/lib/cache";
            std::string file1 = test_dir + "file1.txt";
            std::string file2 = test_dir + "file2.txt";
            create_test_file(file1, "data1");
            create_test_file(file2, "data2");

            mes::a_mes mes_out;
            dir_control::rename_file(file1, file2, mes_out, false);

            if (mes_out.code != 0) {
                print_test("  正确拒绝覆盖");
            }
            cleanup_test_path(test_dir);
        }

        // ============================ 清理测试文件 ============================
        print_test("\n清理测试文件...");
        try {
            std::filesystem::remove_all(main_test_dir);
            print_test("清理完成");
        }
        catch (...) {
            print_test("清理失败");
        }

        print_test("\n========== DIR_CONTROL 测试结束 ==========\n");
    }

#endif // BFS_INCLUDE_TEST
}