﻿// file_agent_ptr_test.cpp
module BFS;

#include "BFS_dp.h"
#include "BMMS_dp.h"

namespace bfs_f {
#if defined(BFS_INCLUDE_TEST)

    // 辅助函数：打印测试信息
    void print_(const str& msg) {
        std::cout << msg << endl;
    }

    // 辅助函数：创建测试目录
    bool create_test_directory(const str& path) {
        try {
            std::filesystem::create_directories(path);
            return true;
        }
        catch (...) {
            return false;
        }
    }

    // 辅助函数：清理测试文件
    void cleanup_test_file(const str& path) {
        try {
            if (std::filesystem::exists(path)) {
                std::filesystem::remove(path);
            }
        }
        catch (...) {
            // 忽略清理错误
        }
    }

    // 辅助函数：比较两个内存区域
    bool compare_memory(void* ptr1, void* ptr2, size_t size) {
        return memcmp(ptr1, ptr2, size) == 0;
    }

    void file_agent_ptr::test() {
        print_("========== BFS_AGENT_PTR 测试开始 ==========\n");

        // 创建测试目录
        str test_dir = "C:/lib/cache/fap_test/";
        create_test_directory(test_dir);

        // ============================ 构造函数测试 ============================
        print_("\n1. 构造函数测试：\n");

        print_("1.1 正常构造测试");
        {
            str test_file = test_dir + "test_construct.txt";
            cleanup_test_file(test_file);

            // 创建基础文件
            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            if (mes_out.code != 0) {
                print_("  基础文件创建失败: " + mes_out.message);
                return;
            }

            // 创建缓存代理指针
            vector<byte_1> cache_buffer(1024);
            bmms_f::agent_ptr cache_agent(cache_buffer.data(), 1024);

            // 创建 file_agent_ptr
            file_agent_ptr fap(bin_file_ptr, 0, 1024, cache_agent, mes_out);

            if (mes_out.code == 0) {
                // 验证初始化状态
                bool inited = false;
                fap.get_is_inited(inited);
                if (inited) {
                    print_("  正常构造通过");
                }
                else {
                    print_("  构造失败：未正确初始化");
                }
            }
            else {
                print_("  构造失败: " + mes_out.message);
            }

            // 清理
            bin_file_ptr->close(mes_out);
        }

        print_("1.2 构造测试 - 缓存大小不足");
        {
            str test_file = test_dir + "test_construct_small_cache.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            if (mes_out.code != 0) {
                print_("  基础文件创建失败: " + mes_out.message);
                return;
            }

            // 创建过小的缓存代理指针
            vector<byte_1> small_buffer(512); // 只有512字节
            bmms_f::agent_ptr small_agent(small_buffer.data(), 512);

            // 尝试构造（应该失败）
            file_agent_ptr fap(bin_file_ptr, 0, 1024, small_agent, mes_out);

            if (mes_out.code != 0) {
                print_("  正确检测到缓存大小不足: " + mes_out.message);
            }
            else {
                print_("  未检测到缓存大小不足 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("1.3 构造测试 - 文件范围越界");
        {
            str test_file = test_dir + "test_construct_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            if (mes_out.code != 0) {
                print_("  基础文件创建失败: " + mes_out.message);
                return;
            }

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);

            // 尝试从超出文件范围的位置开始（应该失败）
            file_agent_ptr fap(bin_file_ptr, 800, 500, agent, mes_out); // 800+500>1024

            if (mes_out.code != 0) {
                print_("  正确检测到文件范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到文件范围越界 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("1.4 构造测试 - 文件未打开");
        {
            str test_file = test_dir + "test_construct_not_open.txt";
            cleanup_test_file(test_file);

            // 创建一个未打开的bin_file共享指针
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>();

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);

            mes::a_mes mes_out;
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            if (mes_out.code != 0) {
                print_("  正确检测到文件未打开: " + mes_out.message);
            }
            else {
                print_("  未检测到文件未打开 - 错误");
            }
        }

        print_("1.5 构造测试 - 空代理指针");
        {
            str test_file = test_dir + "test_construct_null_agent.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            if (mes_out.code != 0) {
                print_("  基础文件创建失败: " + mes_out.message);
                return;
            }

            // 空代理指针
            bmms_f::agent_ptr null_agent;

            file_agent_ptr fap(bin_file_ptr, 0, 1024, null_agent, mes_out);

            if (mes_out.code != 0) {
                print_("  正确检测到空代理指针: " + mes_out.message);
            }
            else {
                print_("  未检测到空代理指针 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("1.6 构造测试 - 零大小范围");
        {
            str test_file = test_dir + "test_construct_zero_size.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            if (mes_out.code != 0) {
                print_("  基础文件创建失败: " + mes_out.message);
                return;
            }

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);

            file_agent_ptr fap(bin_file_ptr, 0, 0, agent, mes_out);

            if (mes_out.code != 0) {
                print_("  正确检测到零大小范围: " + mes_out.message);
            }
            else {
                print_("  未检测到零大小范围 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        // ============================ 移动构造和移动赋值测试 ============================
        print_("\n2. 移动操作测试：\n");

        print_("2.1 移动构造测试 - 修复版");
        {
            str test_file = test_dir + "test_move_construct_fixed.txt";
            cleanup_test_file(test_file);

            // 创建原始对象
            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap1(bin_file_ptr, 0, 1024, agent, mes_out);

            print_("  步骤1: 创建FAP完成");

            // 检查初始状态
            bool inited1 = false;
            bool dirty1 = false;
            fap1.get_is_inited(inited1);
            fap1.get_dirty_flag(dirty1);
            print_("  初始状态 - inited: " + to_string(inited1) + ", dirty: " + to_string(dirty1));

            // 使用不同的源数据（避免内存重叠）
            vector<byte_1> source_data(1024);
            memset(source_data.data(), 0xBB, 1024);
            print_("  步骤2: 准备源数据完成");

            // 通过store操作标记为脏（源和目标不同，不会重叠）
            fap1.store_from_void_ptr(source_data.data(), 1024, 0, true, mes_out);
            print_("  步骤3: store_from_void_ptr调用完成, mes_out.code: " + to_string(mes_out.code) +
                ", message: " + mes_out.message);

            // 再次检查状态
            fap1.get_dirty_flag(dirty1);
            print_("  存储后状态 - dirty: " + to_string(dirty1));

            if (dirty1) {
                print_("   脏标志正确设置");

                // 验证数据是否正确存储
                vector<byte_1> verify_buffer(1024);
                fap1.load_to_void_ptr(0, 1024, verify_buffer.data(), true, mes_out);

                bool data_correct = (memcmp(source_data.data(), verify_buffer.data(), 1024) == 0);
                print_("  数据验证: " + to_string(data_correct));

                // 移动构造
                file_agent_ptr fap2 = move(fap1);

                // 检查新对象状态
                bool inited2 = false;
                bool dirty2 = false;
                fap2.get_is_inited(inited2);
                fap2.get_dirty_flag(dirty2);

                print_("  移动构造后 - 新对象inited: " + to_string(inited2) + ", dirty: " + to_string(dirty2));

                if (inited2 && dirty2) {
                    print_("   移动构造成功，脏标志正确转移");
                }
                else {
                    print_("   移动构造失败");
                }
            }
            else {
                print_("   脏标志未设置");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("2.2 移动赋值测试");
        {
            str test_file1 = test_dir + "test_move_assign1.txt";
            str test_file2 = test_dir + "test_move_assign2.txt";
            cleanup_test_file(test_file1);
            cleanup_test_file(test_file2);

            // 创建两个对象
            mes::a_mes mes_out;

            shared_ptr<bfs_f::bin_file> bin_file1 = make_shared<bfs_f::bin_file>(
                test_file1, 1024, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer1(1024);
            bmms_f::agent_ptr agent1(buffer1.data(), 1024);
            file_agent_ptr fap1(bin_file1, 0, 1024, agent1, mes_out);

            shared_ptr<bfs_f::bin_file> bin_file2 = make_shared<bfs_f::bin_file>(
                test_file2, 2048, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer2(2048);
            bmms_f::agent_ptr agent2(buffer2.data(), 2048);
            file_agent_ptr fap2(bin_file2, 0, 2048, agent2, mes_out);

            // 标记fap2为脏
            memset(buffer2.data(), 0xCC, 2048);
            fap2.store_from_void_ptr(buffer2.data(), 2048, 0, true, mes_out);

            // 移动赋值
            fap1 = move(fap2);

            // 验证fap2状态
            bool inited2 = false;
            fap2.get_is_inited(inited2);
            if (!inited2) {
                print_("  源对象正确置为未初始化状态");
            }
            else {
                print_("  源对象未正确置为未初始化状态");
            }

            // 验证fap1状态
            bool inited1 = false;
            fap1.get_is_inited(inited1);
            size_t cache_size = 0;
            fap1.get_cache_size(cache_size);

            if (inited1 && cache_size == 2048) {
                print_("  移动赋值成功，资源正确转移");
            }
            else {
                print_("  移动赋值失败");
            }

            bin_file1->close(mes_out);
            bin_file2->close(mes_out);
        }

        print_("2.3 自移动赋值测试");
        {
            str test_file = test_dir + "test_self_move.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 自移动赋值（应该无操作）
            fap = move(fap);

            // 验证状态仍然有效
            bool inited = false;
            fap.get_is_inited(inited);
            if (inited) {
                print_("  自移动赋值无副作用");
            }
            else {
                print_("  自移动赋值破坏了状态");
            }

            bin_file_ptr->close(mes_out);
        }

        // ============================ 数据控制测试 ============================
        print_("\n3. 数据控制测试：\n");

        print_("3.1 clear测试 - 正常清空");
        {
            str test_file = test_dir + "test_clear.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024, 0xAA);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 先写入一些数据
            memset(buffer.data(), 0xBB, 1024);
            fap.store_from_void_ptr(buffer.data(), 1024, 0, true, mes_out);

            // 清空
            fap.clear(mes_out);
            if (mes_out.code == 0) {
                // 验证缓存已清空
                bool all_zero = true;
                for (int i = 0; i < 1024; i++) {
                    if (buffer[i] != 0) {
                        all_zero = false;
                        break;
                    }
                }

                if (all_zero) {
                    print_("  clear成功，缓存已清空");

                    // 验证脏标志
                    bool dirty = false;
                    fap.get_dirty_flag(dirty);
                    if (dirty) {
                        print_("  脏标志正确设置");
                    }
                    else {
                        print_("  脏标志未正确设置");
                    }
                }
                else {
                    print_("  clear失败，缓存未完全清空");
                }
            }
            else {
                print_("  clear失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("3.2 clear_range测试 - 正常范围清空");
        {
            str test_file = test_dir + "test_clear_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            // 填充测试数据
            for (int i = 0; i < 1024; i++) {
                buffer[i] = static_cast<byte_1>(i % 256);
            }

            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 清空中间区域
            fap.clear_range(256, 512, mes_out);
            if (mes_out.code == 0) {
                // 验证指定范围已清空
                bool range_cleared = true;
                for (int i = 256; i < 768; i++) {
                    if (buffer[i] != 0) {
                        range_cleared = false;
                        break;
                    }
                }

                // 验证其他区域未改变
                bool other_unchanged = true;
                for (int i = 0; i < 256; i++) {
                    if (buffer[i] != static_cast<byte_1>(i % 256)) {
                        other_unchanged = false;
                        break;
                    }
                }
                for (int i = 768; i < 1024; i++) {
                    if (buffer[i] != static_cast<byte_1>(i % 256)) {
                        other_unchanged = false;
                        break;
                    }
                }

                if (range_cleared && other_unchanged) {
                    print_("  clear_range成功");
                }
                else {
                    print_("  clear_range失败，数据不正确");
                }
            }
            else {
                print_("  clear_range失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("3.3 clear_range测试 - 范围越界");
        {
            str test_file = test_dir + "test_clear_range_overflow.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 尝试越界清空
            fap.clear_range(512, 1024, mes_out); // 512+1024 > 1024
            if (mes_out.code != 0) {
                print_("  正确检测到范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到范围越界 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("3.4 clear测试 - 未初始化对象");
        {
            file_agent_ptr fap; // 未初始化
            mes::a_mes mes_out;
            fap.clear(mes_out);

            if (mes_out.code != 0) {
                print_("  正确检测到未初始化对象");
            }
            else {
                print_("  未检测到未初始化对象 - 错误");
            }
        }

        // ============================ 缓存同步测试 ============================
        print_("\n4. 缓存同步测试：\n");

        print_("4.1 push_cache_to_bin_file测试 - 正常推送");
        {
            str test_file = test_dir + "test_push_cache.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);

            // FAP从文件位置0开始，管理1024字节
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 修改缓存数据（使用不同的源数据避免重叠）
            vector<byte_1> source_data(1024, 0xDD);
            fap.store_from_void_ptr(source_data.data(), 1024, 0, true, mes_out);

            // 推送缓存到文件
            fap.push_cache_to_bin_file(mes_out);
            if (mes_out.code == 0) {
                // 验证文件数据 - 从文件的正确位置读取
                vector<byte_1> file_data(1024);
                // FAP管理的是文件位置0-1024，所以从0开始读取
                bin_file_ptr->load_to_void_ptr(0, 1024, file_data.data(), true, mes_out);

                if (memcmp(source_data.data(), file_data.data(), 1024) == 0) {
                    print_("  push_cache_to_bin_file成功");

                    // 验证脏标志已清除
                    bool dirty = false;
                    fap.get_dirty_flag(dirty);
                    if (!dirty) {
                        print_("  脏标志正确清除");
                    }
                    else {
                        print_("  脏标志未清除");
                    }
                }
                else {
                    print_("  文件数据验证失败 - 数据不匹配");

                    // 调试信息
                    print_("  源数据第一个字节: " + to_string(static_cast<int>(source_data[0])));
                    print_("  文件数据第一个字节: " + to_string(static_cast<int>(file_data[0])));
                }
            }
            else {
                print_("  push_cache_to_bin_file失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("4.2 pull_cache_from_bin_file测试 - 正常拉取");
        {
            str test_file = test_dir + "test_pull_cache.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            // 写入文件数据
            vector<byte_1> file_data(1024);
            for (int i = 0; i < 1024; i++) {
                file_data[i] = static_cast<byte_1>(i % 256);
            }
            bin_file_ptr->store_from_void_ptr(file_data.data(), 1024, 0, true, mes_out);

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 修改缓存数据（与文件不同）
            memset(buffer.data(), 0xEE, 1024);

            // 从文件拉取数据
            fap.pull_cache_from_bin_file(mes_out);
            if (mes_out.code == 0) {
                // 验证缓存数据与文件数据一致
                if (memcmp(buffer.data(), file_data.data(), 1024) == 0) {
                    print_("  pull_cache_from_bin_file成功");

                    // 验证脏标志已清除（缓存与文件一致）
                    bool dirty = false;
                    fap.get_dirty_flag(dirty);
                    if (!dirty) {
                        print_("  脏标志正确清除");
                    }
                    else {
                        print_("  脏标志未清除");
                    }
                }
                else {
                    print_("  缓存数据验证失败");
                }
            }
            else {
                print_("  pull_cache_from_bin_file失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("4.3 缓存同步循环测试");
        {
            str test_file = test_dir + "test_cache_cycle.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 512, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(512);
            bmms_f::agent_ptr agent(buffer.data(), 512);
            file_agent_ptr fap(bin_file_ptr, 0, 512, agent, mes_out);

            // 步骤1：写入数据到文件（通过FAP）
            vector<byte_1> data1(512, 0x11);
            fap.store_from_void_ptr(data1.data(), 512, 0, true, mes_out);
            fap.push_cache_to_bin_file(mes_out);

            if (mes_out.code != 0) {
                print_("  步骤1失败: " + mes_out.message);
                bin_file_ptr->close(mes_out);
                return;
            }

            // 步骤2：修改缓存（不推送）
            vector<byte_1> data2(512, 0x22);
            fap.store_from_void_ptr(data2.data(), 512, 0, true, mes_out);

            // 验证缓存是0x22
            bool cache_is_0x22 = true;
            for (int i = 0; i < 512; i++) {
                if (buffer[i] != 0x22) {
                    cache_is_0x22 = false;
                    break;
                }
            }

            if (!cache_is_0x22) {
                print_("  步骤2失败：缓存数据不正确");
                bin_file_ptr->close(mes_out);
                return;
            }

            // 步骤3：拉取（应该恢复为文件数据0x11）
            fap.pull_cache_from_bin_file(mes_out);
            if (mes_out.code != 0) {
                print_("  步骤3失败: " + mes_out.message);
                bin_file_ptr->close(mes_out);
                return;
            }

            // 验证缓存恢复为0x11
            bool restored = true;
            for (int i = 0; i < 512; i++) {
                if (buffer[i] != 0x11) {
                    restored = false;
                    break;
                }
            }

            if (restored) {
                print_("  缓存同步循环测试成功");
            }
            else {
                print_("  缓存同步循环测试失败 - 缓存未恢复");

                // 调试信息
                print_("  缓存第一个字节: " + to_string(static_cast<int>(buffer[0])));
                print_("  期望值: 0x11 (17)");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("4.4 push测试 - 文件范围无效");
        {
            str test_file = test_dir + "test_push_invalid.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 修改缓存
            vector<byte_1> source_data(1024, 0xFF);
            fap.store_from_void_ptr(source_data.data(), 1024, 0, true, mes_out);

            // 缩小文件（使缓存范围无效）
            bin_file_ptr->resize(512, mes_out);
            if (mes_out.code != 0) {
                print_("  文件缩小失败: " + mes_out.message);
                bin_file_ptr->close(mes_out);
                return;
            }

            // 尝试推送（应该失败）
            fap.push_cache_to_bin_file(mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到文件范围无效: " + mes_out.message);
            }
            else {
                print_("  未检测到文件范围无效 - 错误");

                // 调试：检查文件大小
                size_t file_size = bin_file_ptr->__file_size__();
                print_("  当前文件大小: " + to_string(file_size));
                print_("  FAP管理范围: 0-" + to_string(1024));
            }

            bin_file_ptr->close(mes_out);
        }

        print_("4.5 pull测试 - 缓存代理指针无效");
        {
            str test_file = test_dir + "test_pull_invalid.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            // 使用局部变量创建代理指针
            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // buffer离开作用域，但agent仍然持有指针
            // 在实际使用中，这种情况应该由调用者避免

            print_("  注意：测试缓存指针有效性依赖调用者管理内存生命周期");

            bin_file_ptr->close(mes_out);
        }

        // ============================ FAP <==> FAP 数据交换测试 ============================
        print_("\n5. FAP <==> FAP 数据交换测试：\n");

        print_("5.1 load/store测试 - 正常情况");
        {
            str test_file1 = test_dir + "test_fap_load_src.txt";
            str test_file2 = test_dir + "test_fap_load_dst.txt";
            cleanup_test_file(test_file1);
            cleanup_test_file(test_file2);

            // 创建两个file_agent_ptr
            mes::a_mes mes_out;

            shared_ptr<bfs_f::bin_file> bin_file1 = make_shared<bfs_f::bin_file>(
                test_file1, 2048, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer1(2048);
            bmms_f::agent_ptr agent1(buffer1.data(), 2048);
            file_agent_ptr fap1(bin_file1, 0, 2048, agent1, mes_out);

            shared_ptr<bfs_f::bin_file> bin_file2 = make_shared<bfs_f::bin_file>(
                test_file2, 2048, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer2(2048);
            bmms_f::agent_ptr agent2(buffer2.data(), 2048);
            file_agent_ptr fap2(bin_file2, 0, 2048, agent2, mes_out);

            // 准备源数据
            for (int i = 0; i < 2048; i++) {
                buffer1[i] = static_cast<byte_1>(i % 256);
            }
            fap1.store_from_void_ptr(buffer1.data(), 2048, 0, true, mes_out);

            // 从fap1加载数据到fap2
            fap1.load(256, 1024, fap2, 512, true, mes_out);
            if (mes_out.code == 0) {
                // 验证fap2的目标区域数据正确
                bool data_correct = true;
                for (int i = 0; i < 1024; i++) {
                    if (buffer2[512 + i] != buffer1[256 + i]) {
                        data_correct = false;
                        break;
                    }
                }

                if (data_correct) {
                    print_("  load操作成功");

                    // 验证fap2的脏标志
                    bool dirty2 = false;
                    fap2.get_dirty_flag(dirty2);
                    if (dirty2) {
                        print_("  目标FAP脏标志正确设置");
                    }
                    else {
                        print_("  目标FAP脏标志未设置");
                    }

                    // 验证fap1的脏标志（应该未改变）
                    bool dirty1 = false;
                    fap1.get_dirty_flag(dirty1);
                    if (!dirty1) {
                        print_("  源FAP脏标志未改变（正确）");
                    }
                    else {
                        print_("  源FAP脏标志错误改变");
                    }
                }
                else {
                    print_("  数据传输验证失败");
                }
            }
            else {
                print_("  load操作失败: " + mes_out.message);
            }

            // 测试store操作
            for (int i = 0; i < 2048; i++) {
                buffer2[i] = static_cast<byte_1>((i + 128) % 256);
            }
            fap2.store_from_void_ptr(buffer2.data(), 2048, 0, true, mes_out);

            fap1.store(fap2, 512, 512, 1024, true, mes_out);
            if (mes_out.code == 0) {
                // 验证数据
                bool store_correct = true;
                for (int i = 0; i < 512; i++) {
                    if (buffer1[1024 + i] != buffer2[512 + i]) {
                        store_correct = false;
                        break;
                    }
                }

                if (store_correct) {
                    print_("  store操作成功");
                }
                else {
                    print_("  store操作数据传输失败");
                }
            }
            else {
                print_("  store操作失败: " + mes_out.message);
            }

            bin_file1->close(mes_out);
            bin_file2->close(mes_out);
        }

        print_("5.2 load测试 - 安全模式重叠检查");
        {
            str test_file = test_dir + "test_fap_overlap.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 2048, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(2048);
            bmms_f::agent_ptr agent(buffer.data(), 2048);
            file_agent_ptr fap(bin_file_ptr, 0, 2048, agent, mes_out);

            // 填充数据
            for (int i = 0; i < 2048; i++) {
                buffer[i] = static_cast<byte_1>(i);
            }
            fap.store_from_void_ptr(buffer.data(), 2048, 0, true, mes_out);

            // 尝试重叠操作（应该失败）
            fap.load(0, 1024, fap, 512, true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到重叠操作: " + mes_out.message);
            }
            else {
                print_("  未检测到重叠操作 - 错误");
            }

            // 尝试不重叠操作（应该成功）
            fap.load(0, 512, fap, 1536, true, mes_out);
            if (mes_out.code == 0) {
                print_("  不重叠操作成功");
            }
            else {
                print_("  不重叠操作失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("5.3 load测试 - 非安全模式");
        {
            str test_file = test_dir + "test_fap_unsafe.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 填充数据
            memset(buffer.data(), 0x33, 512);
            memset(buffer.data() + 512, 0x44, 512);
            fap.store_from_void_ptr(buffer.data(), 1024, 0, true, mes_out);

            // 非安全模式重叠操作（可能成功，但不保证安全性）
            fap.load(0, 512, fap, 256, false, mes_out);
            if (mes_out.code == 0) {
                print_("  非安全模式重叠操作执行（注意：不保证数据正确性）");
            }
            else {
                print_("  非安全模式操作失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("5.4 load测试 - 范围越界");
        {
            str test_file = test_dir + "test_fap_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 创建另一个FAP
            str test_file2 = test_dir + "test_fap_range2.txt";
            cleanup_test_file(test_file2);
            shared_ptr<bfs_f::bin_file> bin_file2 = make_shared<bfs_f::bin_file>(
                test_file2, 512, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer2(512);
            bmms_f::agent_ptr agent2(buffer2.data(), 512);
            file_agent_ptr fap2(bin_file2, 0, 512, agent2, mes_out);

            // 尝试越界加载
            fap.load(512, 1024, fap2, 0, true, mes_out); // 源越界
            if (mes_out.code != 0) {
                print_("  正确检测到源范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到源范围越界 - 错误");
            }

            // 尝试目标越界
            fap.load(0, 512, fap2, 256, true, mes_out); // 256+512 > 512
            if (mes_out.code != 0) {
                print_("  正确检测到目标范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到目标范围越界 - 错误");
            }

            bin_file_ptr->close(mes_out);
            bin_file2->close(mes_out);
        }

        print_("5.5 load测试 - 未初始化对象");
        {
            file_agent_ptr fap1; // 未初始化
            file_agent_ptr fap2; // 未初始化
            mes::a_mes mes_out;

            fap1.load(0, 100, fap2, 0, true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到未初始化对象");
            }
            else {
                print_("  未检测到未初始化对象 - 错误");
            }
        }

        // ============================ FAP <==> AGENT_PTR 数据交换测试 ============================
        print_("\n6. FAP <==> AGENT_PTR 数据交换测试：\n");

        print_("6.1 load_to_agent_ptr测试 - 正常情况");
        {
            str test_file = test_dir + "test_fap_to_agent.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            // 准备FAP数据
            vector<byte_1> fap_buffer(1024);
            for (int i = 0; i < 1024; i++) {
                fap_buffer[i] = static_cast<byte_1>(i % 256);
            }
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);
            fap.store_from_void_ptr(fap_buffer.data(), 1024, 0, true, mes_out);

            // 准备目标代理指针
            vector<byte_1> target_buffer(2048);
            bmms_f::agent_ptr target_agent(target_buffer.data(), 2048);

            // 从FAP加载到代理指针
            fap.load_to_agent_ptr(256, 512, target_agent, 1024, true, mes_out);
            if (mes_out.code == 0) {
                // 验证数据
                bool data_correct = true;
                for (int i = 0; i < 512; i++) {
                    if (target_buffer[1024 + i] != fap_buffer[256 + i]) {
                        data_correct = false;
                        break;
                    }
                }

                if (data_correct) {
                    print_("  load_to_agent_ptr成功");

                    // 验证FAP脏标志未改变
                    bool dirty = false;
                    fap.get_dirty_flag(dirty);
                    if (!dirty) {
                        print_("  FAP脏标志未改变（正确）");
                    }
                    else {
                        print_("  FAP脏标志错误改变");
                    }
                }
                else {
                    print_("  数据传输验证失败");
                }
            }
            else {
                print_("  load_to_agent_ptr失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("6.2 store_from_agent_ptr测试 - 正常情况");
        {
            str test_file = test_dir + "test_agent_to_fap.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> fap_buffer(1024);
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);

            // 准备源代理指针数据
            vector<byte_1> source_buffer(2048);
            for (int i = 0; i < 2048; i++) {
                source_buffer[i] = static_cast<byte_1>((i + 64) % 256);
            }
            bmms_f::agent_ptr source_agent(source_buffer.data(), 2048);

            // 从代理指针存储到FAP
            fap.store_from_agent_ptr(source_agent, 512, 256, 128, true, mes_out);
            if (mes_out.code == 0) {
                // 验证FAP缓存数据
                bool data_correct = true;
                for (int i = 0; i < 256; i++) {
                    if (fap_buffer[128 + i] != source_buffer[512 + i]) {
                        data_correct = false;
                        break;
                    }
                }

                if (data_correct) {
                    print_("  store_from_agent_ptr成功");

                    // 验证FAP脏标志已设置
                    bool dirty = false;
                    fap.get_dirty_flag(dirty);
                    if (dirty) {
                        print_("  FAP脏标志正确设置");
                    }
                    else {
                        print_("  FAP脏标志未设置");
                    }
                }
                else {
                    print_("  数据传输验证失败");
                }
            }
            else {
                print_("  store_from_agent_ptr失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("6.3 load_to_agent_ptr测试 - 空代理指针");
        {
            str test_file = test_dir + "test_fap_to_null_agent.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 空代理指针
            bmms_f::agent_ptr null_agent;

            fap.load_to_agent_ptr(0, 100, null_agent, 0, true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到空代理指针: " + mes_out.message);
            }
            else {
                print_("  未检测到空代理指针 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("6.4 load_to_agent_ptr测试 - 代理指针范围越界");
        {
            str test_file = test_dir + "test_fap_agent_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> fap_buffer(1024);
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);

            // 小代理指针
            vector<byte_1> small_buffer(256);
            bmms_f::agent_ptr small_agent(small_buffer.data(), 256);

            // 尝试越界加载
            fap.load_to_agent_ptr(0, 512, small_agent, 0, true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到代理指针范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到代理指针范围越界 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("6.5 store_from_agent_ptr测试 - FAP范围越界");
        {
            str test_file = test_dir + "test_agent_fap_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> fap_buffer(1024);
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);

            vector<byte_1> source_buffer(512);
            bmms_f::agent_ptr source_agent(source_buffer.data(), 512);

            // 尝试越界存储
            fap.store_from_agent_ptr(source_agent, 0, 256, 800, true, mes_out); // 800+256 > 1024
            if (mes_out.code != 0) {
                print_("  正确检测到FAP范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到FAP范围越界 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        // ============================ FAP <==> VOID* 数据交换测试 ============================
        print_("\n7. FAP <==> VOID* 数据交换测试：\n");

        print_("7.1 load_to_void_ptr测试 - 正常情况");
        {
            str test_file = test_dir + "test_fap_to_void.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            // 准备FAP数据
            vector<byte_1> fap_buffer(1024);
            for (int i = 0; i < 1024; i++) {
                fap_buffer[i] = static_cast<byte_1>(i * 2);
            }
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);
            fap.store_from_void_ptr(fap_buffer.data(), 1024, 0, true, mes_out);

            // 目标内存
            vector<byte_1> target_buffer(512);

            // 从FAP加载到void指针
            fap.load_to_void_ptr(128, 256, target_buffer.data(), true, mes_out);
            if (mes_out.code == 0) {
                // 验证数据
                bool data_correct = true;
                for (int i = 0; i < 256; i++) {
                    if (target_buffer[i] != fap_buffer[128 + i]) {
                        data_correct = false;
                        break;
                    }
                }

                if (data_correct) {
                    print_("  load_to_void_ptr成功");
                }
                else {
                    print_("  数据传输验证失败");
                }
            }
            else {
                print_("  load_to_void_ptr失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("7.2 store_from_void_ptr测试 - 正常情况");
        {
            str test_file = test_dir + "test_void_to_fap.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> fap_buffer(1024);
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);

            // 源数据
            vector<byte_1> source_data(384);
            for (int i = 0; i < 384; i++) {
                source_data[i] = static_cast<byte_1>(i * 3);
            }

            // 从void指针存储到FAP
            fap.store_from_void_ptr(source_data.data(), 384, 320, true, mes_out);
            if (mes_out.code == 0) {
                // 验证FAP缓存数据
                bool data_correct = true;
                for (int i = 0; i < 384; i++) {
                    if (fap_buffer[320 + i] != source_data[i]) {
                        data_correct = false;
                        break;
                    }
                }

                if (data_correct) {
                    print_("  store_from_void_ptr成功");
                }
                else {
                    print_("  数据传输验证失败");
                }
            }
            else {
                print_("  store_from_void_ptr失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("7.3 load_to_void_ptr测试 - 空指针");
        {
            str test_file = test_dir + "test_fap_to_null_void.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            fap.load_to_void_ptr(0, 100, nullptr, true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到空指针: " + mes_out.message);
            }
            else {
                print_("  未检测到空指针 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("7.4 store_from_void_ptr测试 - FAP范围越界");
        {
            str test_file = test_dir + "test_void_fap_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> fap_buffer(1024);
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);

            vector<byte_1> source_data(256);

            // 尝试越界存储
            fap.store_from_void_ptr(source_data.data(), 256, 900, true, mes_out); // 900+256 > 1024
            if (mes_out.code != 0) {
                print_("  正确检测到FAP范围越界: " + mes_out.message);
            }
            else {
                print_("  未检测到FAP范围越界 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("7.5 安全模式重叠检查");
        {
            str test_file = test_dir + "test_void_overlap.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> fap_buffer(1024);
            bmms_f::agent_ptr fap_agent(fap_buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, fap_agent, mes_out);

            // 填充数据
            for (int i = 0; i < 1024; i++) {
                fap_buffer[i] = static_cast<byte_1>(i);
            }
            fap.store_from_void_ptr(fap_buffer.data(), 1024, 0, true, mes_out);

            // 尝试重叠操作（应该失败）
            fap.load_to_void_ptr(0, 512, fap_buffer.data() + 256, true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到重叠操作: " + mes_out.message);
            }
            else {
                print_("  未检测到重叠操作 - 错误");
            }

            // 尝试不重叠操作（应该成功）
            fap.load_to_void_ptr(0, 256, fap_buffer.data() + 768, true, mes_out);
            if (mes_out.code == 0) {
                print_("  不重叠操作成功");
            }
            else {
                print_("  不重叠操作失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        // ============================ 信息获取函数测试 ============================
        print_("\n8. 信息获取函数测试：\n");

        print_("8.1 基本状态信息获取测试");
        {
            str test_file = test_dir + "test_info.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 2048, bfs_f::bin_file::init_type::create, mes_out
            );

            // 注意：agent的大小是2048，FAP管理的是其中的1024字节
            vector<byte_1> buffer(2048);  // 缓存大小2048
            bmms_f::agent_ptr agent(buffer.data(), 2048);

            // FAP从文件位置512开始，管理1024字节
            file_agent_ptr fap(bin_file_ptr, 512, 1024, agent, mes_out);

            // 测试各种信息获取函数
            bool inited = false;
            fap.get_is_inited(inited);
            if (!inited) {
                print_("  get_is_inited失败");
                bin_file_ptr->close(mes_out);
                return;
            }

            size_t cache_begin = 0;
            fap.get_cache_begin_about_bin_file(cache_begin);
            if (cache_begin != 512) {
                print_("  get_cache_begin_about_bin_file失败: " + to_string(cache_begin) + " (期望: 512)");
                bin_file_ptr->close(mes_out);
                return;
            }

            bmms_f::agent_ptr cache_agent;
            fap.get_cache_agent_ptr(cache_agent);
            bool agent_null = false;
            cache_agent.get_is_null(agent_null);
            if (agent_null) {
                print_("  get_cache_agent_ptr失败");
                bin_file_ptr->close(mes_out);
                return;
            }

            void* raw_ptr = nullptr;
            fap.get_cache_raw_ptr(raw_ptr);
            if (raw_ptr != buffer.data()) {
                print_("  get_cache_raw_ptr失败");
                bin_file_ptr->close(mes_out);
                return;
            }

            size_t cache_size = 0;
            fap.get_cache_size(cache_size);
            // agent的大小是2048，所以应该返回2048（缓存总大小）
            if (cache_size == 2048) {
                print_("  get_cache_size正确：缓存总大小=" + to_string(cache_size));
            }
            else {
                print_("  get_cache_size失败: " + to_string(cache_size) + " (期望: 2048)");
                bin_file_ptr->close(mes_out);
                return;
            }

            bool dirty = false;
            fap.get_dirty_flag(dirty);
            if (dirty) {
                print_("  get_dirty_flag失败：初始应为false");
                bin_file_ptr->close(mes_out);
                return;
            }

            shared_ptr<bfs_f::bin_file> associated_file;
            fap.get_associated_bin_file_shared_ptr(associated_file);
            if (associated_file != bin_file_ptr) {
                print_("  get_associated_bin_file_shared_ptr失败");
                bin_file_ptr->close(mes_out);
                return;
            }

            bool is_associated = false;
            fap.check_associated_with_bin_file_shared_ptr(bin_file_ptr, is_associated, mes_out);
            if (!is_associated) {
                print_("  check_associated_with_bin_file_shared_ptr失败");
                bin_file_ptr->close(mes_out);
                return;
            }

            print_("  所有基本状态信息获取函数测试通过");

            bin_file_ptr->close(mes_out);
        }

        print_("8.2 范围检查测试");
        {
            str test_file = test_dir + "test_range_check.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 2048, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 256, 1024, agent, mes_out); // 管理256-1280

            // 测试文件范围检查
            bool in_managed = false;

            // 在管理范围内
            fap.check_file_range_in_managed(bin_file_ptr, 256, 512, in_managed, mes_out);
            if (!in_managed) {
                print_("  文件范围检查失败（应在管理范围内）");
                return;
            }

            // 不在管理范围内（在之前）
            fap.check_file_range_in_managed(bin_file_ptr, 0, 256, in_managed, mes_out);
            if (in_managed) {
                print_("  文件范围检查失败（不应在管理范围内）");
                return;
            }

            // 部分重叠（应该返回false）
            fap.check_file_range_in_managed(bin_file_ptr, 128, 256, in_managed, mes_out);
            if (in_managed) {
                print_("  文件范围检查失败（部分重叠应返回false）");
                return;
            }

            // 测试缓存范围检查
            fap.check_cache_range_in_managed(0, 512, in_managed, mes_out);
            if (!in_managed) {
                print_("  缓存范围检查失败（应在管理范围内）");
                return;
            }

            fap.check_cache_range_in_managed(512, 1024, in_managed, mes_out);
            if (in_managed) {
                print_("  缓存范围检查失败（应越界）");
                return;
            }

            print_("  范围检查函数测试通过");

            bin_file_ptr->close(mes_out);
        }

        print_("8.3 大小信息获取测试");
        {
            str test_file = test_dir + "test_size_info.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 4096, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(2048);
            bmms_f::agent_ptr agent(buffer.data(), 2048);
            file_agent_ptr fap(bin_file_ptr, 1024, 2048, agent, mes_out);

            // 获取管理的文件范围大小
            size_t managed_size = 0;
            fap.get_managed_file_size(managed_size, mes_out);
            if (managed_size != 3072) { // 从1024开始，文件大小4096，所以4096-1024=3072
                print_("  get_managed_file_size失败: " + to_string(managed_size));
                return;
            }

            // 获取缓存使用大小
            size_t used_size = 0;
            fap.get_cache_used_size(used_size, mes_out);
            if (used_size != 2048) {
                print_("  get_cache_used_size失败: " + to_string(used_size));
                return;
            }

            print_("  大小信息获取函数测试通过");

            // 测试文件被缩小的情况
            bin_file_ptr->resize(2048, mes_out); // 缩小文件
            fap.get_managed_file_size(managed_size, mes_out);
            if (managed_size != 1024) { // 2048-1024=1024
                print_("  文件缩小后get_managed_file_size失败: " + to_string(managed_size));
                return;
            }

            print_("  文件大小变化处理测试通过");

            bin_file_ptr->close(mes_out);
        }

        print_("8.4 文件有效性检查测试");
        {
            str test_file = test_dir + "test_validity.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 检查文件是否有效
            bool is_valid = false;
            fap.check_file_still_valid(is_valid, mes_out);
            if (!is_valid) {
                print_("  check_file_still_valid失败（文件应有效）");
                return;
            }

            // 关闭文件后检查
            bin_file_ptr->close(mes_out);
            fap.check_file_still_valid(is_valid, mes_out);
            if (is_valid) {
                print_("  check_file_still_valid失败（文件已关闭应无效）");
                return;
            }

            print_("  文件有效性检查测试通过");
        }

        print_("8.5 位置映射测试");
        {
            str test_file = test_dir + "test_position.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 4096, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(2048);
            bmms_f::agent_ptr agent(buffer.data(), 2048);
            file_agent_ptr fap(bin_file_ptr, 512, 2048, agent, mes_out);

            // 计算文件位置到缓存位置
            size_t cache_pos = 0;
            bool is_mappable = false;

            // 有效映射
            fap.calculate_cache_position(768, cache_pos, is_mappable, mes_out); // 768-512=256
            if (!is_mappable || cache_pos != 256) {
                print_("  calculate_cache_position失败: " + to_string(cache_pos));
                return;
            }

            // 不可映射（在管理范围之前）
            fap.calculate_cache_position(256, cache_pos, is_mappable, mes_out);
            if (is_mappable) {
                print_("  calculate_cache_position失败（应在管理范围之前）");
                return;
            }

            // 不可映射（在管理范围之后）
            fap.calculate_cache_position(3000, cache_pos, is_mappable, mes_out);
            if (is_mappable) {
                print_("  calculate_cache_position失败（应在管理范围之后）");
                return;
            }

            // 计算缓存位置到文件位置
            size_t file_pos = 0;

            // 有效映射
            fap.calculate_file_position(1024, file_pos, is_mappable, mes_out); // 512+1024=1536
            if (!is_mappable || file_pos != 1536) {
                print_("  calculate_file_position失败: " + to_string(file_pos));
                return;
            }

            // 不可映射（超出缓存大小）
            fap.calculate_file_position(2500, file_pos, is_mappable, mes_out);
            if (is_mappable) {
                print_("  calculate_file_position失败（应超出缓存大小）");
                return;
            }

            print_("  位置映射函数测试通过");

            bin_file_ptr->close(mes_out);
        }

        // ============================ 定理校验函数测试 ============================
        print_("\n9. 定理校验函数测试：\n");

        print_("9.1 自身状态有效性检查测试");
        {
            str test_file = test_dir + "test_theorem_self.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 测试有效状态
            bool valid = fap.__check_self_valid__(mes_out);
            if (!valid) {
                print_("  __check_self_valid__失败（有效状态）");
                return;
            }

            // 测试未初始化状态
            file_agent_ptr uninitialized;
            valid = uninitialized.__check_self_valid__(mes_out);
            if (valid) {
                print_("  __check_self_valid__失败（未初始化状态）");
                return;
            }

            print_("  __check_self_valid__测试通过");

            bin_file_ptr->close(mes_out);
        }

        print_("9.2 文件范围有效性检查测试");
        {
            str test_file = test_dir + "test_theorem_file.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 2048, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 512, 1024, agent, mes_out);

            // 测试有效范围
            size_t valid_begin = 768;
            size_t valid_size = 256;
            bool valid = fap.__check_file_range_valid__(*bin_file_ptr, valid_begin, valid_size, mes_out);
            if (!valid) {
                print_("  __check_file_range_valid__失败（有效范围）");
                return;
            }

            // 测试无效范围（越界）
            size_t invalid_begin = 1500;
            size_t invalid_size = 1024;
            valid = fap.__check_file_range_valid__(*bin_file_ptr, invalid_begin, invalid_size, mes_out);
            if (valid) {
                print_("  __check_file_range_valid__失败（越界范围）");
                return;
            }

            // 测试零大小
            size_t zero_size = 0;
            valid = fap.__check_file_range_valid__(*bin_file_ptr, valid_begin, zero_size, mes_out);
            if (valid) {
                print_("  __check_file_range_valid__失败（零大小）");
                return;
            }

            print_("  __check_file_range_valid__测试通过");

            bin_file_ptr->close(mes_out);
        }

        print_("9.3 缓存范围有效性检查测试");
        {
            str test_file = test_dir + "test_theorem_cache.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 测试有效范围
            size_t valid_begin = 256;
            size_t valid_size = 512;
            bool valid = fap.__check_cache_range_valid__(valid_begin, valid_size, mes_out);
            if (!valid) {
                print_("  __check_cache_range_valid__失败（有效范围）");
                return;
            }

            // 测试无效范围（越界）
            size_t invalid_begin = 512;
            size_t invalid_size = 1024;
            valid = fap.__check_cache_range_valid__(invalid_begin, invalid_size, mes_out);
            if (valid) {
                print_("  __check_cache_range_valid__失败（越界范围）");
                return;
            }

            // 测试零大小
            size_t zero_size = 0;
            valid = fap.__check_cache_range_valid__(valid_begin, zero_size, mes_out);
            if (valid) {
                print_("  __check_cache_range_valid__失败（零大小）");
                return;
            }

            print_("  __check_cache_range_valid__测试通过");

            bin_file_ptr->close(mes_out);
        }

        print_("9.4 两个FAP兼容性检查测试");
        {
            str test_file1 = test_dir + "test_theorem_fap1.txt";
            str test_file2 = test_dir + "test_theorem_fap2.txt";
            cleanup_test_file(test_file1);
            cleanup_test_file(test_file2);

            mes::a_mes mes_out;

            shared_ptr<bfs_f::bin_file> bin_file1 = make_shared<bfs_f::bin_file>(
                test_file1, 2048, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer1(2048);
            bmms_f::agent_ptr agent1(buffer1.data(), 2048);
            file_agent_ptr fap1(bin_file1, 0, 2048, agent1, mes_out);

            shared_ptr<bfs_f::bin_file> bin_file2 = make_shared<bfs_f::bin_file>(
                test_file2, 2048, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer2(2048);
            bmms_f::agent_ptr agent2(buffer2.data(), 2048);
            file_agent_ptr fap2(bin_file2, 0, 2048, agent2, mes_out);

            // 测试兼容操作
            size_t self_begin = 256;
            size_t other_begin = 512;
            size_t op_size = 1024;
            bool compatible = fap1.__check_two_fap_compatible__(fap2, self_begin, other_begin, op_size, mes_out);
            if (!compatible) {
                print_("  __check_two_fap_compatible__失败（兼容操作）");
                return;
            }

            // 测试不兼容操作（大小不匹配）
            size_t large_size = 3000;
            compatible = fap1.__check_two_fap_compatible__(fap2, self_begin, other_begin, large_size, mes_out);
            if (compatible) {
                print_("  __check_two_fap_compatible__失败（大小不匹配）");
                return;
            }

            print_("  __check_two_fap_compatible__测试通过");

            bin_file1->close(mes_out);
            bin_file2->close(mes_out);
        }

        // ============================ 边界条件测试 ============================
        print_("\n10. 边界条件测试：\n");

        print_("10.1 单字节FAP测试");
        {
            str test_file = test_dir + "test_edge_single.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1);
            bmms_f::agent_ptr agent(buffer.data(), 1);
            file_agent_ptr fap(bin_file_ptr, 0, 1, agent, mes_out);

            // 写入和读取单个字节
            byte_1 data = 0x7F;
            fap.store_from_void_ptr(&data, 1, 0, true, mes_out);

            byte_1 read_data = 0;
            fap.load_to_void_ptr(0, 1, &read_data, true, mes_out);

            if (data == read_data) {
                print_("  单字节FAP操作成功");
            }
            else {
                print_("  单字节FAP操作失败");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("10.2 最大边界测试");
        {
            str test_file = test_dir + "test_edge_max.txt";
            cleanup_test_file(test_file);

            // 测试大文件和大缓存
            const size_t LARGE_SIZE = 10 * 1024 * 1024; // 10MB

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, LARGE_SIZE, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(LARGE_SIZE);
            bmms_f::agent_ptr agent(buffer.data(), LARGE_SIZE);
            file_agent_ptr fap(bin_file_ptr, 0, LARGE_SIZE, agent, mes_out);

            if (mes_out.code == 0) {
                // 填充测试数据
                for (size_t i = 0; i < LARGE_SIZE; i++) {
                    buffer[i] = static_cast<byte_1>(i % 256);
                }
                fap.store_from_void_ptr(buffer.data(), LARGE_SIZE, 0, true, mes_out);

                // 推送缓存
                fap.push_cache_to_bin_file(mes_out);

                if (mes_out.code == 0) {
                    print_("  大文件FAP操作成功（10MB）");
                }
                else {
                    print_("  大文件推送失败: " + mes_out.message);
                }
            }
            else {
                print_("  大文件FAP创建失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("10.3 文件范围边界测试");
        {
            str test_file = test_dir + "test_edge_file_range.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 4096, bfs_f::bin_file::init_type::create, mes_out
            );

            // 创建从文件末尾开始的FAP（管理最后1024字节）
            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 3072, 1024, agent, mes_out);

            if (mes_out.code == 0) {
                // 测试操作边界 - 使用不同的源数据
                vector<byte_1> source_data(1024, 0x99);
                fap.store_from_void_ptr(source_data.data(), 1024, 0, true, mes_out);

                if (mes_out.code == 0) {
                    print_("  文件范围边界存储操作成功");

                    // 尝试操作边界（应该成功）
                    vector<byte_1> read_buffer(1024);
                    fap.load_to_void_ptr(0, 1024, read_buffer.data(), true, mes_out);
                    if (mes_out.code == 0) {
                        // 验证读取的数据
                        if (memcmp(source_data.data(), read_buffer.data(), 1024) == 0) {
                            print_("  文件范围边界读取操作成功");
                        }
                        else {
                            print_("  数据验证失败");
                        }
                    }
                    else {
                        print_("  文件范围边界读取操作失败: " + mes_out.message);
                    }

                    // 尝试越界操作（应该失败）
                    fap.load_to_void_ptr(512, 1024, read_buffer.data(), true, mes_out);
                    if (mes_out.code != 0) {
                        print_("  正确检测到边界越界操作");
                    }
                    else {
                        print_("  未检测到边界越界操作 - 错误");
                    }
                }
                else {
                    print_("  文件范围边界存储操作失败: " + mes_out.message);
                }
            }
            else {
                print_("  边界FAP创建失败: " + mes_out.message);
            }

            bin_file_ptr->close(mes_out);
        }

        print_("10.4 溢出测试");
        {
            str test_file = test_dir + "test_edge_overflow.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 1024, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 0, 1024, agent, mes_out);

            // 测试size_t溢出
            size_t overflow_begin = SIZE_MAX - 500;
            size_t overflow_size = 1000;

            fap.load_to_void_ptr(overflow_begin, overflow_size, buffer.data(), true, mes_out);
            if (mes_out.code != 0) {
                print_("  正确检测到溢出: " + mes_out.message);
            }
            else {
                print_("  未检测到溢出 - 错误");
            }

            bin_file_ptr->close(mes_out);
        }

        // ============================ 综合场景测试 ============================
        print_("\n11. 综合场景测试：\n");

        print_("11.1 完整工作流程测试");
        {
            str test_file = test_dir + "test_scenario_full.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;

            // 阶段1：创建和初始化
            print_("  阶段1：创建FAP");
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 4096, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(2048);
            bmms_f::agent_ptr agent(buffer.data(), 2048);
            file_agent_ptr fap(bin_file_ptr, 1024, 2048, agent, mes_out);

            if (mes_out.code != 0) {
                print_("  创建失败: " + mes_out.message);
                return;
            }

            // 阶段2：数据操作
            print_("  阶段2：数据操作");

            // 写入数据 - 使用不同的源数据
            vector<byte_1> source_data1(2048);
            for (int i = 0; i < 2048; i++) {
                source_data1[i] = static_cast<byte_1>(i);
            }
            fap.store_from_void_ptr(source_data1.data(), 2048, 0, true, mes_out);

            // 读取验证 - 使用不同的缓冲区
            vector<byte_1> verify_buffer1(2048);
            fap.load_to_void_ptr(0, 2048, verify_buffer1.data(), true, mes_out);

            if (memcmp(source_data1.data(), verify_buffer1.data(), 2048) != 0) {
                print_("  数据操作验证失败");
                bin_file_ptr->close(mes_out);
                return;
            }

            // 阶段3：缓存同步
            print_("  阶段3：缓存同步");
            fap.push_cache_to_bin_file(mes_out);
            if (mes_out.code != 0) {
                print_("  缓存推送失败: " + mes_out.message);
                bin_file_ptr->close(mes_out);
                return;
            }

            // 阶段4：修改和重新拉取
            print_("  阶段4：修改和重新拉取");

            // 使用不同的数据修改缓存
            vector<byte_1> source_data2(2048, 0xFF);
            fap.store_from_void_ptr(source_data2.data(), 2048, 0, true, mes_out);

            // 从文件重新拉取
            fap.pull_cache_from_bin_file(mes_out);
            if (mes_out.code != 0) {
                print_("  重新拉取失败: " + mes_out.message);
                bin_file_ptr->close(mes_out);
                return;
            }

            // 验证恢复为原始数据
            vector<byte_1> verify_buffer2(2048);
            fap.load_to_void_ptr(0, 2048, verify_buffer2.data(), true, mes_out);

            bool restored = true;
            for (int i = 0; i < 2048; i++) {
                if (verify_buffer2[i] != source_data1[i]) {  // 应该恢复为source_data1
                    restored = false;
                    break;
                }
            }

            if (!restored) {
                print_("  重新拉取验证失败");

                // 调试信息
                print_("  期望第一个字节: " + to_string(static_cast<int>(source_data1[0])));
                print_("  实际第一个字节: " + to_string(static_cast<int>(verify_buffer2[0])));

                bin_file_ptr->close(mes_out);
                return;
            }

            // 阶段5：清理
            print_("  阶段5：清理");
            fap.clear(mes_out);
            bool all_zero = true;
            for (int i = 0; i < 2048; i++) {
                if (buffer[i] != 0) {
                    all_zero = false;
                    break;
                }
            }

            if (all_zero) {
                print_("  综合场景测试通过");
            }
            else {
                print_("  清理验证失败");
            }

            bin_file_ptr->close(mes_out);
        }

        print_("11.2 多FAP协作测试");
        {
            str test_file1 = test_dir + "test_multi_fap1.txt";
            str test_file2 = test_dir + "test_multi_fap2.txt";
            str test_file3 = test_dir + "test_multi_fap3.txt";
            cleanup_test_file(test_file1);
            cleanup_test_file(test_file2);
            cleanup_test_file(test_file3);

            mes::a_mes mes_out;

            // 创建三个FAP
            print_("  创建三个FAP进行协作测试");

            shared_ptr<bfs_f::bin_file> bin_file1 = make_shared<bfs_f::bin_file>(
                test_file1, 3072, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer1(1024);
            bmms_f::agent_ptr agent1(buffer1.data(), 1024);
            file_agent_ptr fap1(bin_file1, 0, 1024, agent1, mes_out);

            shared_ptr<bfs_f::bin_file> bin_file2 = make_shared<bfs_f::bin_file>(
                test_file2, 3072, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer2(1024);
            bmms_f::agent_ptr agent2(buffer2.data(), 1024);
            file_agent_ptr fap2(bin_file2, 1024, 1024, agent2, mes_out);

            shared_ptr<bfs_f::bin_file> bin_file3 = make_shared<bfs_f::bin_file>(
                test_file3, 3072, bfs_f::bin_file::init_type::create, mes_out
            );
            vector<byte_1> buffer3(1024);
            bmms_f::agent_ptr agent3(buffer3.data(), 1024);
            file_agent_ptr fap3(bin_file3, 2048, 1024, agent3, mes_out);

            // 准备数据
            for (int i = 0; i < 1024; i++) {
                buffer1[i] = static_cast<byte_1>(i);
            }
            fap1.store_from_void_ptr(buffer1.data(), 1024, 0, true, mes_out);

            // FAP1 -> FAP2 -> FAP3 数据传输链
            fap1.load(0, 512, fap2, 256, true, mes_out);
            fap2.load(256, 512, fap3, 0, true, mes_out);

            // 验证数据
            vector<byte_1> verify_buffer(512);
            fap3.load_to_void_ptr(0, 512, verify_buffer.data(), true, mes_out);

            bool chain_correct = true;
            for (int i = 0; i < 512; i++) {
                if (verify_buffer[i] != static_cast<byte_1>(i)) {
                    chain_correct = false;
                    break;
                }
            }

            if (chain_correct) {
                print_("  多FAP协作测试通过");
            }
            else {
                print_("  多FAP协作测试失败");
            }

            bin_file1->close(mes_out);
            bin_file2->close(mes_out);
            bin_file3->close(mes_out);
        }

        print_("11.3 错误恢复和状态保持测试");
        {
            str test_file = test_dir + "test_error_recovery.txt";
            cleanup_test_file(test_file);

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, 2048, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(1024);
            bmms_f::agent_ptr agent(buffer.data(), 1024);
            file_agent_ptr fap(bin_file_ptr, 512, 1024, agent, mes_out);

            // 记录初始状态
            bool initial_inited = false;
            fap.get_is_inited(initial_inited);

            // 触发一个错误（范围越界）
            vector<byte_1> temp_buffer(2048);
            fap.store_from_void_ptr(temp_buffer.data(), 2048, 0, true, mes_out);

            if (mes_out.code != 0) {
                print_("  正确触发错误: " + mes_out.message);

                // 错误后检查状态
                bool after_error_inited = false;
                fap.get_is_inited(after_error_inited);

                if (initial_inited && after_error_inited) {
                    print_("  错误后状态保持正确");

                    // 尝试正常操作（应该能恢复）
                    mes_out = mes::a_mes(0, 0, "");
                    fap.store_from_void_ptr(temp_buffer.data(), 512, 0, true, mes_out);

                    if (mes_out.code == 0) {
                        print_("  错误后恢复操作成功");
                    }
                    else {
                        print_("  错误后恢复操作失败: " + mes_out.message);
                    }
                }
                else {
                    print_("  错误后状态不一致");
                }
            }
            else {
                print_("  未正确触发错误");
            }

            bin_file_ptr->close(mes_out);
        }

        // ============================ 性能测试 ============================
        print_("\n12. 性能测试：\n");

        str perf_test_dir = test_dir + "perf/";
        create_test_directory(perf_test_dir);

        print_("12.1 FAP创建性能测试");
        {
            const size_t TEST_COUNT = 1000;
            const size_t BFS_SIZE = 1024;
            const size_t CACHE_SIZE = 1024;

            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < TEST_COUNT; i++) {
                str file_path = perf_test_dir + "perf_create_" + to_string(i) + ".txt";
                cleanup_test_file(file_path);

                mes::a_mes mes_out;
                shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                    file_path, BFS_SIZE, bfs_f::bin_file::init_type::create, mes_out
                );

                vector<byte_1> buffer(CACHE_SIZE);
                bmms_f::agent_ptr agent(buffer.data(), CACHE_SIZE);
                file_agent_ptr fap(bin_file_ptr, 0, CACHE_SIZE, agent, mes_out);

                bin_file_ptr->close(mes_out);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            double avg_us = duration.count() * 1000.0 / TEST_COUNT;

            print_("  " + to_string(static_cast<unsigned long>(duration.count())) +
                " ms (平均" + to_string(avg_us) + " us/次)");
        }

        print_("12.2 FAP数据操作性能测试");
        {
            str test_file = perf_test_dir + "perf_ops.txt";
            cleanup_test_file(test_file);

            const size_t BFS_SIZE = 10 * 1024 * 1024; // 10MB
            const size_t CACHE_SIZE = 1 * 1024 * 1024; // 1MB
            const size_t OP_COUNT = 1000;

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, BFS_SIZE, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(CACHE_SIZE);
            bmms_f::agent_ptr agent(buffer.data(), CACHE_SIZE);
            file_agent_ptr fap(bin_file_ptr, 0, CACHE_SIZE, agent, mes_out);

            // 准备测试数据
            vector<byte_1> test_data(64 * 1024); // 64KB
            for (size_t i = 0; i < test_data.size(); i++) {
                test_data[i] = static_cast<byte_1>(i % 256);
            }

            // 写入性能测试
            print_("  连续写入性能（64KB×" + to_string(OP_COUNT) + "次）: ");
            auto write_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < OP_COUNT; i++) {
                size_t offset = (i * test_data.size()) % (CACHE_SIZE - test_data.size());
                fap.store_from_void_ptr(test_data.data(), test_data.size(), offset, false, mes_out);
            }

            auto write_end = std::chrono::high_resolution_clock::now();
            auto write_duration = std::chrono::duration_cast<std::chrono::milliseconds>(write_end - write_start);
            double total_bytes = OP_COUNT * test_data.size();
            double write_speed = total_bytes / (1024.0 * 1024.0) / (write_duration.count() / 1000.0);

            print_("  " + to_string(static_cast<unsigned long>(write_duration.count())) +
                " ms (" + to_string(write_speed) + " MB/s)");

            // 读取性能测试
            print_("  连续读取性能（64KB×" + to_string(OP_COUNT) + "次）: ");
            auto read_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < OP_COUNT; i++) {
                size_t offset = (i * test_data.size()) % (CACHE_SIZE - test_data.size());
                fap.load_to_void_ptr(offset, test_data.size(), test_data.data(), false, mes_out);
            }

            auto read_end = std::chrono::high_resolution_clock::now();
            auto read_duration = std::chrono::duration_cast<std::chrono::milliseconds>(read_end - read_start);
            double read_speed = total_bytes / (1024.0 * 1024.0) / (read_duration.count() / 1000.0);

            print_("  " + to_string(static_cast<unsigned long>(read_duration.count())) +
                " ms (" + to_string(read_speed) + " MB/s)");

            bin_file_ptr->close(mes_out);
        }

        print_("12.3 缓存同步性能测试");
        {
            str test_file = perf_test_dir + "perf_cache_sync.txt";
            cleanup_test_file(test_file);

            const size_t CACHE_SIZE = 4 * 1024 * 1024; // 4MB

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, CACHE_SIZE, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(CACHE_SIZE);
            bmms_f::agent_ptr agent(buffer.data(), CACHE_SIZE);
            file_agent_ptr fap(bin_file_ptr, 0, CACHE_SIZE, agent, mes_out);

            // 填充缓存
            for (size_t i = 0; i < CACHE_SIZE; i++) {
                buffer[i] = static_cast<byte_1>(i % 256);
            }
            fap.store_from_void_ptr(buffer.data(), CACHE_SIZE, 0, true, mes_out);

            // 推送性能测试
            print_("  缓存推送性能（4MB）: ");
            auto push_start = std::chrono::high_resolution_clock::now();

            fap.push_cache_to_bin_file(mes_out);

            auto push_end = std::chrono::high_resolution_clock::now();
            auto push_duration = std::chrono::duration_cast<std::chrono::microseconds>(push_end - push_start);
            double push_speed = CACHE_SIZE / (1024.0 * 1024.0) / (push_duration.count() / 1000000.0);

            print_("  " + to_string(static_cast<unsigned long>(push_duration.count())) +
                " us (" + to_string(push_speed) + " MB/s)");

            // 拉取性能测试
            print_("  缓存拉取性能（4MB）: ");
            auto pull_start = std::chrono::high_resolution_clock::now();

            fap.pull_cache_from_bin_file(mes_out);

            auto pull_end = std::chrono::high_resolution_clock::now();
            auto pull_duration = std::chrono::duration_cast<std::chrono::microseconds>(pull_end - pull_start);
            double pull_speed = CACHE_SIZE / (1024.0 * 1024.0) / (pull_duration.count() / 1000000.0);

            print_("  " + to_string(static_cast<unsigned long>(pull_duration.count())) +
                " us (" + to_string(pull_speed) + " MB/s)");

            bin_file_ptr->close(mes_out);
        }

        print_("12.4 安全模式与非安全模式性能对比");
        {
            str test_file = perf_test_dir + "perf_safe_mode.txt";
            cleanup_test_file(test_file);

            const size_t CACHE_SIZE = 2 * 1024 * 1024; // 2MB
            const size_t OP_SIZE = 4 * 1024; // 4KB
            const size_t OP_COUNT = 1000;

            mes::a_mes mes_out;
            shared_ptr<bfs_f::bin_file> bin_file_ptr = make_shared<bfs_f::bin_file>(
                test_file, CACHE_SIZE, bfs_f::bin_file::init_type::create, mes_out
            );

            vector<byte_1> buffer(CACHE_SIZE);
            bmms_f::agent_ptr agent(buffer.data(), CACHE_SIZE);
            file_agent_ptr fap(bin_file_ptr, 0, CACHE_SIZE, agent, mes_out);

            // 准备测试数据
            vector<byte_1> test_data(OP_SIZE);
            for (size_t i = 0; i < OP_SIZE; i++) {
                test_data[i] = static_cast<byte_1>(i % 256);
            }

            // 安全模式性能
            print_("  安全模式（4KB×" + to_string(OP_COUNT) + "次）: ");
            auto safe_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < OP_COUNT; i++) {
                size_t offset = (i * OP_SIZE) % (CACHE_SIZE - OP_SIZE);
                fap.store_from_void_ptr(test_data.data(), OP_SIZE, offset, true, mes_out);
            }

            auto safe_end = std::chrono::high_resolution_clock::now();
            auto safe_duration = std::chrono::duration_cast<std::chrono::milliseconds>(safe_end - safe_start);

            print_("  " + to_string(static_cast<unsigned long>(safe_duration.count())) + " ms");

            // 非安全模式性能
            print_("  非安全模式（4KB×" + to_string(OP_COUNT) + "次）: ");
            auto unsafe_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < OP_COUNT; i++) {
                size_t offset = (i * OP_SIZE) % (CACHE_SIZE - OP_SIZE);
                fap.store_from_void_ptr(test_data.data(), OP_SIZE, offset, false, mes_out);
            }

            auto unsafe_end = std::chrono::high_resolution_clock::now();
            auto unsafe_duration = std::chrono::duration_cast<std::chrono::milliseconds>(unsafe_end - unsafe_start);

            double improvement = (safe_duration.count() - unsafe_duration.count()) * 100.0 / safe_duration.count();
            print_("  " + to_string(static_cast<unsigned long>(unsafe_duration.count())) +
                " ms (" + to_string(improvement) + "%性能提升)");

            bin_file_ptr->close(mes_out);
        }

        // 清理测试文件
        print_("\n清理测试文件...");
        try {
            std::filesystem::remove_all(test_dir);
            print_("清理完成");
        }
        catch (...) {
            print_("清理失败");
        }

        print_("\n========== BFS_AGENT_PTR 测试结束 ==========\n");
    }
#endif
}