﻿//file_bin_file_test.cpp

module BFS;

#include "BFS_dp.h"
#include "BMMS_dp.h"

namespace bfs_f {
    #if defined(BFS_INCLUDE_TEST)

    namespace bin_file_test {
        // 辅助函数：打印测试信息
        void print_(const str& msg) {
            std::cout << msg << endl;
        }

        // 辅助函数：创建测试目录
        bool create_test_directory(const std::string& path) {
            try {
                std::filesystem::create_directories(path);
                return true;
            }
            catch (...) {
                return false;
            }
        }

        // 辅助函数：清理测试文件
        void cleanup_test_file(const std::string& path) {
            try {
                if (std::filesystem::exists(path)) {
                    std::filesystem::remove(path);
                }
            }
            catch (...) {
                // 忽略清理错误
            }
        }
        // 辅助函数：比较两个文件内容
        bool compare_files(const std::string& path1, const std::string& path2) {
            try {
                if (!std::filesystem::exists(path1) || !std::filesystem::exists(path2)) {
                    return false;
                }

                size_t size1 = std::filesystem::file_size(path1);
                size_t size2 = std::filesystem::file_size(path2);

                if (size1 != size2) {
                    return false;
                }

                std::ifstream file1(path1, std::ios::binary);
                std::ifstream file2(path2, std::ios::binary);

                if (!file1.is_open() || !file2.is_open()) {
                    return false;
                }

                const size_t BUFFER_SIZE = 4096;
                vector<char> buffer1(BUFFER_SIZE);
                vector<char> buffer2(BUFFER_SIZE);

                size_t remaining = size1;
                while (remaining > 0) {
                    size_t chunk = std::min(remaining, BUFFER_SIZE);
                    file1.read(buffer1.data(), chunk);
                    file2.read(buffer2.data(), chunk);

                    if (memcmp(buffer1.data(), buffer2.data(), chunk) != 0) {
                        return false;
                    }

                    remaining -= chunk;
                }

                return true;
            }
            catch (...) {
                return false;
            }
        }
    }

    void bin_file::test() {
        bin_file_test::print_("========== BFS 测试开始 ==========\n");

        // 创建测试目录
        std::string test_dir = "C:/lib/cache/test/";
        bin_file_test::create_test_directory(test_dir);

        // ============================ 构造函数测试 ============================
        bin_file_test::print_("\n1. 构造函数测试：\n");

        bin_file_test::print_("1.1 正常构造测试 - create模式");
        {
            std::string test_file = test_dir + "test_create.txt";
            bin_file_test::cleanup_test_file(test_file);

            mes::a_mes mes_out;
            bin_file file(test_file, 100, init_type::create, mes_out);

            if (mes_out.code == 0 && file.__check_inited__()) {
                bin_file_test::print_("  正常构造通过");
            }
            else {
                bin_file_test::print_("  正常构造失败: " + mes_out.message);
            }
        }

        bin_file_test::print_("1.2 正常构造测试 - open_existed模式");
        {
            std::string test_file = test_dir + "test_open_exist.txt";
            bin_file_test::cleanup_test_file(test_file);

            // 先创建文件
            {
                std::ofstream f(test_file);
                f << "test data";
            }

            mes::a_mes mes_out;
            bin_file file(test_file, 0, init_type::open_existed, mes_out);

            if (mes_out.code == 0 && file.__check_inited__()) {
                bin_file_test::print_("  正常构造通过");
            }
            else {
                bin_file_test::print_("  正常构造失败: " + mes_out.message);
            }

            bin_file_test::cleanup_test_file(test_file);
        }

        bin_file_test::print_("1.3 正常构造测试 - cover_and_create模式");
        {
            std::string test_file = test_dir + "test_cover.txt";
            bin_file_test::cleanup_test_file(test_file);

            mes::a_mes mes_out;
            bin_file file(test_file, 200, init_type::cover_and_create, mes_out);

            if (mes_out.code == 0 && file.__check_inited__()) {
                bin_file_test::print_("  正常构造通过");
            }
            else {
                bin_file_test::print_("  正常构造失败: " + mes_out.message);
            }
        }

        bin_file_test::print_("1.4 错误构造测试 - 空路径");
        {
            try {
                mes::a_mes mes_out;
                bin_file file("", 100, init_type::create, mes_out);
                bin_file_test::print_("  未捕获异常 - 错误");
            }
            catch (mes::a_mes e) {
                bin_file_test::print_("  捕获异常 - 正常: " + e.message);
            }
        }

        bin_file_test::print_("1.5 错误构造测试 - 文件不存在时使用open_existed");
        {
            std::string test_file = test_dir + "non_existent.txt";
            bin_file_test::cleanup_test_file(test_file);

            mes::a_mes mes_out;
            bin_file file(test_file, 0, init_type::open_existed, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件不存在");
            }
            else {
                bin_file_test::print_("  未检测到文件不存在 - 错误");
            }
        }

        bin_file_test::print_("1.6 错误构造测试 - 文件已存在时使用create");
        {
            std::string test_file = test_dir + "already_exists.txt";

            // 先创建文件
            {
                std::ofstream f(test_file);
                f << "existing data";
            }

            mes::a_mes mes_out;
            bin_file file(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件已存在");
            }
            else {
                bin_file_test::print_("  未检测到文件已存在 - 错误");
            }

            bin_file_test::cleanup_test_file(test_file);
        }

        bin_file_test::print_("1.7 错误构造测试 - 无效的init_type值");
        {
            std::string test_file = test_dir + "test_invalid.txt";

            try {
                mes::a_mes mes_out;
                bin_file file(test_file, 100, static_cast<init_type>(99), mes_out);

                // 如果没有抛出异常，检查返回的错误
                if (mes_out.code != 0) {
                    bin_file_test::print_("  返回错误 - 正常: " + mes_out.message);
                }
                else {
                    bin_file_test::print_("  既无异常也无错误 - 不应该发生");
                }
            }
            catch (mes::a_mes e) {
                bin_file_test::print_("  捕获异常 - 正常: " + e.message);
            }
            catch (...) {
                bin_file_test::print_("  捕获未知异常 - 正常");
            }
        }

        // ============================ open函数测试 ============================
        bin_file_test::print_("\n2. open函数测试：\n");

        bin_file_test::print_("2.1 open测试 - 正常open_existed");
        {
            std::string test_file = test_dir + "test_open_func.txt";
            bin_file_test::cleanup_test_file(test_file);

            // 先创建文件
            {
                std::ofstream f(test_file);
                f << "test data for open";
            }

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 0, init_type::open_existed, mes_out);

            if (mes_out.code == 0 && file.__check_inited__()) {
                bin_file_test::print_("  open成功");
            }
            else {
                bin_file_test::print_("  open失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("2.2 open测试 - 重新打开已打开的文件");
        {
            std::string test_file = test_dir + "test_reopen.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;

            // 第一次打开
            file.open(test_file, 100, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  第一次打开失败: " + mes_out.message);
                return;
            }

            // 第二次打开（应该先关闭再打开）
            file.open(test_file, 200, init_type::cover_and_create, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  重新打开成功");
            }
            else {
                bin_file_test::print_("  重新打开失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("2.3 open测试 - 打开空路径");
        {
            try {
                bin_file file;
                mes::a_mes mes_out;
                file.open("", 100, init_type::create, mes_out);
                bin_file_test::print_("  未捕获异常 - 错误");
            }
            catch (mes::a_mes e) {
                bin_file_test::print_("  捕获异常 - 正常: " + e.message);
            }
        }

        // ============================ close函数测试 ============================
        bin_file_test::print_("\n3. close函数测试：\n");

        bin_file_test::print_("3.1 close测试 - 正常关闭");
        {
            std::string test_file = test_dir + "test_close.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            file.close(mes_out);
            if (mes_out.code == 0 && !file.__check_inited__()) {
                bin_file_test::print_("  正常关闭成功");
            }
            else {
                bin_file_test::print_("  关闭失败: " + mes_out.message);
            }
        }

        bin_file_test::print_("3.2 close测试 - 关闭未打开的文件");
        {
            bin_file file; // 未打开
            mes::a_mes mes_out;
            file.close(mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件未打开");
            }
            else {
                bin_file_test::print_("  未检测到文件未打开 - 错误");
            }
        }

        bin_file_test::print_("3.3 close测试 - 多次关闭");
        {
            std::string test_file = test_dir + "test_double_close.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 第一次关闭
            file.close(mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  第一次关闭失败: " + mes_out.message);
            }

            // 第二次关闭
            file.close(mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  第二次关闭正确返回错误: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  第二次关闭不应该成功");
            }
        }

        // ============================ resize函数测试 ============================
        bin_file_test::print_("\n4. resize函数测试：\n");

        bin_file_test::print_("4.1 resize测试 - 扩大文件");
        {
            std::string test_file = test_dir + "test_resize_grow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            file.resize(200, mes_out);
            if (mes_out.code == 0 && file.__file_size__() == 200) {
                bin_file_test::print_("  扩大文件成功");
            }
            else {
                bin_file_test::print_("  扩大文件失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("4.2 resize测试 - 缩小文件");
        {
            std::string test_file = test_dir + "test_resize_shrink.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 200, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 写入一些数据
            std::string test_data = "test data for resize";
            file.store_from_void_ptr((void*)test_data.c_str(), test_data.size(), 0, false, mes_out);

            file.resize(100, mes_out);
            if (mes_out.code == 0 && file.__file_size__() == 100) {
                bin_file_test::print_("  缩小文件成功");
            }
            else {
                bin_file_test::print_("  缩小文件失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("4.3 resize测试 - 大小不变");
        {
            std::string test_file = test_dir + "test_resize_same.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            size_t original_size = file.__file_size__();
            file.resize(100, mes_out);

            if (mes_out.code == 0 && file.__file_size__() == original_size) {
                bin_file_test::print_("  大小不变操作成功");
            }
            else {
                bin_file_test::print_("  大小不变操作失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("4.4 resize测试 - 文件未打开时resize");
        {
            bin_file file; // 未打开
            mes::a_mes mes_out;
            file.resize(100, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件未打开");
            }
            else {
                bin_file_test::print_("  未检测到文件未打开 - 错误");
            }
        }

        bin_file_test::print_("4.5 resize测试 - 大小为零");
        {
            std::string test_file = test_dir + "test_resize_zero.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            file.resize(0, mes_out);
            if (mes_out.code == 0 && file.__file_size__() == 0) {
                bin_file_test::print_("  调整为0大小成功");
            }
            else {
                bin_file_test::print_("  调整为0大小失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        // ============================ clear函数测试 ============================
        bin_file_test::print_("\n5. clear函数测试：\n");

        // 测试5.1 clear测试 - 正常清空
        bin_file_test::print_("\n5.1 clear测试 - 正常清空");
        {
            mes::a_mes mes_out = {0,0,""};
            bin_file_test::cleanup_test_file("test_clear_.bin");
            bin_file file("test_clear_.bin", 1024, init_type::create, mes_out);

            // 第一步：检查构造函数是否成功
            if (mes_out.code != 0) {
                bin_file_test::print_("  文件创建失败: " + mes_out.message);
            }

            // 第二步：验证文件大小确实是1024
            size_t initial_size = file.__file_size__();
            if (initial_size != 1024) {
                bin_file_test::print_("  警告：文件大小不是1024，而是 " + to_string(initial_size));
                // 继续测试，但调整期望值
            }

            // 第三步：先写入一些数据
            vector<char> data(1024, 0xAA);
            file.store_from_void_ptr(data.data(), 1024, 0, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  数据写入失败: " + mes_out.message);
            }

            // 第四步：然后清空
            file.clear(mes_out);
            if (mes_out.code == 0) {
                size_t after_clear_size = file.__file_size__();

                // 正确检查：大小应该与清空前相同
                if (after_clear_size == initial_size) {
                    // 可选：验证内容为0
                    vector<char> buffer(std::min(static_cast<size_t>(1024), after_clear_size));
                    file.load_to_void_ptr(0, buffer.size(), buffer.data(), true, mes_out);
                    if (mes_out.code == 0) {
                        bool all_zero = true;
                        for (size_t i = 0; i < buffer.size(); i++) {
                            if (buffer[i] != 0) {
                                all_zero = false;
                                break;
                            }
                        }
                        if (all_zero) {
                            bin_file_test::print_("  清空文件成功");
                        }
                        else {
                            bin_file_test::print_("  清空文件失败: 内容未完全清零");
                        }
                    }
                }
                else {
                    bin_file_test::print_("  清空文件失败: 文件大小从 " + to_string(initial_size) +
                        " 改变为 " + to_string(after_clear_size));
                }
            }
            else {
                bin_file_test::print_("  清空文件失败: " + mes_out.message);
            }

            bin_file_test::cleanup_test_file("test_clear_.bin");
        }

        bin_file_test::print_("5.2 clear测试 - 文件未打开时clear");
        {
            bin_file file; // 未打开
            mes::a_mes mes_out;
            file.clear(mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件未打开");
            }
            else {
                bin_file_test::print_("  未检测到文件未打开 - 错误");
            }
        }

        // ============================ clear_range函数测试 ============================
        bin_file_test::print_("\n6. clear_range函数测试：\n");

        bin_file_test::print_("6.1 clear_range测试 - 正常范围清空");
        {
            std::string test_file = test_dir + "test_clear_range.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 写入测试数据
            vector<char> test_data(100, 0xFF);
            file.store_from_void_ptr(test_data.data(), 100, 0, false, mes_out);

            // 清空中间部分
            file.clear_range(25, 50, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  范围清空成功");

                // 验证：中间50字节应该为0
                vector<char> buffer(50);
                file.load_to_void_ptr(25, 50, buffer.data(), false, mes_out);
                if (mes_out.code == 0) {
                    bool all_zero = true;
                    for (int i = 0; i < 50; i++) {
                        if (buffer[i] != 0) {
                            all_zero = false;
                            break;
                        }
                    }
                    if (all_zero) {
                        bin_file_test::print_("  验证通过：范围内数据已清空");
                    }
                    else {
                        bin_file_test::print_("  验证失败：范围内数据未完全清空");
                    }
                }
            }
            else {
                bin_file_test::print_("  范围清空失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("6.2 clear_range测试 - 清空整个文件");
        {
            std::string test_file = test_dir + "test_clear_range_all.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 写入测试数据
            vector<char> test_data(100, 0xAA);
            file.store_from_void_ptr(test_data.data(), 100, 0, false, mes_out);

            file.clear_range(0, 100, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  清空整个文件成功");
            }
            else {
                bin_file_test::print_("  清空整个文件失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("6.3 clear_range测试 - 零大小清空");
        {
            std::string test_file = test_dir + "test_clear_range_zero.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            file.clear_range(0, 0, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  零大小清空成功（应无操作）");
            }
            else {
                bin_file_test::print_("  零大小清空失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("6.4 clear_range测试 - 范围越界");
        {
            std::string test_file = test_dir + "test_clear_range_overflow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 测试越界
            file.clear_range(50, 100, mes_out); // 50+100 > 100
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到范围越界 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("6.5 clear_range测试 - 溢出检查");
        {
            std::string test_file = test_dir + "test_clear_range_overflow2.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 测试size_t溢出
            file.clear_range(SIZE_MAX - 50, 100, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到溢出: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到溢出 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("6.6 clear_range测试 - 文件未打开时操作");
        {
            bin_file file; // 未打开
            mes::a_mes mes_out;
            file.clear_range(0, 10, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件未打开");
            }
            else {
                bin_file_test::print_("  未检测到文件未打开 - 错误");
            }
        }

        // ============================ save_as函数测试 ============================
        bin_file_test::print_("\n7. save_as函数测试：\n");

        bin_file_test::print_("7.1 save_as测试 - 正常另存为");
        {
            std::string src_file = test_dir + "test_save_as_src.txt";
            std::string dst_file = test_dir + "test_save_as_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(src_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 写入测试数据
            vector<char> test_data(100);
            for (int i = 0; i < 100; i++) {
                test_data[i] = static_cast<char>(i);
            }
            file.store_from_void_ptr(test_data.data(), 100, 0, false, mes_out);

            // 另存为
            file.save_as(dst_file, mes_out);
            if (mes_out.code == 0 && file.__check_inited__() && file.path == dst_file) {
                bin_file_test::print_("  另存为成功");

                // 验证文件内容相同
                if (bin_file_test::compare_files(src_file, dst_file)) {
                    bin_file_test::print_("  验证通过：文件内容相同");
                }
                else {
                    bin_file_test::print_("  验证失败：文件内容不同");
                }
            }
            else {
                bin_file_test::print_("  另存为失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("7.2 save_as测试 - 另存为到自身（编码错误）");
        {
            std::string test_file = test_dir + "test_save_as_self.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            try {
                file.save_as(test_file, mes_out);
                bin_file_test::print_("  未捕获异常 - 错误");
            }
            catch (mes::a_mes e) {
                bin_file_test::print_("  捕获异常 - 正常: " + e.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("7.3 save_as测试 - 另存为到空路径");
        {
            std::string test_file = test_dir + "test_save_as_empty.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            try {
                file.save_as("", mes_out);
                bin_file_test::print_("  未捕获异常 - 错误");
            }
            catch (mes::a_mes e) {
                bin_file_test::print_("  捕获异常 - 正常: " + e.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("7.4 save_as测试 - 文件未打开时另存为");
        {
            bin_file file; // 未打开
            mes::a_mes mes_out;
            file.save_as(test_dir + "test_not_open.txt", mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件未打开");
            }
            else {
                bin_file_test::print_("  未检测到文件未打开 - 错误");
            }
        }

        // ============================ load/store测试（文件到文件） ============================
        bin_file_test::print_("\n8. load/store测试（文件到文件）：\n");

        bin_file_test::print_("8.1 load测试 - 正常文件到文件");
        {
            std::string src_file = test_dir + "test_load_src.txt";
            std::string dst_file = test_dir + "test_load_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            // 创建源文件并写入数据
            bin_file src;
            mes::a_mes mes_out;
            src.open(src_file, 200, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  源文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> src_data(200);
            for (int i = 0; i < 200; i++) {
                src_data[i] = static_cast<char>(i % 256);
            }
            src.store_from_void_ptr(src_data.data(), 200, 0, false, mes_out);

            // 创建目标文件
            bin_file dst;
            dst.open(dst_file, 200, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  目标文件打开失败: " + mes_out.message);
                src.close(mes_out);
                return;
            }

            // 从源文件读取数据到目标文件
            src.load(0, 100, dst, 50, true, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  load操作成功");

                // 验证目标文件数据
                vector<char> dst_buffer(200);
                dst.load_to_void_ptr(0, 200, dst_buffer.data(), false, mes_out);

                // 检查50-150位置的数据是否与源文件0-100位置相同
                bool valid = true;
                for (int i = 0; i < 100; i++) {
                    if (dst_buffer[50 + i] != src_data[i]) {
                        valid = false;
                        break;
                    }
                }

                if (valid) {
                    bin_file_test::print_("  验证通过：数据正确传输");
                }
                else {
                    bin_file_test::print_("  验证失败：数据传输错误");
                }
            }
            else {
                bin_file_test::print_("  load操作失败: " + mes_out.message);
            }

            src.close(mes_out);
            dst.close(mes_out);
        }

        bin_file_test::print_("8.2 store测试 - 正常文件从文件");
        {
            std::string src_file = test_dir + "test_store_src.txt";
            std::string dst_file = test_dir + "test_store_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            // 创建源文件并写入数据
            bin_file src;
            mes::a_mes mes_out;
            src.open(src_file, 150, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  源文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> src_data(150);
            for (int i = 0; i < 150; i++) {
                src_data[i] = static_cast<char>((i + 50) % 256);
            }
            src.store_from_void_ptr(src_data.data(), 150, 0, false, mes_out);

            // 创建目标文件
            bin_file dst;
            dst.open(dst_file, 200, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  目标文件打开失败: " + mes_out.message);
                src.close(mes_out);
                return;
            }

            // 从源文件存储数据到目标文件
            dst.store(src, 25, 100, 75, true, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  store操作成功");
            }
            else {
                bin_file_test::print_("  store操作失败: " + mes_out.message);
            }

            src.close(mes_out);
            dst.close(mes_out);
        }

        bin_file_test::print_("8.3 load测试 - 安全模式边界检查（同文件操作不重叠）");
        {
            std::string test_file = test_dir + "test_load_same_file.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 200, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 写入测试数据
            vector<char> data(200, 0xAA);
            file.store_from_void_ptr(data.data(), 200, 0, false, mes_out);

            // 尝试重叠操作（应该失败）
            try {
                file.load(0, 100, file, 50, true, true, mes_out);
            }
            catch (mes::a_mes e) {
                if (e.code != 0) {
                    bin_file_test::print_("  正确检测到同文件重叠操作: " + e.message);
                }
                else {
                    bin_file_test::print_("  未检测到同文件重叠操作 - 错误");
                }
            }
           
            // 尝试不重叠操作（应该成功）
            file.load(0, 50, file, 150, true, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  同文件不重叠操作成功");
            }
            else {
                bin_file_test::print_("  同文件不重叠操作失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("8.4 load测试 - 文件未打开时操作");
        {
            std::string src_file = test_dir + "test_load_not_open_src.txt";
            std::string dst_file = test_dir + "test_load_not_open_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            bin_file src;
            bin_file dst;
            mes::a_mes mes_out;

            // 只打开源文件，不打开目标文件
            src.open(src_file, 100, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  源文件打开失败: " + mes_out.message);
                return;
            }

            src.load(0, 50, dst, 0, true, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到目标文件未打开: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到目标文件未打开 - 错误");
            }

            src.close(mes_out);
        }

        bin_file_test::print_("8.5 load测试 - 零大小操作");
        {
            std::string src_file = test_dir + "test_load_zero_src.txt";
            std::string dst_file = test_dir + "test_load_zero_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            bin_file src;
            bin_file dst;
            mes::a_mes mes_out;

            src.open(src_file, 100, init_type::create, mes_out);
            dst.open(dst_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            src.load(0, 0, dst, 0, true, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  零大小操作成功（应无操作）");
            }
            else {
                bin_file_test::print_("  零大小操作失败: " + mes_out.message);
            }

            src.close(mes_out);
            dst.close(mes_out);
        }

        bin_file_test::print_("8.6 load测试 - 范围越界");
        {
            std::string src_file = test_dir + "test_load_overflow_src.txt";
            std::string dst_file = test_dir + "test_load_overflow_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            bin_file src;
            bin_file dst;
            mes::a_mes mes_out;

            src.open(src_file, 100, init_type::create, mes_out);
            dst.open(dst_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 源文件范围越界
            src.load(50, 100, dst, 0, true, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到源文件范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到源文件范围越界 - 错误");
            }

            src.close(mes_out);
            dst.close(mes_out);
        }

        bin_file_test::print_("8.7 load测试 - 非安全模式");
        {
            std::string src_file = test_dir + "test_load_unsafe_src.txt";
            std::string dst_file = test_dir + "test_load_unsafe_dst.txt";
            bin_file_test::cleanup_test_file(src_file);
            bin_file_test::cleanup_test_file(dst_file);

            bin_file src;
            bin_file dst;
            mes::a_mes mes_out;

            src.open(src_file, 100, init_type::create, mes_out);
            dst.open(dst_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 写入源数据
            vector<char> src_data(100, 0xCC);
            src.store_from_void_ptr(src_data.data(), 100, 0, false, mes_out);

            // 非安全模式传输
            src.load(0, 100, dst, 0, false, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  非安全模式操作成功");
            }
            else {
                bin_file_test::print_("  非安全模式操作失败: " + mes_out.message);
            }

            src.close(mes_out);
            dst.close(mes_out);
        }

        // ============================ load_to_agent_ptr/store_from_agent_ptr测试 ============================
        bin_file_test::print_("\n9. 文件与代理指针交互测试：\n");

        bin_file_test::print_("9.1 load_to_agent_ptr测试 - 正常情况");
        {
            std::string test_file = test_dir + "test_load_to_agent_ptr.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 200, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 写入文件数据
            vector<char> file_data(200);
            for (int i = 0; i < 200; i++) {
                file_data[i] = static_cast<char>(i % 256);
            }
            file.store_from_void_ptr(file_data.data(), 200, 0, false, mes_out);

            // 创建代理指针
            vector<char> agent_buffer(200);
            bmms_f::agent_ptr agent(agent_buffer.data(), 200);

            // 从文件加载到代理指针
            file.load_to_agent_ptr(50, 100, agent, 25, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  load_to_agent_ptr成功");

                // 验证数据
                bool valid = true;
                for (int i = 0; i < 100; i++) {
                    if (agent_buffer[25 + i] != file_data[50 + i]) {
                        valid = false;
                        break;
                    }
                }

                if (valid) {
                    bin_file_test::print_("  验证通过：数据正确传输");
                }
                else {
                    bin_file_test::print_("  验证失败：数据传输错误");
                }
            }
            else {
                bin_file_test::print_("  load_to_agent_ptr失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("9.2 store_from_agent_ptr测试 - 正常情况");
        {
            std::string test_file = test_dir + "test_store_from_agent_ptr.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 200, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 创建代理指针并填充数据
            vector<char> agent_buffer(150);
            for (int i = 0; i < 150; i++) {
                agent_buffer[i] = static_cast<char>((i * 2) % 256);
            }
            bmms_f::agent_ptr agent(agent_buffer.data(), 150);

            // 从代理指针存储到文件
            file.store_from_agent_ptr(agent, 25, 100, 50, true, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  store_from_agent_ptr成功");
            }
            else {
                bin_file_test::print_("  store_from_agent_ptr失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("9.3 load_to_agent_ptr测试 - 空代理指针");
        {
            std::string test_file = test_dir + "test_load_to_null_agent.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 空代理指针
            bmms_f::agent_ptr null_agent;

            file.load_to_agent_ptr(0, 50, null_agent, 0, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到空代理指针: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到空代理指针 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("9.4 load_to_agent_ptr测试 - 代理指针范围越界");
        {
            std::string test_file = test_dir + "test_load_agent_overflow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 小代理指针
            vector<char> small_buffer(50);
            bmms_f::agent_ptr small_agent(small_buffer.data(), 50);

            // 尝试加载100字节到50字节的代理指针
            file.load_to_agent_ptr(0, 100, small_agent, 0, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到代理指针范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到代理指针范围越界 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("9.5 load_to_agent_ptr测试 - 文件范围越界");
        {
            std::string test_file = test_dir + "test_load_file_overflow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> agent_buffer(200);
            bmms_f::agent_ptr agent(agent_buffer.data(), 200);

            // 尝试从超出文件范围的位置读取
            file.load_to_agent_ptr(80, 50, agent, 0, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到文件范围越界 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("9.6 store_from_agent_ptr测试 - 文件范围越界");
        {
            std::string test_file = test_dir + "test_store_file_overflow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> agent_buffer(200);
            bmms_f::agent_ptr agent(agent_buffer.data(), 200);

            // 尝试存储到超出文件范围的位置
            file.store_from_agent_ptr(agent, 0, 50, 80, true, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到文件范围越界 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("9.7 store_from_agent_ptr测试 - 非安全模式");
        {
            std::string test_file = test_dir + "test_store_agent_unsafe.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 200, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> agent_buffer(100, 0xDD);
            bmms_f::agent_ptr agent(agent_buffer.data(), 100);

            file.store_from_agent_ptr(agent, 0, 100, 50, false, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  非安全模式操作成功");
            }
            else {
                bin_file_test::print_("  非安全模式操作失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        // ============================ load_to_void_ptr/store_from_void_ptr测试 ============================
        bin_file_test::print_("\n10. 文件与void指针交互测试：\n");

        bin_file_test::print_("10.1 load_to_void_ptr测试 - 正常情况");
        {
            std::string test_file = test_dir + "test_load_to_void_ptr.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 写入文件数据
            vector<char> file_data(100);
            for (int i = 0; i < 100; i++) {
                file_data[i] = static_cast<char>(i);
            }
            file.store_from_void_ptr(file_data.data(), 100, 0, false, mes_out);

            // 加载到void指针
            vector<char> void_buffer(100);
            file.load_to_void_ptr(25, 50, void_buffer.data(), true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  load_to_void_ptr成功");

                // 验证数据
                bool valid = true;
                for (int i = 0; i < 50; i++) {
                    if (void_buffer[i] != file_data[25 + i]) {
                        valid = false;
                        break;
                    }
                }

                if (valid) {
                    bin_file_test::print_("  验证通过：数据正确传输");
                }
                else {
                    bin_file_test::print_("  验证失败：数据传输错误");
                }
            }
            else {
                bin_file_test::print_("  load_to_void_ptr失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("10.2 store_from_void_ptr测试 - 正常情况");
        {
            std::string test_file = test_dir + "test_store_from_void_ptr.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> void_data(50, 0xEE);

            file.store_from_void_ptr(void_data.data(), 50, 25, true, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  store_from_void_ptr成功");
            }
            else {
                bin_file_test::print_("  store_from_void_ptr失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("10.3 load_to_void_ptr测试 - 空void指针");
        {
            std::string test_file = test_dir + "test_load_to_null_void.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            file.load_to_void_ptr(0, 50, nullptr, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到空void指针: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到空void指针 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("10.4 load_to_void_ptr测试 - 文件范围越界");
        {
            std::string test_file = test_dir + "test_load_void_overflow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> buffer(200);

            file.load_to_void_ptr(80, 50, buffer.data(), true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到文件范围越界 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("10.5 store_from_void_ptr测试 - 文件范围越界");
        {
            std::string test_file = test_dir + "test_store_void_overflow.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            vector<char> data(50);

            file.store_from_void_ptr(data.data(), 50, 80, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确检测到文件范围越界: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  未检测到文件范围越界 - 错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("10.6 load_to_void_ptr测试 - 非安全模式");
        {
            std::string test_file = test_dir + "test_load_void_unsafe.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 写入数据
            vector<char> file_data(100, 0x99);
            file.store_from_void_ptr(file_data.data(), 100, 0, false, mes_out);

            vector<char> buffer(50);

            file.load_to_void_ptr(25, 50, buffer.data(), false, mes_out);
            if (mes_out.code == 0) {
                bin_file_test::print_("  非安全模式操作成功");
            }
            else {
                bin_file_test::print_("  非安全模式操作失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        // ============================ 定理检查函数测试 ============================
        bin_file_test::print_("\n11. 定理检查函数测试：\n");

        bin_file_test::print_("11.1 no_overflow测试");
        {
            bin_file file;
            if (file.no_overflow(100, 200) &&
                !file.no_overflow(SIZE_MAX - 50, 100) &&
                file.no_overflow(0, SIZE_MAX) &&
                !file.no_overflow(1, SIZE_MAX)) {
                bin_file_test::print_("  no_overflow测试通过");
            }
            else {
                bin_file_test::print_("  no_overflow测试失败");
            }
        }

        bin_file_test::print_("11.2 __check_inited__测试");
        {
            std::string test_file = test_dir + "test_check_inited.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;

            // 未初始化状态
            if (!file.__check_inited__()) {
                bin_file_test::print_("  未初始化状态检查正确");
            }
            else {
                bin_file_test::print_("  未初始化状态检查错误");
            }

            // 初始化后状态
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);
            if (mes_out.code == 0 && file.__check_inited__()) {
                bin_file_test::print_("  初始化后状态检查正确");
            }
            else {
                bin_file_test::print_("  初始化后状态检查错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("11.3 __same_file__测试");
        {
            std::string file1_path = test_dir + "same_file1.txt";
            std::string file2_path = test_dir + "same_file2.txt";
            std::string file3_path = test_dir + "same_file1.txt"; // 相同路径

            bin_file_test::cleanup_test_file(file1_path);
            bin_file_test::cleanup_test_file(file2_path);
            bin_file_test::cleanup_test_file(file3_path);

            bin_file file1;
            bin_file file2;
            bin_file file3;
            mes::a_mes mes_out;

            file1.open(file1_path, 100, init_type::create, mes_out);
            file2.open(file2_path, 100, init_type::create, mes_out);
            file3.open(file3_path, 100, init_type::create, mes_out);

            if (!file1.__same_file__(file2) &&
                file1.__same_file__(file3) &&
                !file2.__same_file__(file3)) {
                bin_file_test::print_("  __same_file__测试通过");
            }
            else {
                bin_file_test::print_("  __same_file__测试失败");
            }

            file1.close(mes_out);
            file2.close(mes_out);
            file3.close(mes_out);
        }

        bin_file_test::print_("11.4 __file_size__测试");
        {
            std::string test_file = test_dir + "test_file_size.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;

            // 创建时指定大小
            file.open(test_file, 250, init_type::create, mes_out);
            if (mes_out.code == 0 && file.__file_size__() == 250) {
                bin_file_test::print_("  创建时文件大小正确");
            }
            else {
                bin_file_test::print_("  创建时文件大小错误");
            }

            // 调整大小后
            file.resize(500, mes_out);
            if (mes_out.code == 0 && file.__file_size__() == 500) {
                bin_file_test::print_("  调整后文件大小正确");
            }
            else {
                bin_file_test::print_("  调整后文件大小错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("11.5 __check_file_range__测试");
        {
            std::string test_file = test_dir + "test_check_range.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 100, init_type::create, mes_out);

            if (mes_out.code != 0) {
                bin_file_test::print_("  文件打开失败: " + mes_out.message);
                return;
            }

            // 有效范围
            if (file.__check_file_range__(0, 100) &&
                file.__check_file_range__(25, 50) &&
                file.__check_file_range__(0, 0)) { // 零大小
                bin_file_test::print_("  有效范围检查正确");
            }
            else {
                bin_file_test::print_("  有效范围检查错误");
            }

            // 无效范围
            if (!file.__check_file_range__(0, 101) &&
                !file.__check_file_range__(100, 1) &&
                !file.__check_file_range__(50, 51) &&
                !file.__check_file_range__(SIZE_MAX - 50, 100)) { // 溢出
                bin_file_test::print_("  无效范围检查正确");
            }
            else {
                bin_file_test::print_("  无效范围检查错误");
            }

            file.close(mes_out);
        }

        bin_file_test::print_("11.6 __check_range_overlap__测试");
        {
            bin_file file;

            // 不重叠情况
            if (!file.__check_range_overlap__(0, 50, 50, 50) &&  // 刚好相邻
                !file.__check_range_overlap__(0, 50, 100, 50) && // 完全分离
                !file.__check_range_overlap__(100, 50, 0, 50)) { // 反序
                bin_file_test::print_("  不重叠情况检查正确");
            }
            else {
                bin_file_test::print_("  不重叠情况检查错误");
            }

            // 重叠情况
            if (file.__check_range_overlap__(0, 100, 50, 100) &&  // 部分重叠
                file.__check_range_overlap__(0, 100, 0, 100) &&   // 完全重叠
                file.__check_range_overlap__(25, 50, 0, 100)) {   // 包含在内
                bin_file_test::print_("  重叠情况检查正确");
            }
            else {
                bin_file_test::print_("  重叠情况检查错误");
            }
        }

        bin_file_test::print_("11.7 __op_begin__/__op_end__测试");
        {
            bin_file file;

            // 正常操作
            size_t begin = file.__op_begin__(100);
            size_t end = file.__op_end__(100, 50);

            if (begin == 100 && end == 150) {
                bin_file_test::print_("  正常操作计算正确");
            }
            else {
                bin_file_test::print_("  正常操作计算错误");
            }

            // 溢出测试（应该抛出异常）
            try {
                file.__op_end__(SIZE_MAX - 50, 100);
                bin_file_test::print_("  未捕获溢出异常 - 错误");
            }
            catch (mes::a_mes e) {
                bin_file_test::print_("  正确捕获溢出异常: " + e.message);
            }
        }

        // ============================ 边界值测试 ============================
        bin_file_test::print_("\n12. 边界值测试：\n");

        bin_file_test::print_("12.1 SIZE_MAX边界测试");
        {
            std::string test_file = test_dir + "test_size_max.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;

            // 尝试创建极大文件（可能失败，取决于文件系统）
            file.open(test_file, SIZE_MAX, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  创建极大文件失败（预期内）: " + mes_out.message);
            }
            else {
                bin_file_test::print_("  创建极大文件成功（可能截断）");
                file.close(mes_out);
            }
        }

        bin_file_test::print_("12.2 零大小文件操作");
        {
            std::string test_file = test_dir + "test_zero_size.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 0, init_type::create, mes_out);

            if (mes_out.code == 0 && file.__file_size__() == 0) {
                bin_file_test::print_("  零大小文件创建成功");

                // 尝试各种操作
                vector<char> buffer(10);
                bmms_f::agent_ptr agent(buffer.data(), 10);

                // load操作应该失败（范围越界）
                file.load(0, 1, file, 0, true, true, mes_out);
                if (mes_out.code != 0) {
                    bin_file_test::print_("  零大小文件load正确失败: " + mes_out.message);
                }
                else {
                    bin_file_test::print_("  零大小文件load不应该成功");
                }

                // load_to_void_ptr应该失败
                file.load_to_void_ptr(0, 1, buffer.data(), true, mes_out);
                if (mes_out.code != 0) {
                    bin_file_test::print_("  零大小文件load_to_void_ptr正确失败: " + mes_out.message);
                }
                else {
                    bin_file_test::print_("  零大小文件load_to_void_ptr不应该成功");
                }
            }
            else {
                bin_file_test::print_("  零大小文件创建失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("12.3 单字节文件操作");
        {
            std::string test_file = test_dir + "test_one_byte.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, 1, init_type::create, mes_out);

            if (mes_out.code == 0 && file.__file_size__() == 1) {
                bin_file_test::print_("  单字节文件创建成功");

                // 写入一个字节
                char data = 0x7F;
                file.store_from_void_ptr(&data, 1, 0, true, mes_out);

                // 读取一个字节
                char read_data;
                file.load_to_void_ptr(0, 1, &read_data, true, mes_out);

                if (mes_out.code == 0 && read_data == data) {
                    bin_file_test::print_("  单字节读写操作成功");
                }
                else {
                    bin_file_test::print_("  单字节读写操作失败");
                }
            }
            else {
                bin_file_test::print_("  单字节文件创建失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        bin_file_test::print_("12.4 大文件分块操作");
        {
            std::string test_file = test_dir + "test_large_file.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;

            // 创建10MB文件（测试分块操作）
            const size_t LARGE_SIZE = 10 * 1024 * 1024; // 10MB
            file.open(test_file, LARGE_SIZE, init_type::create, mes_out);

            if (mes_out.code == 0) {
                bin_file_test::print_("  大文件创建成功");

                // 写入模式数据
                vector<char> pattern(1024); // 1KB模式
                for (size_t i = 0; i < pattern.size(); i++) {
                    pattern[i] = static_cast<char>(i % 256);
                }

                // 分块写入
                size_t remaining = LARGE_SIZE;
                size_t offset = 0;
                while (remaining > 0) {
                    size_t chunk = std::min(remaining, pattern.size());
                    file.store_from_void_ptr(pattern.data(), chunk, offset, false, mes_out);
                    if (mes_out.code != 0) {
                        bin_file_test::print_("  大文件写入失败: " + mes_out.message);
                        break;
                    }
                    remaining -= chunk;
                    offset += chunk;
                }

                if (mes_out.code == 0) {
                    bin_file_test::print_("  大文件写入成功");

                    // 验证部分数据
                    vector<char> verify_buffer(1024);
                    file.load_to_void_ptr(LARGE_SIZE - 1024, 1024, verify_buffer.data(), false, mes_out);

                    if (mes_out.code == 0) {
                        bool valid = true;
                        for (size_t i = 0; i < 1024; i++) {
                            if (verify_buffer[i] != pattern[i]) {
                                valid = false;
                                break;
                            }
                        }

                        if (valid) {
                            bin_file_test::print_("  大文件验证成功");
                        }
                        else {
                            bin_file_test::print_("  大文件验证失败");
                        }
                    }
                    else {
                        bin_file_test::print_("  大文件验证读取失败: " + mes_out.message);
                    }
                }
            }
            else {
                bin_file_test::print_("  大文件创建失败: " + mes_out.message);
            }

            file.close(mes_out);
        }

        // ============================ 综合测试 ============================
        bin_file_test::print_("\n13. 综合测试：\n");

        bin_file_test::print_("13.1 文件生命周期测试");
        {
            std::string test_file = test_dir + "test_lifecycle.txt";
            bin_file_test::cleanup_test_file(test_file);

            mes::a_mes mes_out;

            // 1. 创建
            bin_file file;
            file.open(test_file, 100, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  创建失败: " + mes_out.message);
                return;
            }
            bin_file_test::print_("  阶段1: 文件创建成功");

            // 2. 写入数据
            std::string data1 = "Hello, World!";
            file.store_from_void_ptr((void*)data1.c_str(), data1.size(), 0, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  写入失败: " + mes_out.message);
                return;
            }
            bin_file_test::print_("  阶段2: 数据写入成功");

            // 3. 调整大小
            file.resize(200, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  调整大小失败: " + mes_out.message);
                return;
            }
            bin_file_test::print_("  阶段3: 文件调整大小成功");

            // 4. 另存为
            std::string new_file = test_dir + "test_lifecycle_copy.txt";
            bin_file_test::cleanup_test_file(new_file);
            file.save_as(new_file, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  另存为失败: " + mes_out.message);
                return;
            }
            bin_file_test::print_("  阶段4: 文件另存为成功");

            // 5. 关闭
            file.close(mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  关闭失败: " + mes_out.message);
                return;
            }
            bin_file_test::print_("  阶段5: 文件关闭成功");

            // 6. 重新打开验证
            file.open(new_file, 0, init_type::open_existed, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  重新打开失败: " + mes_out.message);
                return;
            }

            vector<char> read_buffer(data1.size() + 1);
            file.load_to_void_ptr(0, data1.size(), read_buffer.data(), true, mes_out);
            read_buffer[data1.size()] = '\0';

            if (mes_out.code == 0 && std::string(read_buffer.data()) == data1) {
                bin_file_test::print_("  阶段6: 重新打开验证成功");
            }
            else {
                bin_file_test::print_("  阶段6: 重新打开验证失败");
            }

            file.close(mes_out);
            bin_file_test::cleanup_test_file(new_file);
        }

        bin_file_test::print_("13.2 错误恢复测试");
        {
            std::string test_file = test_dir + "test_error_recovery.txt";
            bin_file_test::cleanup_test_file(test_file);

            bin_file file;
            mes::a_mes mes_out;

            // 正常操作
            file.open(test_file, 100, init_type::create, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  打开失败: " + mes_out.message);
                return;
            }

            // 触发一个错误（范围越界）
            file.load_to_void_ptr(0, 200, nullptr, true, mes_out);
            if (mes_out.code != 0) {
                bin_file_test::print_("  正确触发错误: " + mes_out.message);

                // 错误后尝试正常操作（应该能恢复）
                mes_out = mes::a_mes(0, 0, ""); // 重置消息

                vector<char> buffer(50);
                file.load_to_void_ptr(0, 50, buffer.data(), true, mes_out);
                if (mes_out.code == 0) {
                    bin_file_test::print_("  错误后恢复成功");
                }
                else {
                    bin_file_test::print_("  错误后恢复失败: " + mes_out.message);
                }
            }
            else {
                bin_file_test::print_("  未正确触发错误");
            }

            file.close(mes_out);
        }

        // 清理测试目录
        bin_file_test::print_("\n清理测试文件...");
        try {
            std::filesystem::remove_all(test_dir);
            bin_file_test::print_("清理完成");
        }
        catch (...) {
            bin_file_test::print_("清理失败");
        }

        // ============================ 性能压测测试 ============================
        bin_file_test::print_("\n14. 性能压测测试：\n");

        // 临时测试目录
        std::string perf_test_dir = "C:/lib/cache/perf_test/";
        bin_file_test::cleanup_test_file(perf_test_dir);
        bin_file_test::create_test_directory(perf_test_dir);

        // 测试参数
        const size_t PERF_ITERATIONS = 1000;  // 1千次操作
        const size_t SMALL_BFS_SIZE = 1024;   // 1KB小文件
        const size_t LARGE_BFS_SIZE = 1024 * 1024; // 1MB大文件

        bin_file_test::print_("14.1 文件创建性能测试\n");
        {
            bin_file_test::print_("  bin_file创建性能: ");
            mes::a_mes mes_out;
            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < PERF_ITERATIONS; ++i) {
                std::string file_path = perf_test_dir + "perf_create_" + to_string(i) + ".bin";
                bin_file file(file_path, SMALL_BFS_SIZE, init_type::create, mes_out);
                if (mes_out.code != 0) {
                    bin_file_test::print_("创建失败: " + mes_out.message);
                    break;
                }
                file.close(mes_out);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            double avg_us = duration.count() * 1000.0 / PERF_ITERATIONS;
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) +
                " ms (平均" + to_string(avg_us) + " us/次)");
        }

        bin_file_test::print_("\n14.2 文件读写性能测试\n");
        {
            // 测试文件
            std::string test_file = perf_test_dir + "perf_rw.bin";
            bin_file_test::cleanup_test_file(test_file);

            // 创建测试数据
            vector<byte_1> test_data(LARGE_BFS_SIZE);
            for (size_t i = 0; i < LARGE_BFS_SIZE; ++i) {
                test_data[i] = static_cast<byte_1>(i % 256);
            }

            // bin_file写入性能
            bin_file_test::print_("  bin_file写入(1MB): ");
            {
                bin_file file;
                mes::a_mes mes_out;
                file.open(test_file, LARGE_BFS_SIZE, init_type::create, mes_out);

                auto start = std::chrono::high_resolution_clock::now();
                file.store_from_void_ptr(test_data.data(), LARGE_BFS_SIZE, 0, false, mes_out);
                auto end = std::chrono::high_resolution_clock::now();

                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                double speed = LARGE_BFS_SIZE / (1024.0 * 1024.0) / (duration.count() / 1000000.0);
                bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) +
                    " us (" + to_string(speed) + " MB/s)");

                file.close(mes_out);
            }

            // bin_file读取性能
            bin_file_test::print_("  bin_file读取(1MB): ");
            {
                bin_file file;
                mes::a_mes mes_out;
                file.open(test_file, 0, init_type::open_existed, mes_out);

                vector<byte_1> read_buffer(LARGE_BFS_SIZE);
                auto start = std::chrono::high_resolution_clock::now();
                file.load_to_void_ptr(0, LARGE_BFS_SIZE, read_buffer.data(), false, mes_out);
                auto end = std::chrono::high_resolution_clock::now();

                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                double speed = LARGE_BFS_SIZE / (1024.0 * 1024.0) / (duration.count() / 1000000.0);
                bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) +
                    " us (" + to_string(speed) + " MB/s)");

                file.close(mes_out);
            }
        }

        bin_file_test::print_("\n14.3 与标准fstream性能对比\n");
        {
            std::string bin_file_path = perf_test_dir + "perf_bin_file.bin";
            std::string fstream_path = perf_test_dir + "perf_fstream.bin";

            const size_t TEST_SIZE = 1024 * 1024; // 1MB
            vector<byte_1> test_data(TEST_SIZE, 0xAA);

            // bin_file性能
            bin_file_test::print_("  bin_file写1MB: ");
            {
                bin_file_test::cleanup_test_file(bin_file_path);
                bin_file file;
                mes::a_mes mes_out;
                file.open(bin_file_path, TEST_SIZE, init_type::create, mes_out);

                auto start = std::chrono::high_resolution_clock::now();
                file.store_from_void_ptr(test_data.data(), TEST_SIZE, 0, false, mes_out);
                file.flush();  // 确保写入磁盘
                auto end = std::chrono::high_resolution_clock::now();

                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) + " us");

                file.close(mes_out);
            }

            // 标准fstream性能
            bin_file_test::print_("  fstream写1MB: ");
            {
                bin_file_test::cleanup_test_file(fstream_path);
                auto start = std::chrono::high_resolution_clock::now();

                std::ofstream fs(fstream_path, std::ios::binary);
                fs.write(reinterpret_cast<const char*>(test_data.data()), TEST_SIZE);
                fs.flush();
                fs.close();

                auto end = std::chrono::high_resolution_clock::now();
                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) + " us");
            }

            // 读取性能对比
            bin_file_test::print_("\n  bin_file读1MB: ");
            {
                bin_file file;
                mes::a_mes mes_out;
                file.open(bin_file_path, 0, init_type::open_existed, mes_out);

                vector<byte_1> buffer(TEST_SIZE);
                auto start = std::chrono::high_resolution_clock::now();
                file.load_to_void_ptr(0, TEST_SIZE, buffer.data(), false, mes_out);
                auto end = std::chrono::high_resolution_clock::now();

                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) + " us");

                file.close(mes_out);
            }

            bin_file_test::print_("  fstream读1MB: ");
            {
                vector<byte_1> buffer(TEST_SIZE);
                auto start = std::chrono::high_resolution_clock::now();

                std::ifstream fs(fstream_path, std::ios::binary);
                fs.read(reinterpret_cast<char*>(buffer.data()), TEST_SIZE);
                fs.close();

                auto end = std::chrono::high_resolution_clock::now();
                auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
                bin_file_test::print_("  " + to_string(static_cast<unsigned long>(duration.count())) + " us");
            }
        }

        bin_file_test::print_("\n14.4 大文件分块读写性能\n");
        {
            const size_t BIG_BFS_SIZE = 10 * 1024 * 1024; // 10MB
            const size_t BLOCK_SIZE = 64 * 1024; // 64KB块

            std::string big_file = perf_test_dir + "perf_big_file.bin";
            bin_file_test::cleanup_test_file(big_file);

            // 准备测试数据
            vector<byte_1> block_data(BLOCK_SIZE);
            for (size_t i = 0; i < BLOCK_SIZE; ++i) {
                block_data[i] = static_cast<byte_1>(i % 256);
            }

            // 创建大文件
            bin_file file;
            mes::a_mes mes_out;
            file.open(big_file, BIG_BFS_SIZE, init_type::create, mes_out);

            bin_file_test::print_("  分块写入10MB(64KB/块): ");
            auto write_start = std::chrono::high_resolution_clock::now();

            size_t blocks = BIG_BFS_SIZE / BLOCK_SIZE;
            for (size_t i = 0; i < blocks; ++i) {
                file.store_from_void_ptr(block_data.data(), BLOCK_SIZE, i * BLOCK_SIZE, false, mes_out);
                if (mes_out.code != 0) {
                    bin_file_test::print_("写入失败: " + mes_out.message);
                    break;
                }
            }

            auto write_end = std::chrono::high_resolution_clock::now();
            auto write_duration = std::chrono::duration_cast<std::chrono::milliseconds>(write_end - write_start);
            double write_speed = BIG_BFS_SIZE / (1024.0 * 1024.0) / (write_duration.count() / 1000.0);
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(write_duration.count())) +
                " ms (" + to_string(write_speed) + " MB/s)");

            // 分块读取测试
            bin_file_test::print_("  分块读取10MB(64KB/块): ");
            vector<byte_1> read_block(BLOCK_SIZE);

            auto read_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < blocks; ++i) {
                file.load_to_void_ptr(i * BLOCK_SIZE, BLOCK_SIZE, read_block.data(), false, mes_out);
                if (mes_out.code != 0) {
                    bin_file_test::print_("读取失败: " + mes_out.message);
                    break;
                }
            }

            auto read_end = std::chrono::high_resolution_clock::now();
            auto read_duration = std::chrono::duration_cast<std::chrono::milliseconds>(read_end - read_start);
            double read_speed = BIG_BFS_SIZE / (1024.0 * 1024.0) / (read_duration.count() / 1000.0);
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(read_duration.count())) +
                " ms (" + to_string(read_speed) + " MB/s)");

            file.close(mes_out);
        }

        bin_file_test::print_("\n14.5 文件与代理指针交互性能\n");
        {
            std::string test_file = perf_test_dir + "perf_agent.bin";
            bin_file_test::cleanup_test_file(test_file);

            const size_t BFS_SIZE = 1024 * 1024; // 1MB
            const size_t AGENT_SIZE = 64 * 1024;  // 64KB代理指针

            // 创建文件和代理指针
            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, BFS_SIZE, init_type::create, mes_out);

            vector<byte_1> agent_buffer(AGENT_SIZE);
            bmms_f::agent_ptr agent(agent_buffer.data(), AGENT_SIZE);

            // 填充代理指针数据
            for (size_t i = 0; i < AGENT_SIZE; ++i) {
                agent_buffer[i] = static_cast<byte_1>(i % 256);
            }

            bin_file_test::print_("  store_from_agent_ptr(64KB): ");
            auto store_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < 16; ++i) {  // 16次填满1MB
                size_t offset = i * AGENT_SIZE;
                file.store_from_agent_ptr(agent, 0, AGENT_SIZE, offset, false, true, mes_out);
            }

            auto store_end = std::chrono::high_resolution_clock::now();
            auto store_duration = std::chrono::duration_cast<std::chrono::microseconds>(store_end - store_start);
            double store_total_bytes = 16.0 * AGENT_SIZE;
            double store_speed = store_total_bytes / (1024.0 * 1024.0) / (store_duration.count() / 1000000.0);
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(store_duration.count())) +
                " us (" + to_string(store_speed) + " MB/s)");

            bin_file_test::print_("  load_to_agent_ptr(64KB): ");
            auto load_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < 16; ++i) {
                size_t offset = i * AGENT_SIZE;
                file.load_to_agent_ptr(offset, AGENT_SIZE, agent, 0, false, mes_out);
            }

            auto load_end = std::chrono::high_resolution_clock::now();
            auto load_duration = std::chrono::duration_cast<std::chrono::microseconds>(load_end - load_start);
            double load_total_bytes = 16.0 * AGENT_SIZE;
            double load_speed = load_total_bytes / (1024.0 * 1024.0) / (load_duration.count() / 1000000.0);
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(load_duration.count())) +
                " us (" + to_string(load_speed) + " MB/s)");

            file.close(mes_out);
        }

        bin_file_test::print_("\n14.6 安全模式与非安全模式性能对比\n");
        {
            std::string test_file = perf_test_dir + "perf_safe_mode.bin";
            bin_file_test::cleanup_test_file(test_file);

            const size_t BFS_SIZE = 512 * 1024; // 512KB
            const size_t OP_SIZE = 4 * 1024;     // 4KB操作
            const size_t ITERATIONS = 1000;      // 1000次操作

            bin_file file;
            mes::a_mes mes_out;
            file.open(test_file, BFS_SIZE, init_type::create, mes_out);

            vector<byte_1> buffer(OP_SIZE);

            // 安全模式
            bin_file_test::print_("  安全模式(4KB×1000次): ");
            auto safe_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                size_t offset = (i * OP_SIZE) % (BFS_SIZE - OP_SIZE);
                file.store_from_void_ptr(buffer.data(), OP_SIZE, offset, true, mes_out);
            }

            auto safe_end = std::chrono::high_resolution_clock::now();
            auto safe_duration = std::chrono::duration_cast<std::chrono::milliseconds>(safe_end - safe_start);
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(safe_duration.count())) + " ms");

            // 非安全模式
            bin_file_test::print_("  非安全模式(4KB×1000次): ");
            auto unsafe_start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                size_t offset = (i * OP_SIZE) % (BFS_SIZE - OP_SIZE);
                file.store_from_void_ptr(buffer.data(), OP_SIZE, offset, false, mes_out);
            }

            auto unsafe_end = std::chrono::high_resolution_clock::now();
            auto unsafe_duration = std::chrono::duration_cast<std::chrono::milliseconds>(unsafe_end - unsafe_start);
            double performance_improvement = (safe_duration.count() - unsafe_duration.count()) * 100.0 / safe_duration.count();
            bin_file_test::print_("  " + to_string(static_cast<unsigned long>(unsafe_duration.count())) +
                " ms (" + to_string(performance_improvement) + "%性能提升)");

            file.close(mes_out);
        }

        // 清理性能测试文件
        bin_file_test::print_("\n清理性能测试文件...");
        try {
            std::filesystem::remove_all(perf_test_dir);
            bin_file_test::print_("清理完成\n");
        }
        catch (...) {
            bin_file_test::print_("清理失败\n");
        }

        bin_file_test::print_("\n========== 性能测试完成 ==========\n");

        bin_file_test::print_("\n========== BFS 测试结束 ==========\n");
    }
    #endif
}