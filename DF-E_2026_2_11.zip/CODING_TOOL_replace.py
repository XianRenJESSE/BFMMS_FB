﻿#!/usr/bin/env python
"""
浠ｇ悊鎸囬拡閿欒娑堟伅鎵归噺鏇挎崲宸ュ叿

浣跨敤鏂瑰紡锛?
    1. 灏嗘湰鑴氭湰涓庣洰鏍囨枃浠讹紙濡?BMMS_mes.h锛夋斁鍦ㄥ悓涓€鐩綍
    2. 杩愯鑴氭湰锛岃緭鍏ユ枃浠跺悕锛堟垨鐩存帴鎷栧叆鏂囦欢锛?
    3. 鎸変互涓嬫牸寮忚緭鍏ユ浛鎹㈣鍒欙細
        鍘熷唴瀹?> 鏇挎崲鍐呭
        鍘熷唴瀹? > 鏇挎崲鍐呭2
        ...
    4. 杈撳叆 /w 鎵ц鏇挎崲骞朵繚瀛?
    5. 杈撳叆 /q 鏀惧純淇敼骞堕€€鍑?

娉ㄦ剰锛?
    - 鏂囦欢缂栫爜寮哄埗涓?ANSI (GBK/GB2312)
    - 姣忚瑙勫垯浣跨敤 ' > ' 浣滀负鍒嗛殧绗︼紙绌烘牸-澶т簬鍙?绌烘牸锛?
    - 绌鸿鎴栨棤鏁堟牸寮忓皢琚拷鐣?
"""

import os
import sys
import re
from pathlib import Path

# ------------------------------------------------------------
#  ANSI 缂栫爜妫€娴嬩笌鍏煎灞?
# ------------------------------------------------------------
def detect_ansi_encoding(file_path):
    """妫€娴嬫枃浠剁殑 ANSI 缂栫爜锛堥€氬父鏄?GBK 鎴?GB2312锛?""
    try:
        with open(file_path, 'rb') as f:
            raw = f.read()
        # 灏濊瘯甯歌 ANSI 缂栫爜
        for enc in ['gbk', 'gb2312', 'cp936', 'latin-1']:
            try:
                raw.decode(enc)
                return enc
            except UnicodeDecodeError:
                continue
        return 'gbk'  # 榛樿
    except Exception:
        return 'gbk'

def read_ansi_file(file_path):
    """璇诲彇 ANSI 鏂囦欢锛岃繑鍥炲瓧绗︿覆鍜屽疄闄呯紪鐮?""
    enc = detect_ansi_encoding(file_path)
    with open(file_path, 'r', encoding=enc) as f:
        content = f.read()
    return content, enc

def write_ansi_file(file_path, content, encoding='gbk'):
    """浠?ANSI 缂栫爜鍐欏叆鏂囦欢"""
    with open(file_path, 'w', encoding=encoding) as f:
        f.write(content)

# ------------------------------------------------------------
#  鏍稿績鏇挎崲閫昏緫
# ------------------------------------------------------------
def parse_rule(line):
    """
    瑙ｆ瀽鍗曟潯鏇挎崲瑙勫垯
    鏍煎紡锛氬師鍐呭 > 鏇挎崲鍐呭
    杩斿洖 (old, new) 鍏冪粍锛屾牸寮忛敊璇繑鍥?None
    """
    line = line.strip()
    if not line or ' > ' not in line:
        return None
    parts = line.split(' > ', 1)
    if len(parts) != 2:
        return None
    old, new = parts
    return (old.strip(), new.strip())

def apply_replacements(content, rules):
    """
    瀵?content 渚濇搴旂敤鎵€鏈夋浛鎹㈣鍒?
    rules: [(old, new), ...]
    """
    modified = content
    for old, new in rules:
        # 鍏ㄨ瘝鍖归厤锛岄伩鍏嶉儴鍒嗘浛鎹紙鍙牴鎹渶瑕佽皟鏁达級
        pattern = re.escape(old)
        modified = re.sub(pattern, new, modified)
    return modified

# ------------------------------------------------------------
#  浜や簰鐣岄潰
# ------------------------------------------------------------
def interactive_replace(file_path):
    """涓讳氦浜掓祦绋?""
    print(f"\n=== 浠ｇ悊鎸囬拡閿欒娑堟伅鏇挎崲宸ュ叿 ===")
    print(f"鐩爣鏂囦欢: {file_path}\n")

    # 璇诲彇鍘熷鍐呭
    try:
        original_content, encoding = read_ansi_file(file_path)
        print(f"鉁?鏂囦欢璇诲彇鎴愬姛锛岀紪鐮? {encoding}")
    except Exception as e:
        print(f"鉁?鏃犳硶璇诲彇鏂囦欢: {e}")
        return

    # 鏄剧ず褰撳墠鏂囦欢涓笌 agent_ptr/浠ｇ悊鎸囬拡 鐩稿叧鐨勯敊璇秷鎭紙棰勮锛?
    print("\n--- 褰撳墠鏂囦欢涓殑浠ｇ悊鎸囬拡閿欒娑堟伅 ---")
    preview_lines = []
    for line in original_content.splitlines():
        if 'agent_ptr' in line or '浠ｇ悊鎸囬拡' in line or 'coding_error' in line:
            preview_lines.append(line.strip())
    if preview_lines:
        for line in preview_lines[:15]:  # 鏈€澶氭樉绀?5琛?
            print(f"  {line}")
        if len(preview_lines) > 15:
            print(f"  ... 绛?{len(preview_lines)} 琛?)
    else:
        print("  (鏈彂鐜版槑鏄剧殑浠ｇ悊鎸囬拡閿欒娑堟伅)")
    print("-------------------------------------\n")

    # 鏀堕泦鏇挎崲瑙勫垯
    rules = []
    print("璇疯緭鍏ユ浛鎹㈣鍒欙紙姣忚鏍煎紡锛氬師鍐呭 > 鏇挎崲鍐呭锛?)
    print("杈撳叆 /w 鎵ц鏇挎崲骞朵繚瀛橈紝杈撳叆 /q 鏀惧純閫€鍑篭n")

    while True:
        try:
            line = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n鏀跺埌涓柇淇″彿")
            break

        if not line:
            continue

        if line == '/w':
            break
        if line == '/q':
            print("宸叉斁寮冧慨鏀广€?)
            return

        rule = parse_rule(line)
        if rule:
            rules.append(rule)
            print(f"  鉁?宸叉坊鍔? '{rule[0]}' -> '{rule[1]}'")
        else:
            print("  鉁?鏍煎紡閿欒锛屽簲涓? 鍘熷唴瀹?> 鏇挎崲鍐呭")

    # 鎵ц鏇挎崲
    if not rules:
        print("娌℃湁鏈夋晥鐨勬浛鎹㈣鍒欙紝鏂囦欢鏈慨鏀广€?)
        return

    print(f"\n鍗冲皢搴旂敤 {len(rules)} 鏉℃浛鎹㈣鍒?..")
    modified_content = apply_replacements(original_content, rules)

    # 璁＄畻宸紓缁熻
    diff_count = 0
    for old, _ in rules:
        diff_count += modified_content.count(old)  # 瀹為檯搴旀敼涓烘浛鎹㈠悗璁℃暟锛岃繖閲岀畝鍖?
    # 鏇村噯纭殑缁熻锛氭瘮杈冨師濮嬪拰淇敼鍚庣殑琛屾暟鍙樺寲
    orig_lines = original_content.splitlines()
    mod_lines = modified_content.splitlines()
    line_diff = len(mod_lines) - len(orig_lines)

    print(f"鏇挎崲瀹屾垚銆?)
    print(f"鍘熷澶у皬: {len(original_content)} 瀛楃")
    print(f"淇敼澶у皬: {len(modified_content)} 瀛楃")
    print(f"琛屾暟鍙樺寲: {line_diff:+d}")

    # 鍐欏洖鏂囦欢
    try:
        write_ansi_file(file_path, modified_content, encoding)
        print(f"\n鉁?鏂囦欢宸蹭繚瀛樿嚦: {file_path}")
        print(f"  缂栫爜: {encoding}")
    except Exception as e:
        print(f"\n鉁?鍐欏叆鏂囦欢澶辫触: {e}")
        # 灏濊瘯澶囦唤鍚庡啓鍏?
        backup = file_path + ".bak"
        try:
            write_ansi_file(backup, modified_content, encoding)
            print(f"  宸插浠借嚦: {backup}锛岃鎵嬪姩鏇挎崲銆?)
        except:
            print("  鏃犳硶鍐欏叆浠讳綍澶囦唤锛屼慨鏀逛涪澶便€?)

# ------------------------------------------------------------
#  鍏ュ彛
# ------------------------------------------------------------
if __name__ == "__main__":
    # 鏀寔鎷栨嫿鏂囦欢鎴栨墜鍔ㄨ緭鍏ヨ矾寰?
    if len(sys.argv) > 1:
        file_path = sys.argv[1].strip('"')
    else:
        file_path = input("璇疯緭鍏ユ枃浠惰矾寰勶紙鍙洿鎺ユ嫋鍏ワ級: ").strip('"')

    if not os.path.isfile(file_path):
        print(f"閿欒: 鏂囦欢 '{file_path}' 涓嶅瓨鍦?)
        sys.exit(1)

    interactive_replace(file_path)
