﻿//agent_ptr.cpp
module BMMS;

#include "BMMS_dp.h"

namespace bmms_f {
    //使用时请去 agent_ptr.cpp
    // 将 #define __EXIT__ std::exit(EXIT_FAILURE);// throw std::runtime_error("agent_ptr error");
    // 前后交换
#if defined(AGENT_PTR_INCLUDE_TEST)
    void agent_ptr::test() {
        print("========== AGENT_PTR 测试开始 ==========\n");

        // ============================ 构造测试 ============================
        print("\n1. 构造测试：\n");

        print("1.1 正常构造测试\n");
        byte_1 buffer1[100];
        agent_ptr ap1(buffer1, 100);

        print("1.2 nullptr构造测试\n");
        try {
            agent_ptr ap2(nullptr, 100);
        }
        catch (...) {
            print("捕获异常 - 正常\n");
        }

        print("1.3 零大小构造测试\n");
        try {
            byte_1 buffer3[1];
            agent_ptr ap3(buffer3, 0);
        }
        catch (...) {
            print("捕获异常 - 正常\n");
        }

        print("1.4 地址溢出构造测试\n");
        try {
            void* max_ptr = reinterpret_cast<void*>(UINTPTR_MAX - 50);
            agent_ptr ap4(max_ptr, 100);
        }
        catch (...) {
            print("捕获异常 - 正常\n");
        }

        // ============================ 数据获取测试 ============================
        print("\n2. 数据获取测试：\n");

        print("2.1 get_void_ptr测试\n");
        void* ptr_out;
        ap1.get_void_ptr(ptr_out);

        print("2.2 get_is_null测试\n");
        bool is_null;
        ap1.get_is_null(is_null);
        agent_ptr null_ap;
        null_ap.get_is_null(is_null);

        print("2.3 get_size测试\n");
        size_t size_out;
        ap1.get_size(size_out);

        print("2.4 get_begin测试\n");
        void* begin_out;
        ap1.get_begin(begin_out);

        print("2.5 get_end测试\n");
        void* end_out;
        ap1.get_end(end_out);

        print("2.6 边界get_end溢出测试\n");
        try {
            void* overflow_ptr = reinterpret_cast<void*>(UINTPTR_MAX - 10);
            agent_ptr ap_overflow(overflow_ptr, 20);
            ap_overflow.get_end(end_out);
        }
        catch (...) {
            print("捕获异常 - 正常\n");
        }

        print("2.7 get_check_range_bool测试\n");
        bool range_valid;
        ap1.get_check_range_bool(0, 50, range_valid);
        ap1.get_check_range_bool(0, 101, range_valid);
        ap1.get_check_range_bool(50, 0, range_valid);
        ap1.get_check_range_bool(0, SIZE_MAX, range_valid);

        print("2.8 check_building_no_overflow测试\n");
        bool building_overflow;
        void* buffer1_void = buffer1;
        ap1.check_building_no_overflow(buffer1_void, 100, building_overflow);
        void* overflow_ptr = reinterpret_cast<void*>(UINTPTR_MAX - 10);
        ap1.check_building_no_overflow(overflow_ptr, 20, building_overflow);

        print("2.9 check_end_no_overflow测试\n");
        bool end_no_overflow;
        ap1.check_end_no_overflow(0, 100, end_no_overflow);
        ap1.check_end_no_overflow(50, 51, end_no_overflow);
        ap1.check_end_no_overflow(0, SIZE_MAX, end_no_overflow);

        // ============================ 读写测试 ============================
        print("\n3. 读写测试：\n");

        // 准备测试数据
        byte_1 src_buffer[200];
        byte_1 dst_buffer[200];
        memset(src_buffer, 0xAA, 200);
        memset(dst_buffer, 0xBB, 200);

        agent_ptr src_ap(src_buffer, 200);
        agent_ptr dst_ap(dst_buffer, 200);

        print("3.1 load/store安全模式测试 - 正常情况\n");
        try {
            src_ap.load(0, 100, dst_ap, 0, true);
            dst_ap.store(src_ap, 0, 100, 100, true);
            print("  正常情况通过\n");
        }
        catch (...) {
            print("  正常情况异常\n");
        }

        print("3.2 load/store安全模式测试 - 空代理指针\n");
        try {
            agent_ptr null_ap2;
            src_ap.load(0, 10, null_ap2, 0, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.3 load/store安全模式测试 - 大小不匹配\n");
        try {
            agent_ptr small_ap(dst_buffer, 10);
            src_ap.load(0, 20, small_ap, 0, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.4 load/store安全模式测试 - 管理空间重叠\n");
        try {
            agent_ptr overlap_ap(src_buffer + 50, 100);
            src_ap.load(0, 100, overlap_ap, 0, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.5 load/store安全模式测试 - 操作区间无效\n");
        try {
            src_ap.load(200, 10, dst_ap, 0, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.6 load/store安全模式测试 - 原地操作\n");
        try {
            src_ap.load(0, 100, src_ap, 0, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.7 load/store安全模式测试 - 操作区间重叠\n");
        try {
            src_ap.load(0, 100, src_ap, 50, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.8 load_to_void_ptr安全模式测试 - 正常情况\n");
        try {
            byte_1 void_buffer[100];
            src_ap.load_to_void_ptr(0, 50, void_buffer, true);
            print("  正常情况通过\n");
        }
        catch (...) {
            print("  正常情况异常\n");
        }

        print("3.9 load_to_void_ptr安全模式测试 - 空void指针\n");
        try {
            void* null_void = nullptr;
            src_ap.load_to_void_ptr(0, 10, null_void, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.10 load_to_void_ptr安全模式测试 - 大小不匹配（源代理指针大小不足）\n");
        try {
            byte_1 void_buffer2[201];
            src_ap.load_to_void_ptr(0, 201, void_buffer2, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.11 load_to_void_ptr安全模式测试 - 操作区间重叠（修复版）\n");
        try {
            // 创建重叠情况：void指针指向源代理指针管理范围内的地址
            void* overlap_ptr = src_buffer + 50;
            src_ap.load_to_void_ptr(0, 100, overlap_ptr, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        print("3.12 store_from_void_ptr安全模式测试 - 正常情况\n");
        try {
            byte_1 void_buffer3[100];
            src_ap.store_from_void_ptr(void_buffer3, 50, 100, true);
            print("  正常情况通过\n");
        }
        catch (...) {
            print("  正常情况异常\n");
        }

        print("3.13 store_from_void_ptr安全模式测试 - 空void指针\n");
        try {
            void* null_void2 = nullptr;
            src_ap.store_from_void_ptr(null_void2, 10, 0, true);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        // ============================ 清空测试 ============================
        print("\n4. 清空测试：\n");

        print("4.1 clear测试\n");
        try {
            src_ap.clear();
            print("  正常情况通过\n");
        }
        catch (...) {
            print("  正常情况异常\n");
        }

        print("4.2 clear_range测试 - 正常情况\n");
        try {
            src_ap.clear_range(0, 50);
            print("  正常情况通过\n");
        }
        catch (...) {
            print("  正常情况异常\n");
        }

        print("4.3 clear_range测试 - 无效范围\n");
        try {
            src_ap.clear_range(200, 10);
        }
        catch (...) {
            print("  捕获异常 - 正常\n");
        }

        // ============================ 非安全模式测试 ============================
        print("\n5. 非安全模式测试：\n");

        print("5.1 load非安全模式测试\n");
        try {
            byte_1 test_buf1[50];
            byte_1 test_buf2[50];
            agent_ptr test_ap1(test_buf1, 50);
            agent_ptr test_ap2(test_buf2, 50);

            test_ap1.load(0, 50, test_ap2, 0, false);
            print("  非安全模式通过\n");
        }
        catch (...) {
            print("  非安全模式异常\n");
        }

        print("5.2 store非安全模式测试\n");
        try {
            byte_1 test_buf3[50];
            byte_1 test_buf4[50];
            agent_ptr test_ap3(test_buf3, 50);
            agent_ptr test_ap4(test_buf4, 50);

            test_ap3.store(test_ap4, 0, 50, 0, false);
            print("  非安全模式通过\n");
        }
        catch (...) {
            print("  非安全模式异常\n");
        }

        print("5.3 load_to_void_ptr非安全模式测试\n");
        try {
            byte_1 test_buf5[50];
            byte_1 test_buf6[50];
            agent_ptr test_ap5(test_buf5, 50);

            test_ap5.load_to_void_ptr(0, 50, test_buf6, false);
            print("  非安全模式通过\n");
        }
        catch (...) {
            print("  非安全模式异常\n");
        }

        print("5.4 store_from_void_ptr非安全模式测试\n");
        try {
            byte_1 test_buf7[50];
            byte_1 test_buf8[50];
            agent_ptr test_ap6(test_buf7, 50);

            test_ap6.store_from_void_ptr(test_buf8, 50, 0, false);
            print("  非安全模式通过\n");
        }
        catch (...) {
            print("  非安全模式异常\n");
        }
        // ============================ 性能压测 ============================
        print("\n6. 性能压测测试：\n");

        // 测试参数设置
        const size_t ITERATIONS = 1000000;  // 100万次操作
        const size_t BUFFER_SIZE = 1024;    // 1KB缓冲区

        print("6.1 agent_ptr 性能测试\n");

        // 准备测试数据
        byte_1* buffer1_ = new byte_1[BUFFER_SIZE];
        byte_1* buffer2_ = new byte_1[BUFFER_SIZE];
        memset(buffer1_, 0xAA, BUFFER_SIZE);
        memset(buffer2_, 0xBB, BUFFER_SIZE);

        agent_ptr ap1_(buffer1_, BUFFER_SIZE);
        agent_ptr ap2(buffer2_, BUFFER_SIZE);

        // 测试 agent_ptr::load 性能
        {
            print("  agent_ptr::load (安全模式): ");
            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                // 使用不同偏移避免编译器过度优化
                size_t offset = i % (BUFFER_SIZE - 100);
                ap1_.load(offset, 100, ap2, offset, true);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));
        }

        // 测试 agent_ptr::load 非安全模式性能
        {
            print("  agent_ptr::load (非安全模式): ");
            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                size_t offset = i % (BUFFER_SIZE - 100);
                ap1_.load(offset, 100, ap2, offset, false);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));
        }

        // 测试 agent_ptr::load_to_void_ptr 性能
        {
            print("  agent_ptr::load_to_void_ptr: ");
            byte_1 temp_buffer[100];
            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                size_t offset = i % (BUFFER_SIZE - 100);
                ap1_.load_to_void_ptr(offset, 100, temp_buffer, false);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));
        }

        // 对比测试：unique_ptr 直接内存拷贝
        print("\n6.2 unique_ptr 性能对比测试\n");
        {
            print("  unique_ptr + memcpy: ");

            // 使用 unique_ptr 管理内存
            auto up1 = make_unique<byte_1[]>(BUFFER_SIZE);
            auto up2 = make_unique<byte_1[]>(BUFFER_SIZE);

            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                size_t offset = i % (BUFFER_SIZE - 100);
                memcpy(up2.get() + offset, up1.get() + offset, 100);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));
        }

        // 对比测试：裸指针操作
        {
            print("  裸指针操作: ");
            byte_1* raw1 = new byte_1[BUFFER_SIZE];
            byte_1* raw2 = new byte_1[BUFFER_SIZE];

            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < ITERATIONS; ++i) {
                size_t offset = i % (BUFFER_SIZE - 100);
                memcpy(raw2 + offset, raw1 + offset, 100);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));

            delete[] raw1;
            delete[] raw2;
        }

        // 大规模内存操作测试
        print("\n6.3 大规模内存操作测试\n");
        {
            const size_t LARGE_SIZE = 10 * 1024 * 1024;  // 10MB
            const size_t LARGE_ITERATIONS = 1000;

            byte_1* large_buffer1 = new byte_1[LARGE_SIZE];
            byte_1* large_buffer2 = new byte_1[LARGE_SIZE];

            agent_ptr large_ap1(large_buffer1, LARGE_SIZE);
            agent_ptr large_ap2(large_buffer2, LARGE_SIZE);

            print("  agent_ptr 大规模复制(10MB x 1000次): ");
            auto start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < LARGE_ITERATIONS; ++i) {
                large_ap1.load(0, LARGE_SIZE, large_ap2, 0, false);
            }

            auto end = std::chrono::high_resolution_clock::now();
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));

            // 对比 unique_ptr
            print("  unique_ptr 大规模复制(10MB x 1000次): ");
            auto up_large1 = make_unique<byte_1[]>(LARGE_SIZE);
            auto up_large2 = make_unique<byte_1[]>(LARGE_SIZE);

            start = std::chrono::high_resolution_clock::now();

            for (size_t i = 0; i < LARGE_ITERATIONS; ++i) {
                memcpy(up_large2.get(), up_large1.get(), LARGE_SIZE);
            }

            end = std::chrono::high_resolution_clock::now();
            duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
            print("%lu ms\n", static_cast<unsigned long>(duration.count()));

            delete[] large_buffer1;
            delete[] large_buffer2;
        }

        // 清理测试数据
        delete[] buffer1_;
        delete[] buffer2_;

        print("\n========== 性能测试完成 ==========\n");

        print("\n========== AGENT_PTR 测试结束 ==========\n");
        };
#endif
};