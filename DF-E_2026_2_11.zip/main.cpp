﻿#include "SIMPLE_TYPE_NAME.h"

import MES;
import BMMS;
import BFS;

int main() {
	while (true) {
		int inp = 0;
		print("1 : test agent_ptr \n");
		print("2 : test file \n");
		print("3 : test file_agent_ptr \n");
		print("4 : test volume \n");
		print("Enter a number to choose an test:");
		input >> inp;
		print("\n");	
		switch (inp) {
		case 1:
			{
				print("test agent_ptr\n");
				bmms_f::agent_ptr a;
				a.test();
				break;
			}
		case 2:
			{
				print("test file bin_file\n");
				bfs_f::bin_file f;
				f.test();
				bfs_f::dir_control::test();
				break;
			}
		case 3: 
			{
				print("test file_agent_ptr\n");
				bfs_f::file_agent_ptr fa;
				fa.test();
				break;
			}
		case 4:
			{
				print("test volume\n");
				mes::a_mes tmp_mes = mes::a_mes();
				bmms_f::static_volume v(
					1024,
					10,
					bmms_f::static_volume::init_type::init_all_size,
					bmms_f::static_volume::alignment_type::without_alignment,
					tmp_mes
				);
				break;
			}
		}
	}
};
