﻿#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
_mes.xml 杞崲鍣?
灏?xxx_mes.xml 鏂囦欢杞崲涓?xxx_mes.h 鏂囦欢
"""

import os
import sys
import re
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional

def parse_key_value_line(line: str) -> tuple:
    """瑙ｆ瀽閿€煎鏍煎紡鐨勮"""
    line = line.strip()
    if '=' in line:
        key, value = line.split('=', 1)
        return key.strip(), value.strip()
    return None, None

def parse_mes_xml(xml_file: Path) -> Optional[Dict]:
    """
    瑙ｆ瀽 _mes.xml 鏂囦欢锛屾彁鍙栨ā寮忎俊鎭拰閿欒浠ｇ爜
    
    Args:
        xml_file: XML鏂囦欢璺緞
        
    Returns:
        鍖呭惈瑙ｆ瀽鏁版嵁鐨勫瓧鍏哥粨鏋勶紝鎴朜one濡傛灉瑙ｆ瀽澶辫触
    """
    try:
        # 鐢变簬XML缁撴瀯鐗规畩锛屾垜浠厛鎵嬪姩瑙ｆ瀽info閮ㄥ垎
        with open(xml_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 鍒濆鍖栨暟鎹粨鏋?
        parsed_data = {
            'mode_info': {},
            'suggestions': [],
            'warnings': [],
            'errors': []
        }
        
        # 浣跨敤姝ｅ垯琛ㄨ揪寮忔彁鍙杋nfo閮ㄥ垎
        info_match = re.search(r'<info>(.*?)</info>', content, re.DOTALL)
        if info_match:
            info_content = info_match.group(1)
            lines = info_content.strip().split('\n')
            for line in lines:
                key, value = parse_key_value_line(line)
                if key and value:
                    parsed_data['mode_info'][key] = value
        
        # 瑙ｆ瀽sug閮ㄥ垎
        sug_match = re.search(r'<sug>(.*?)</sug>', content, re.DOTALL)
        if sug_match:
            sug_content = sug_match.group(1).strip()
            if sug_content != 'null' and sug_content != '':
                suggestions = [s.strip() for s in sug_content.split('\n') if s.strip()]
                parsed_data['suggestions'] = suggestions
        
        # 瑙ｆ瀽war閮ㄥ垎
        war_match = re.search(r'<war>(.*?)</war>', content, re.DOTALL)
        if war_match:
            war_content = war_match.group(1).strip()
            if war_content != 'null' and war_content != '':
                warnings = [w.strip() for w in war_content.split('\n') if w.strip()]
                parsed_data['warnings'] = warnings
        
        # 瑙ｆ瀽err閮ㄥ垎
        err_match = re.search(r'<err>(.*?)</err>', content, re.DOTALL)
        if err_match:
            err_content = err_match.group(1).strip()
            if err_content != 'null' and err_content != '':
                # 鎸夎鍒嗗壊锛岃繃婊ゆ帀绌鸿鍜屾敞閲?
                errors = []
                lines = err_content.split('\n')
                for line in lines:
                    line = line.strip()
                    if line and not line.startswith('<!--'):
                        errors.append(line)
                parsed_data['errors'] = errors
        
        return parsed_data
        
    except Exception as e:
        print(f"瑙ｆ瀽鏂囦欢 {xml_file} 鏃跺嚭閿? {e}")
        import traceback
        traceback.print_exc()
        return None

def generate_header_content(xml_file: Path, parsed_data: Dict) -> str:
    """
    鏍规嵁瑙ｆ瀽鐨勬暟鎹敓鎴愬ご鏂囦欢鍐呭
    
    Args:
        xml_file: 婧怷ML鏂囦欢璺緞
        parsed_data: 瑙ｆ瀽鍚庣殑鏁版嵁
        
    Returns:
        鐢熸垚鐨凜++澶存枃浠跺唴瀹?
    """
    # 鎻愬彇鏂囦欢鍚嶅墠缂€
    file_stem = xml_file.stem
    
    # 鑾峰彇妯″紡淇℃伅 - 蹇呴』浠嶺ML涓鍙?
    mode_info = parsed_data.get('mode_info', {})
    
    # 蹇呴』浠嶺ML涓鍙栬繖涓変釜鍏抽敭淇℃伅
    mode_name = mode_info.get('mode_name', '').strip()
    mode_macro = mode_info.get('mode_macro', '').strip()
    namespace = mode_info.get('namespace', '').strip()
    
    # 楠岃瘉蹇呰淇℃伅鏄惁瀛樺湪
    missing_fields = []
    if not mode_name:
        missing_fields.append('mode_name')
    if not mode_macro:
        missing_fields.append('mode_macro')
    if not namespace:
        missing_fields.append('namespace')
    
    if missing_fields:
        print(f"  鉂?閿欒: XML涓己灏戜互涓嬪繀瑕佸瓧娈? {', '.join(missing_fields)}")
        print(f"     鎵惧埌鐨勫瓧娈? {list(mode_info.keys())}")
        return None
    
    # 鑾峰彇鍒楄〃鏁版嵁
    suggestions = parsed_data.get('suggestions', [])
    warnings = parsed_data.get('warnings', [])
    errors = parsed_data.get('errors', [])
    
    # 鏋勫缓澶存枃浠跺唴瀹?
    content = []
    
    # 娣诲姞pragma once鍜宨nclude
    content.append("#pragma once")
    content.append('#include "SIMPLE_TYPE_NAME.h"')
    content.append('#include "INIT.h"')
    content.append("")
    content.append("import MES;")
    content.append("")
    
    # 娣诲姞鍛藉悕绌洪棿寮€濮?
    content.append(f"namespace {namespace} {{")
    content.append("")
    
    # 鐢熸垚sug鍛藉悕绌洪棿
    content.append(f"\tnamespace sug{{")
    if suggestions:
        for sug in suggestions:
            content.append(f'\t\tinline mes::a_mes {sug}() {{ return mes::a_mes({mode_macro}, __LINE__, "{sug}"); }};')
    else:
        content.append(f'\t\tinline mes::a_mes null() {{ return mes::a_mes({mode_macro}, __LINE__, "null"); }};')
    content.append("\t};")
    content.append("")
    
    # 鐢熸垚war鍛藉悕绌洪棿
    content.append(f"\tnamespace war {{")
    if warnings:
        for war in warnings:
            content.append(f'\t\tinline mes::a_mes {war}() {{ return mes::a_mes({mode_macro}, __LINE__, "{war}"); }};')
    else:
        content.append(f'\t\tinline mes::a_mes null() {{ return mes::a_mes({mode_macro}, __LINE__, "null"); }};')
    content.append("\t};")
    content.append("")
    
    # 鐢熸垚err鍛藉悕绌洪棿
    content.append(f"\tnamespace err {{")
    if errors:
        for err in errors:
            content.append(f'\t\tinline mes::a_mes {err}() {{ return mes::a_mes({mode_macro}, __LINE__, "{err}"); }};')
    else:
        content.append(f'\t\tinline mes::a_mes null() {{ return mes::a_mes({mode_macro}, __LINE__, "null"); }};')
    content.append("\t};")
    content.append("")
    
    # 娣诲姞鍛藉悕绌洪棿缁撴潫
    content.append("};")
    
    return "\n".join(content)

def display_file_content(xml_file: Path):
    """
    鏄剧ずXML鏂囦欢鐨勫叧閿俊鎭?
    """
    print(f"\n鏂囦欢鍐呭 - {xml_file.name}:")
    print("=" * 60)
    
    try:
        # 璇诲彇鏂囦欢鍐呭
        with open(xml_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 鏄剧ず鍓?00涓瓧绗?
        preview = content[:500] + "..." if len(content) > 500 else content
        print(preview)
        
        # 灏濊瘯鎻愬彇info閮ㄥ垎
        print("\n灏濊瘯鎻愬彇info閮ㄥ垎:")
        info_match = re.search(r'<info>(.*?)</info>', content, re.DOTALL)
        if info_match:
            info_content = info_match.group(1)
            print("鎵惧埌info閮ㄥ垎:")
            print(info_content)
            
            # 瑙ｆ瀽閿€煎
            lines = info_content.strip().split('\n')
            for line in lines:
                line = line.strip()
                if '=' in line:
                    key, value = line.split('=', 1)
                    print(f"  {key.strip()}: {value.strip()}")
        else:
            print("鏈壘鍒癷nfo閮ㄥ垎")
            
    except Exception as e:
        print(f"璇诲彇鏂囦欢鏃跺嚭閿? {e}")

def convert_mes_files(directory: str = "."):
    """
    杞崲鎸囧畾鐩綍涓嬬殑鎵€鏈?_mes.xml 鏂囦欢
    
    Args:
        directory: 瑕佹壂鎻忕殑鐩綍锛岄粯璁や负褰撳墠鐩綍
    """
    dir_path = Path(directory)
    
    if not dir_path.exists():
        print(f"閿欒: 鐩綍 {directory} 涓嶅瓨鍦?)
        return
    
    # 鏌ユ壘鎵€鏈?_mes.xml 鏂囦欢
    xml_files = list(dir_path.glob("*_mes.xml"))
    
    if not xml_files:
        print(f"鍦ㄧ洰褰?{directory} 涓湭鎵惧埌 *_mes.xml 鏂囦欢")
        return
    
    print(f"鎵惧埌 {len(xml_files)} 涓?_mes.xml 鏂囦欢:")
    for xml_file in xml_files:
        print(f"  - {xml_file.name}")
    
    print("\n寮€濮嬭浆鎹?..")
    
    successful = 0
    failed = 0
    
    for xml_file in xml_files:
        print(f"\n{'='*60}")
        print(f"澶勭悊鏂囦欢: {xml_file.name}")
        
        # 濡傛灉闇€瑕佽皟璇曪紝鏄剧ず鏂囦欢鍐呭
        if os.environ.get('SHOW_BFS_CONTENT'):
            display_file_content(xml_file)
        
        # 瑙ｆ瀽XML鏂囦欢
        parsed_data = parse_mes_xml(xml_file)
        
        if parsed_data is None:
            print(f"  鉂?瑙ｆ瀽澶辫触")
            failed += 1
            continue
        
        # 鏄剧ず浠嶺ML涓鍙栫殑淇℃伅
        mode_info = parsed_data.get('mode_info', {})
        print(f"  浠嶺ML璇诲彇鐨勪俊鎭?")
        for key, value in mode_info.items():
            print(f"    {key}: {value}")
        
        print(f"  寤鸿鏁伴噺: {len(parsed_data.get('suggestions', []))}")
        print(f"  璀﹀憡鏁伴噺: {len(parsed_data.get('warnings', []))}")
        print(f"  閿欒鏁伴噺: {len(parsed_data.get('errors', []))}")
        
        # 妫€鏌ュ繀瑕佺殑淇℃伅
        required_keys = ['mode_name', 'mode_macro', 'namespace']
        missing_keys = [key for key in required_keys if key not in mode_info]
        
        if missing_keys:
            print(f"  鉂?閿欒: XML涓己灏戜互涓嬪繀瑕佸瓧娈? {', '.join(missing_keys)}")
            failed += 1
            continue
        
        # 鐢熸垚澶存枃浠跺唴瀹?
        header_content = generate_header_content(xml_file, parsed_data)
        
        if header_content is None:
            print(f"  鉂?鐢熸垚澶存枃浠跺唴瀹瑰け璐?)
            failed += 1
            continue
        
        # 鐢熸垚澶存枃浠跺悕
        header_filename = xml_file.stem + ".h"
        header_path = xml_file.parent / header_filename
        
        try:
            # 鍐欏叆澶存枃浠?
            with open(header_path, 'w', encoding='utf-8') as f:
                f.write(header_content)
            
            print(f"  鉁?鐢熸垚鎴愬姛: {header_filename}")
            print(f"  妯″紡瀹? {mode_info['mode_macro']}")
            print(f"  鍛藉悕绌洪棿: {mode_info['namespace']}")
            successful += 1
            
        except Exception as e:
            print(f"  鉂?鍐欏叆鏂囦欢澶辫触: {e}")
            failed += 1
    
    print(f"\n{'='*60}")
    print("杞崲瀹屾垚!")
    print(f"鎴愬姛: {successful} 涓枃浠?)
    print(f"澶辫触: {failed} 涓枃浠?)

def main():
    """
    涓诲嚱鏁?
    """
    # 妫€鏌ュ懡浠よ鍙傛暟
    if len(sys.argv) > 1:
        directory = sys.argv[1]
    else:
        directory = "."
    
    print("=== _mes.xml 杞崲鍣?===")
    print(f"鎵弿鐩綍: {directory}")
    print("\n鐜鍙橀噺閫夐」:")
    print("  SHOW_BFS_CONTENT=1  鏄剧ずXML鏂囦欢鍐呭锛堣皟璇曠敤锛?)
    print("")
    
    # 鎵ц杞崲
    convert_mes_files(directory)

if __name__ == "__main__":
    main()
